/**
 * ═══════════════════════════════════════════════════════════
 *  LUME MULTI-AGENT COORDINATOR
 *  §7.3–7.5 LMADP — Task Fan-Out, Consensus Protocol,
 *  Conflict Resolution
 *
 *  Handles:
 *    - Task delegation to agents (D-AGT-01: by agent_id order)
 *    - Three-phase deterministic consensus (PROPOSE → VOTE → COMMIT)
 *    - Conflict resolution (D-AGT-03: type-matched classification)
 *    - Result merge from parallel subtasks
 *
 *  By DarkWave Studios LLC — DarkWaveStudios.io
 *  Copyright 2026. Protected by TrustShield.tech
 * ═══════════════════════════════════════════════════════════
 */

import crypto from 'crypto'
import { TRUST_LEVELS, MESSAGE_TYPES } from './gateway.js'

export const TASK_STATES = {
    RECEIVED: 'RECEIVED',
    VALIDATED: 'VALIDATED',
    EXECUTING: 'EXECUTING',
    COMPLETED: 'COMPLETED',
    REJECTED: 'REJECTED',
    FAILED: 'FAILED',
    ROLLED_BACK: 'ROLLED_BACK',
}

export const CONFLICT_CLASSES = {
    CLASS_A: { class: 'CLASS-A', action: 'IMMEDIATE_SESSION_TERMINATION', description: 'Trust violation' },
    CLASS_B: { class: 'CLASS-B', action: 'CONSENSUS_RE_ROUND', maxRounds: 2, description: 'Value disagreement' },
    CLASS_C: { class: 'CLASS-C', action: 'TASK_REASSIGNMENT', description: 'Timeout' },
    CLASS_D: { class: 'CLASS-D', action: 'HOMEOSTASIS_ARBITRATION', description: 'Resource contention' },
}

/**
 * A managed task.
 */
class ManagedTask {
    constructor(config) {
        this.taskId = config.taskId || crypto.randomUUID()
        this.requesterId = config.requesterId
        this.description = config.description || ''
        this.state = TASK_STATES.RECEIVED
        this.assignedAgents = []
        this.subtasks = []
        this.results = new Map()     // agentId → result
        this.createdAt = new Date().toISOString()
        this.completedAt = null
        this.stateHistory = [{ state: TASK_STATES.RECEIVED, timestamp: new Date().toISOString() }]
    }

    transition(newState) {
        this.state = newState
        this.stateHistory.push({ state: newState, timestamp: new Date().toISOString() })
        if (newState === TASK_STATES.COMPLETED || newState === TASK_STATES.FAILED) {
            this.completedAt = new Date().toISOString()
        }
    }
}

/**
 * A consensus round.
 */
class ConsensusRound {
    constructor(config) {
        this.proposalId = config.proposalId || crypto.randomUUID()
        this.proposedValue = config.proposedValue
        this.evidence = config.evidence || {}
        this.deadline = config.deadline || new Date(Date.now() + 30000).toISOString()
        this.votes = new Map()          // agentId → { vote: 'AGREE'|'DISAGREE', value }
        this.participants = new Set(config.participants || [])
        this.phase = 'PROPOSE'          // PROPOSE | VOTE | COMMIT | ESCALATE
        this.roundNumber = config.roundNumber || 1
        this.result = null
    }
}

/**
 * Multi-Agent Coordinator.
 */
export class MultiAgentCoordinator {
    constructor(config = {}) {
        this.tasks = new Map()           // taskId → ManagedTask
        this.consensusRounds = new Map() // proposalId → ConsensusRound
        this.delegationLog = []
        this.conflictLog = []
        this.gateway = config.gateway || null
        this.maxConsensusRounds = 2      // D-AGT-03: CLASS-B max 2 re-rounds

        // HITL Bridge reference
        this.hitlBridge = config.hitlBridge || null
    }

    /**
     * Create and track a new task.
     */
    createTask(config) {
        const task = new ManagedTask(config)
        this.tasks.set(task.taskId, task)
        return task
    }

    /**
     * Delegate subtasks to agents.
     * D-AGT-01: When agents have equivalent capability/trust,
     * delegate by agent_id (UUID v7 temporal ordering).
     *
     * @param {string} taskId - Parent task ID
     * @param {Array} subtasks - [{ description, requiredCapability, minTrustLevel }]
     * @param {Array} eligibleAgents - [{ agentId, capabilities, trustLevel }]
     * @returns {Array} Delegation assignments
     */
    delegate(taskId, subtasks, eligibleAgents) {
        const task = this.tasks.get(taskId)
        if (!task) throw new Error(`Task ${taskId} not found`)

        task.transition(TASK_STATES.VALIDATED)

        // Sort agents deterministically by agent_id (D-AGT-01)
        const sortedAgents = [...eligibleAgents].sort((a, b) =>
            a.agentId.localeCompare(b.agentId)
        )

        const assignments = []

        for (const subtask of subtasks) {
            // Find eligible agents for this subtask
            const capable = sortedAgents.filter(a => {
                const hasCapability = !subtask.requiredCapability
                    || a.capabilities?.includes(subtask.requiredCapability)
                const hasTrust = !subtask.minTrustLevel
                    || this._trustMeetsMinimum(a.trustLevel, subtask.minTrustLevel)
                return hasCapability && hasTrust
            })

            if (capable.length === 0) {
                assignments.push({
                    subtask: subtask.description,
                    assigned: null,
                    reason: 'No eligible agent',
                })
                continue
            }

            // Assign to first capable agent (deterministic — sorted by agent_id)
            const assigned = capable[0]
            assignments.push({
                subtask: subtask.description,
                assigned: assigned.agentId,
                trustLevel: assigned.trustLevel,
            })
            task.assignedAgents.push(assigned.agentId)
        }

        task.subtasks = subtasks
        task.transition(TASK_STATES.EXECUTING)

        this.delegationLog.push({
            taskId,
            assignments,
            timestamp: new Date().toISOString(),
        })

        return assignments
    }

    /**
     * Submit a result for a task from an agent.
     */
    submitResult(taskId, agentId, result) {
        const task = this.tasks.get(taskId)
        if (!task) throw new Error(`Task ${taskId} not found`)

        task.results.set(agentId, {
            value: result,
            submittedAt: new Date().toISOString(),
        })

        // Check if all assigned agents have reported
        const allReported = task.assignedAgents.every(id => task.results.has(id))

        if (allReported) {
            task.transition(TASK_STATES.COMPLETED)
        }

        return { received: true, allReported, pending: task.assignedAgents.length - task.results.size }
    }

    /**
     * Merge results from multiple agents.
     */
    mergeResults(taskId) {
        const task = this.tasks.get(taskId)
        if (!task) throw new Error(`Task ${taskId} not found`)

        const results = {}
        for (const [agentId, result] of task.results) {
            results[agentId] = result.value
        }

        return {
            taskId,
            state: task.state,
            resultCount: task.results.size,
            expectedCount: task.assignedAgents.length,
            results,
        }
    }

    // ═══════════════════════════════════════════
    //  CONSENSUS PROTOCOL (§7.5)
    // ═══════════════════════════════════════════

    /**
     * PHASE 1 — PROPOSE
     * Coordinator broadcasts a proposed value with evidence.
     */
    propose(value, evidence, participants) {
        const round = new ConsensusRound({
            proposedValue: value,
            evidence,
            participants,
        })

        this.consensusRounds.set(round.proposalId, round)

        return {
            proposalId: round.proposalId,
            proposedValue: value,
            evidence,
            deadline: round.deadline,
            participantCount: participants.length,
        }
    }

    /**
     * PHASE 2 — VOTE
     * Each agent computes the value from the same evidence and votes.
     * D-AGT-02: All agents compute from same evidence + same rulebook.
     */
    vote(proposalId, agentId, voteType, computedValue = null) {
        const round = this.consensusRounds.get(proposalId)
        if (!round) throw new Error(`Consensus round ${proposalId} not found`)

        if (!round.participants.has(agentId)) {
            throw new Error(`Agent ${agentId} is not a participant in this consensus`)
        }

        round.votes.set(agentId, {
            vote: voteType,  // 'AGREE' or 'DISAGREE'
            value: computedValue,
            timestamp: new Date().toISOString(),
        })

        round.phase = 'VOTE'

        // Check if all participants have voted
        if (round.votes.size === round.participants.size) {
            return this._evaluateConsensus(round)
        }

        return {
            proposalId,
            votesReceived: round.votes.size,
            votesNeeded: round.participants.size,
            phase: 'VOTE',
        }
    }

    /**
     * Classify a conflict deterministically.
     * D-AGT-03: By type-match, not severity judgment.
     */
    classifyConflict(conflictType) {
        const CLASSIFICATIONS = {
            trust_violation: CONFLICT_CLASSES.CLASS_A,
            value_disagreement: CONFLICT_CLASSES.CLASS_B,
            timeout: CONFLICT_CLASSES.CLASS_C,
            resource_contention: CONFLICT_CLASSES.CLASS_D,
        }

        const classification = CLASSIFICATIONS[conflictType]
        if (!classification) {
            return {
                class: 'UNKNOWN',
                action: 'ESCALATE_TO_HUMAN',
                description: `Unknown conflict type: ${conflictType}`,
            }
        }

        this.conflictLog.push({
            type: conflictType,
            classification: classification.class,
            action: classification.action,
            timestamp: new Date().toISOString(),
        })

        return { ...classification }
    }

    /**
     * Get coordinator statistics.
     */
    stats() {
        const tasksByState = {}
        for (const task of this.tasks.values()) {
            tasksByState[task.state] = (tasksByState[task.state] || 0) + 1
        }
        return {
            totalTasks: this.tasks.size,
            tasksByState,
            activeConsensusRounds: this.consensusRounds.size,
            totalDelegations: this.delegationLog.length,
            totalConflicts: this.conflictLog.length,
        }
    }

    // ── Private ──

    _evaluateConsensus(round) {
        const agrees = [...round.votes.values()].filter(v => v.vote === 'AGREE').length
        const total = round.votes.size
        const certified = this.gateway
            ? [...round.participants].filter(id => {
                const agent = this.gateway.getAgent(id)
                return agent?.trustLevel === TRUST_LEVELS.CERTIFIED
            }).length
            : total

        // Quorum: >50% of registered certified agents
        const quorum = Math.floor(certified / 2) + 1
        const quorumMet = agrees >= quorum

        if (quorumMet) {
            round.phase = 'COMMIT'
            round.result = {
                committed: true,
                value: round.proposedValue,
                agrees,
                total,
                quorum,
            }

            return {
                proposalId: round.proposalId,
                phase: 'COMMIT',
                result: round.result,
            }
        }

        // Quorum failed — check if we can re-round (CLASS-B)
        if (round.roundNumber < this.maxConsensusRounds) {
            // Re-round
            const newRound = new ConsensusRound({
                proposedValue: round.proposedValue,
                evidence: round.evidence,
                participants: [...round.participants],
                roundNumber: round.roundNumber + 1,
            })
            this.consensusRounds.set(newRound.proposalId, newRound)

            return {
                proposalId: newRound.proposalId,
                phase: 'RE-ROUND',
                roundNumber: newRound.roundNumber,
                previousAgrees: agrees,
                previousTotal: total,
            }
        }

        // Max re-rounds exhausted — escalate
        round.phase = 'ESCALATE'
        round.result = { committed: false, escalated: true, agrees, total, quorum }

        // Identify disagreeing agents for audit (D-AGT-02)
        const disagreeing = [...round.votes.entries()]
            .filter(([, v]) => v.vote === 'DISAGREE')
            .map(([agentId, v]) => ({ agentId, computedValue: v.value }))

        return {
            proposalId: round.proposalId,
            phase: 'ESCALATE',
            result: round.result,
            disagreeing,
            escalation: 'CONFLICT_ESCALATE — Consensus failed after max rounds',
        }
    }

    _trustMeetsMinimum(actual, minimum) {
        const order = [TRUST_LEVELS.UNTRUSTED, TRUST_LEVELS.SANDBOXED, TRUST_LEVELS.PROVISIONAL, TRUST_LEVELS.CERTIFIED]
        return order.indexOf(actual) >= order.indexOf(minimum)
    }
}

export const coordinator = new MultiAgentCoordinator()
export default coordinator
