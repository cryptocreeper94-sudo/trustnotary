/**
 * ═══════════════════════════════════════════════════════════
 *  LUME AGENT GATEWAY
 *  §7 LMADP — Agent Registration, Session Management,
 *  Certificate-Bound Sessions
 *
 *  The Agent Gateway is the entry point for all agents in
 *  the Lume ecosystem. It handles:
 *    - Agent identity registration and validation
 *    - Trust level assignment based on cert chain depth
 *    - Session token issuance with TTL
 *    - Certificate-bound session management
 *
 *  §7.7 Security Constraints:
 *    SEC-01: No agent may escalate its own trust_level
 *    SEC-02: Untrusted agents may only communicate with Coordinator
 *    SEC-05: Session tokens are non-transferable
 *    SEC-08: Agent code must be compiled through Lume compiler
 *
 *  By DarkWave Studios LLC — DarkWaveStudios.io
 *  Copyright 2026. Protected by TrustShield.tech
 * ═══════════════════════════════════════════════════════════
 */

import crypto from 'crypto'

export const AGENT_CLASSES = {
    COMPILER_AGENT: 'compiler_agent',
    RUNTIME_AGENT: 'runtime_agent',
    TRUST_AGENT: 'trust_agent',
    COORDINATOR_AGENT: 'coordinator_agent',
    USER_PROXY_AGENT: 'user_proxy_agent',
    EXTERNAL_AGENT: 'external_agent',
}

export const TRUST_LEVELS = {
    CERTIFIED: 'certified',
    PROVISIONAL: 'provisional',
    SANDBOXED: 'sandboxed',
    UNTRUSTED: 'untrusted',
}

export const MESSAGE_TYPES = {
    TASK_REQUEST: 'TASK_REQUEST',
    TASK_RESPONSE: 'TASK_RESPONSE',
    TASK_DELEGATION: 'TASK_DELEGATION',
    CONSENSUS_PROPOSE: 'CONSENSUS_PROPOSE',
    CONSENSUS_VOTE: 'CONSENSUS_VOTE',
    CONSENSUS_COMMIT: 'CONSENSUS_COMMIT',
    CONFLICT_ESCALATE: 'CONFLICT_ESCALATE',
    STATE_SNAPSHOT: 'STATE_SNAPSHOT',
    HEARTBEAT: 'HEARTBEAT',
    GATE_REQUEST: 'GATE_REQUEST',
    GATE_RESPONSE: 'GATE_RESPONSE',
    CERT_REFRESH: 'CERT_REFRESH',
    SESSION_TERMINATE: 'SESSION_TERMINATE',
}

/**
 * Agent identity record.
 */
class AgentIdentity {
    constructor(config) {
        this.agentId = config.agentId || crypto.randomUUID()
        this.agentClass = config.agentClass
        this.capabilitySet = config.capabilitySet || []
        this.trustLevel = TRUST_LEVELS.UNTRUSTED  // Default until validated
        this.certChainRoot = config.certChainRoot || null
        this.registeredAt = new Date().toISOString()
        this.registeredBy = config.registeredBy || null
        this.sessionToken = null
        this.sessionExpires = null
        this.lastHeartbeat = null
        this.messageCount = 0
    }
}

/**
 * LMADP Message format.
 */
export class AgentMessage {
    constructor(config) {
        this.protocol = 'LMADP/1.0'
        this.messageId = config.messageId || crypto.randomUUID()
        this.timestamp = config.timestamp || new Date().toISOString()
        this.sender = {
            agentId: config.senderId,
            trustLevel: config.senderTrustLevel || TRUST_LEVELS.UNTRUSTED,
        }
        this.recipient = {
            agentId: config.recipientId || 'COORDINATOR',
        }
        this.messageType = config.messageType
        this.payload = config.payload || {}
        this.certReference = config.certReference || null
        this.signature = null  // Set after signing
    }

    /**
     * Sign this message with Ed25519.
     */
    sign(privateKey) {
        const data = JSON.stringify({
            protocol: this.protocol,
            messageId: this.messageId,
            timestamp: this.timestamp,
            sender: this.sender,
            recipient: this.recipient,
            messageType: this.messageType,
            payload: this.payload,
        })

        const keyObject = crypto.createPrivateKey({
            key: privateKey,
            type: 'pkcs8',
            format: 'der',
        })
        this.signature = crypto.sign(null, Buffer.from(data), keyObject).toString('base64')
        return this.signature
    }

    /**
     * Verify message signature.
     */
    verify(publicKey) {
        if (!this.signature) return false

        const data = JSON.stringify({
            protocol: this.protocol,
            messageId: this.messageId,
            timestamp: this.timestamp,
            sender: this.sender,
            recipient: this.recipient,
            messageType: this.messageType,
            payload: this.payload,
        })

        const keyObject = crypto.createPublicKey({
            key: publicKey,
            type: 'spki',
            format: 'der',
        })
        return crypto.verify(null, Buffer.from(data), keyObject, Buffer.from(this.signature, 'base64'))
    }

    toJSON() {
        return {
            protocol: this.protocol,
            message_id: this.messageId,
            timestamp: this.timestamp,
            sender: this.sender,
            recipient: this.recipient,
            message_type: this.messageType,
            payload: this.payload,
            cert_reference: this.certReference,
            signature: this.signature,
        }
    }
}

/**
 * Agent Gateway — entry point for all agents.
 */
export class AgentGateway {
    constructor(config = {}) {
        this.agents = new Map()              // agentId → AgentIdentity
        this.sessions = new Map()            // sessionToken → agentId
        this.messageLog = []
        this.sessionTTL = config.sessionTTL || 3600000  // 1 hour default
        this.clockSkewTolerance = config.clockSkewTolerance || 60000  // 60 seconds (V-05)
        this.maxAgents = config.maxAgents || 1000

        // Trust certificate validator reference
        this.certValidator = config.certValidator || null

        // Message handlers
        this._messageHandlers = new Map()
    }

    /**
     * Register an agent.
     * §7.2 Registration Protocol:
     *   1. Agent submits identity + capability declaration
     *   2. Gateway validates cert_chain_root against Trust Layer CA
     *   3. Gateway assigns trust_level based on cert validation depth
     *   4. Gateway issues session token
     *   5. Session token has TTL
     */
    register(config) {
        if (this.agents.size >= this.maxAgents) {
            throw new Error(`Agent limit reached (${this.maxAgents})`)
        }

        const agent = new AgentIdentity(config)

        // Determine trust level based on certificate chain
        agent.trustLevel = this._determineTrustLevel(agent.certChainRoot)

        // Issue session token
        agent.sessionToken = this._issueSessionToken(agent.agentId)
        agent.sessionExpires = new Date(Date.now() + this.sessionTTL).toISOString()

        this.agents.set(agent.agentId, agent)
        this.sessions.set(agent.sessionToken, agent.agentId)

        return {
            agentId: agent.agentId,
            trustLevel: agent.trustLevel,
            sessionToken: agent.sessionToken,
            sessionExpires: agent.sessionExpires,
        }
    }

    /**
     * Validate an incoming message.
     * §7.4 Validation Rules V-01 through V-05
     */
    validateMessage(message) {
        const errors = []

        // V-01: Sender trust_level must meet task's minimum trust requirement
        const agent = this.agents.get(message.sender?.agentId)
        if (!agent) {
            errors.push('V-01: Unknown sender agent')
            return { valid: false, errors }
        }

        // V-05: Timestamp must be within 60s of receiver's clock
        const msgTime = new Date(message.timestamp).getTime()
        const now = Date.now()
        if (Math.abs(now - msgTime) > this.clockSkewTolerance) {
            errors.push(`V-05: Timestamp skew ${Math.abs(now - msgTime)}ms exceeds tolerance ${this.clockSkewTolerance}ms`)
        }

        // SEC-02: Untrusted agents may only communicate with Coordinator
        if (agent.trustLevel === TRUST_LEVELS.UNTRUSTED) {
            if (message.recipient?.agentId !== 'COORDINATOR') {
                errors.push('SEC-02: Untrusted agents may only communicate with the Coordinator')
            }
        }

        // SEC-03: Sandboxed agents may not initiate CONSENSUS_PROPOSE
        if (agent.trustLevel === TRUST_LEVELS.SANDBOXED) {
            if (message.messageType === MESSAGE_TYPES.CONSENSUS_PROPOSE) {
                errors.push('SEC-03: Sandboxed agents may not initiate CONSENSUS_PROPOSE')
            }
        }

        // Check session validity
        if (!agent.sessionToken || !this.sessions.has(agent.sessionToken)) {
            errors.push('Session token invalid or expired')
        }

        if (agent.sessionExpires && new Date(agent.sessionExpires) < new Date()) {
            errors.push('Session has expired')
        }

        // Log the message
        agent.messageCount++
        agent.lastHeartbeat = new Date().toISOString()

        return { valid: errors.length === 0, errors }
    }

    /**
     * Handle a heartbeat from an agent.
     */
    heartbeat(agentId) {
        const agent = this.agents.get(agentId)
        if (!agent) return false

        agent.lastHeartbeat = new Date().toISOString()
        return true
    }

    /**
     * Terminate an agent's session.
     */
    terminateSession(agentId, reason = 'terminated') {
        const agent = this.agents.get(agentId)
        if (!agent) return false

        if (agent.sessionToken) {
            this.sessions.delete(agent.sessionToken)
        }
        agent.sessionToken = null
        agent.sessionExpires = null

        this.messageLog.push({
            type: 'session_terminated',
            agentId,
            reason,
            timestamp: new Date().toISOString(),
        })

        return true
    }

    /**
     * Get an agent by ID.
     */
    getAgent(agentId) {
        const agent = this.agents.get(agentId)
        if (!agent) return null

        return {
            agentId: agent.agentId,
            agentClass: agent.agentClass,
            trustLevel: agent.trustLevel,
            capabilitySet: agent.capabilitySet,
            registeredAt: agent.registeredAt,
            sessionExpires: agent.sessionExpires,
            lastHeartbeat: agent.lastHeartbeat,
            messageCount: agent.messageCount,
        }
    }

    /**
     * Get all agents by trust level.
     */
    getAgentsByTrust(trustLevel) {
        return Array.from(this.agents.values())
            .filter(a => a.trustLevel === trustLevel)
            .map(a => this.getAgent(a.agentId))
    }

    /**
     * Get gateway statistics.
     */
    stats() {
        const byClass = {}
        const byTrust = {}
        for (const agent of this.agents.values()) {
            byClass[agent.agentClass] = (byClass[agent.agentClass] || 0) + 1
            byTrust[agent.trustLevel] = (byTrust[agent.trustLevel] || 0) + 1
        }
        return {
            totalAgents: this.agents.size,
            activeSessions: this.sessions.size,
            byClass,
            byTrust,
            messageLogSize: this.messageLog.length,
        }
    }

    // ── Private ──

    _determineTrustLevel(certChainRoot) {
        if (!certChainRoot) return TRUST_LEVELS.UNTRUSTED

        // If we have a cert validator, use it
        if (this.certValidator) {
            try {
                const result = this.certValidator.quickValidate(certChainRoot)
                if (result.valid) return TRUST_LEVELS.CERTIFIED
                return TRUST_LEVELS.PROVISIONAL
            } catch {
                return TRUST_LEVELS.SANDBOXED
            }
        }

        // Without validator, check if cert has basic structure
        if (certChainRoot.cert_id && certChainRoot.signature) {
            if (certChainRoot.chain?.parent_cert === 'ROOT') {
                return TRUST_LEVELS.CERTIFIED
            }
            return TRUST_LEVELS.PROVISIONAL
        }

        return TRUST_LEVELS.SANDBOXED
    }

    _issueSessionToken(agentId) {
        const tokenData = `${agentId}:${Date.now()}:${crypto.randomBytes(16).toString('hex')}`
        return crypto.createHash('sha256').update(tokenData).digest('hex')
    }
}

export const gateway = new AgentGateway()
export default gateway
