/**
 * ═══════════════════════════════════════════════════════════
 *  LUME HUMAN-IN-THE-LOOP (HITL) BRIDGE
 *  §7.6 — Confirmation Gates, Escalation Routing
 *
 *  Gate Triggers (§7.6):
 *    G-01: Any action classified as CONSEQUENCE_BEARING
 *    G-02: First execution of a task type by an agent
 *    G-03: Consensus failure in multi-agent vote
 *    G-04: Trust level downgrade during active session
 *    G-05: Resource consumption exceeding homeostatic bounds
 *    G-06: External system interaction (API calls, data egress)
 *
 *  TIMEOUT BEHAVIOR:
 *    "Silence is denial" — agents never assume approval.
 *    Default timeout: 300 seconds.
 *
 *  By DarkWave Studios LLC — DarkWaveStudios.io
 *  Copyright 2026. Protected by TrustShield.tech
 * ═══════════════════════════════════════════════════════════
 */

import crypto from 'crypto'

export const GATE_TRIGGERS = {
    CONSEQUENCE_BEARING: 'G-01',
    FIRST_TASK_TYPE: 'G-02',
    CONSENSUS_FAILURE: 'G-03',
    TRUST_DOWNGRADE: 'G-04',
    RESOURCE_EXCEEDED: 'G-05',
    EXTERNAL_INTERACTION: 'G-06',
}

export const CONSEQUENCE_CLASSES = {
    REVERSIBLE: 'reversible',
    IRREVERSIBLE: 'irreversible',
    FINANCIAL: 'financial',
    DATA_EGRESS: 'data_egress',
    PRIVILEGE_ESCALATION: 'privilege_escalation',
}

export const GATE_OPTIONS = {
    APPROVE: 'APPROVE',
    DENY: 'DENY',
    MODIFY: 'MODIFY',
    DEFER: 'DEFER',
}

const DEFAULT_TIMEOUT = 300  // seconds — "Silence is denial"

/**
 * A gate request awaiting human confirmation.
 */
class GateRequest {
    constructor(config) {
        this.gateId = config.gateId || crypto.randomUUID()
        this.trigger = config.trigger
        this.requestingAgent = config.requestingAgent
        this.actionSummary = config.actionSummary || 'Action requires human confirmation'
        this.consequenceClass = config.consequenceClass || CONSEQUENCE_CLASSES.REVERSIBLE
        this.evidence = config.evidence || {}
        this.options = config.options || Object.values(GATE_OPTIONS)
        this.timeout = config.timeout || DEFAULT_TIMEOUT
        this.createdAt = new Date().toISOString()
        this.expiresAt = new Date(Date.now() + (this.timeout * 1000)).toISOString()
        this.response = null
        this.respondedAt = null
        this.respondedBy = null
        this.status = 'pending'  // pending | approved | denied | modified | deferred | expired
    }

    isExpired() {
        return new Date() > new Date(this.expiresAt)
    }
}

/**
 * Human-in-the-Loop Bridge.
 */
export class HITLBridge {
    constructor(config = {}) {
        this.pendingGates = new Map()     // gateId → GateRequest
        this.resolvedGates = []            // History
        this.taskTypeHistory = new Map()   // taskType → Set<agentId> — tracks first executions (G-02)
        this.defaultTimeout = config.timeout || DEFAULT_TIMEOUT

        // Handler for presenting gate requests to humans
        this.onGateRequest = config.onGateRequest || null

        // Auto-responses for testing/CI
        this.autoResponses = config.autoResponses || null  // 'approve_all' | 'deny_all' | null
    }

    /**
     * Check if a gate should be triggered for an action.
     *
     * @param {Object} action
     * @param {string} action.type - Action type
     * @param {string} action.agentId - Agent performing the action
     * @param {Object} action.context - Action context
     * @returns {{ triggered: boolean, trigger: string|null, reason: string }}
     */
    shouldGate(action) {
        // G-01: Consequence-bearing action
        if (action.consequenceBearing || action.consequenceClass) {
            return {
                triggered: true,
                trigger: GATE_TRIGGERS.CONSEQUENCE_BEARING,
                reason: `Action is consequence-bearing (${action.consequenceClass || 'unknown class'})`,
            }
        }

        // G-02: First execution of a task type by an agent
        if (action.taskType && action.agentId) {
            const executors = this.taskTypeHistory.get(action.taskType)
            if (!executors || !executors.has(action.agentId)) {
                return {
                    triggered: true,
                    trigger: GATE_TRIGGERS.FIRST_TASK_TYPE,
                    reason: `First time agent ${action.agentId.slice(0, 8)} executes task type "${action.taskType}"`,
                }
            }
        }

        // G-03: Consensus failure
        if (action.consensusFailure) {
            return {
                triggered: true,
                trigger: GATE_TRIGGERS.CONSENSUS_FAILURE,
                reason: 'Consensus failed in multi-agent vote — human decision required',
            }
        }

        // G-04: Trust level downgrade
        if (action.trustDowngrade) {
            return {
                triggered: true,
                trigger: GATE_TRIGGERS.TRUST_DOWNGRADE,
                reason: `Trust level downgraded: ${action.previousTrust} → ${action.newTrust}`,
            }
        }

        // G-05: Resource exceeded
        if (action.resourceExceeded) {
            return {
                triggered: true,
                trigger: GATE_TRIGGERS.RESOURCE_EXCEEDED,
                reason: `Resource consumption exceeding bounds: ${action.resourceType}`,
            }
        }

        // G-06: External system interaction
        if (action.externalInteraction) {
            return {
                triggered: true,
                trigger: GATE_TRIGGERS.EXTERNAL_INTERACTION,
                reason: `External system interaction: ${action.externalSystem || 'unknown'}`,
            }
        }

        return { triggered: false, trigger: null, reason: 'No gate trigger matched' }
    }

    /**
     * Create a gate request.
     * @returns {GateRequest}
     */
    createGateRequest(config) {
        const gate = new GateRequest({
            ...config,
            timeout: config.timeout || this.defaultTimeout,
        })

        this.pendingGates.set(gate.gateId, gate)

        // Notify handler if set
        if (this.onGateRequest) {
            try { this.onGateRequest(gate) } catch { }
        }

        // Auto-response for testing
        if (this.autoResponses === 'approve_all') {
            this.respond(gate.gateId, GATE_OPTIONS.APPROVE, 'auto_test')
        } else if (this.autoResponses === 'deny_all') {
            this.respond(gate.gateId, GATE_OPTIONS.DENY, 'auto_test')
        }

        return gate
    }

    /**
     * Respond to a gate request.
     * @param {string} gateId
     * @param {string} response - One of GATE_OPTIONS
     * @param {string} [respondedBy] - Who responded
     * @param {*} [modifiedAction] - If MODIFY, the modified action
     */
    respond(gateId, response, respondedBy = 'human', modifiedAction = null) {
        const gate = this.pendingGates.get(gateId)
        if (!gate) throw new Error(`Gate ${gateId} not found`)

        if (gate.isExpired()) {
            gate.status = 'expired'
            gate.response = GATE_OPTIONS.DENY  // "Silence is denial"
            this._resolve(gate)
            return { gateId, status: 'expired', response: GATE_OPTIONS.DENY }
        }

        gate.response = response
        gate.respondedAt = new Date().toISOString()
        gate.respondedBy = respondedBy
        gate.status = response.toLowerCase()

        if (response === GATE_OPTIONS.MODIFY && modifiedAction) {
            gate.modifiedAction = modifiedAction
        }

        this._resolve(gate)

        // Track task type execution (G-02 — after approval)
        if (response === GATE_OPTIONS.APPROVE && gate.evidence?.taskType && gate.requestingAgent) {
            if (!this.taskTypeHistory.has(gate.evidence.taskType)) {
                this.taskTypeHistory.set(gate.evidence.taskType, new Set())
            }
            this.taskTypeHistory.get(gate.evidence.taskType).add(gate.requestingAgent)
        }

        return { gateId, status: gate.status, response }
    }

    /**
     * Check for and expire timed-out gates.
     * "Silence is denial" — expired gates are auto-denied.
     */
    expireTimedOut() {
        const expired = []

        for (const [gateId, gate] of this.pendingGates) {
            if (gate.isExpired()) {
                gate.status = 'expired'
                gate.response = GATE_OPTIONS.DENY
                this._resolve(gate)
                expired.push(gateId)
            }
        }

        return expired
    }

    /**
     * Get all pending gate requests.
     */
    getPending() {
        return Array.from(this.pendingGates.values()).map(g => ({
            gateId: g.gateId,
            trigger: g.trigger,
            agent: g.requestingAgent,
            summary: g.actionSummary,
            consequenceClass: g.consequenceClass,
            expiresAt: g.expiresAt,
            timeout: g.timeout,
        }))
    }

    /**
     * Get bridge statistics.
     */
    stats() {
        const byStatus = {}
        for (const gate of this.resolvedGates) {
            byStatus[gate.status] = (byStatus[gate.status] || 0) + 1
        }
        const byTrigger = {}
        for (const gate of this.resolvedGates) {
            byTrigger[gate.trigger] = (byTrigger[gate.trigger] || 0) + 1
        }

        return {
            pending: this.pendingGates.size,
            resolved: this.resolvedGates.length,
            byStatus,
            byTrigger,
            trackedTaskTypes: this.taskTypeHistory.size,
            defaultTimeout: this.defaultTimeout,
        }
    }

    // ── Private ──

    _resolve(gate) {
        this.pendingGates.delete(gate.gateId)
        this.resolvedGates.push({
            gateId: gate.gateId,
            trigger: gate.trigger,
            agent: gate.requestingAgent,
            status: gate.status,
            response: gate.response,
            consequenceClass: gate.consequenceClass,
            createdAt: gate.createdAt,
            resolvedAt: gate.respondedAt || new Date().toISOString(),
        })
    }
}

export const hitlBridge = new HITLBridge()
export default hitlBridge
