/**
 * ═══════════════════════════════════════════════════════════
 *  LUME INFERENCE AUDIT LOG
 *  Records every inference decision made by the LDIR engine.
 *
 *  DEF-03: LOG EVERYTHING — Every inference decision, including
 *  trivial ones resolved at Tier 1, is logged with: rule_id
 *  applied, tier of the rule, input values, output value,
 *  timestamp. Unlogged inferences are determinism violations.
 *
 *  By DarkWave Studios LLC — DarkWaveStudios.io
 *  Copyright 2026. Protected by TrustShield.tech
 * ═══════════════════════════════════════════════════════════
 */

import crypto from 'crypto'

export class InferenceAuditLog {
    constructor(config = {}) {
        this.entries = []
        this.maxEntries = config.maxEntries || 100000
        this.version = config.version || '1.0'
        this.compilerVersion = config.compilerVersion || '1.1.0'
        this.createdAt = new Date().toISOString()
        this._entryCounter = 0
    }

    /**
     * Log an inference decision.
     * @param {Object} decision
     * @param {string} decision.ruleId - ID of the rule applied (e.g., 'S-01', 'A-03', 'DEF-01')
     * @param {number} decision.tier - Tier of the rule (1-4)
     * @param {string} decision.ruleName - Human-readable rule name
     * @param {*} decision.input - Input values to the inference
     * @param {*} decision.output - Output/result of the inference
     * @param {string} decision.context - Where in the pipeline this occurred
     * @param {string} [decision.escalation] - If escalated, reason
     * @returns {Object} The logged entry with ID and hash
     */
    log(decision) {
        const entry = {
            id: `INF-${this._entryCounter++}`,
            ruleId: decision.ruleId,
            tier: decision.tier,
            tierName: this._tierName(decision.tier),
            ruleName: decision.ruleName,
            input: decision.input,
            output: decision.output,
            context: decision.context || 'unknown',
            escalation: decision.escalation || null,
            timestamp: new Date().toISOString(),
            compilerVersion: this.compilerVersion,
            ldir_version: this.version,
        }

        // Hash the entry for tamper detection
        entry.hash = crypto
            .createHash('sha256')
            .update(JSON.stringify({
                ruleId: entry.ruleId,
                tier: entry.tier,
                input: entry.input,
                output: entry.output,
                timestamp: entry.timestamp,
            }))
            .digest('hex')

        this.entries.push(entry)

        // Trim if over capacity (FIFO)
        if (this.entries.length > this.maxEntries) {
            this.entries.shift()
        }

        return entry
    }

    /**
     * Log a rulebook gap — when no rule covers an inference point.
     * This is a HALT condition per §9.8 Step 5.
     */
    logGap(inferencePoint, context) {
        return this.log({
            ruleId: 'RULEBOOK_GAP',
            tier: 0,
            ruleName: 'NO RULE FOUND — HALT',
            input: inferencePoint,
            output: 'HALTED',
            context,
            escalation: 'GATE_REQUEST — No rule covers this inference point',
        })
    }

    /**
     * Log a human override decision.
     * DEF-05: HUMAN IS FINAL — response becomes part of compilation record.
     */
    logHumanOverride(inferencePoint, humanDecision, context) {
        return this.log({
            ruleId: 'HUMAN_OVERRIDE',
            tier: 5,
            ruleName: 'HUMAN IS FINAL',
            input: inferencePoint,
            output: humanDecision,
            context,
        })
    }

    /**
     * Get all entries for a specific rule.
     */
    getByRule(ruleId) {
        return this.entries.filter(e => e.ruleId === ruleId)
    }

    /**
     * Get all entries for a specific tier.
     */
    getByTier(tier) {
        return this.entries.filter(e => e.tier === tier)
    }

    /**
     * Get all escalated entries.
     */
    getEscalations() {
        return this.entries.filter(e => e.escalation !== null)
    }

    /**
     * Get all gaps.
     */
    getGaps() {
        return this.entries.filter(e => e.ruleId === 'RULEBOOK_GAP')
    }

    /**
     * Export the full log as a JSON-serializable object.
     */
    export() {
        return {
            ldir_version: this.version,
            compilerVersion: this.compilerVersion,
            createdAt: this.createdAt,
            exportedAt: new Date().toISOString(),
            totalEntries: this.entries.length,
            tierBreakdown: {
                safety: this.entries.filter(e => e.tier === 4).length,
                axiomDerived: this.entries.filter(e => e.tier === 3).length,
                domain: this.entries.filter(e => e.tier === 2).length,
                default: this.entries.filter(e => e.tier === 1).length,
                gaps: this.entries.filter(e => e.tier === 0).length,
                humanOverrides: this.entries.filter(e => e.tier === 5).length,
            },
            entries: this.entries,
        }
    }

    /**
     * Verify integrity of the log by recomputing hashes.
     * @returns {{ valid: boolean, tampered: string[] }}
     */
    verifyIntegrity() {
        const tampered = []
        for (const entry of this.entries) {
            const expected = crypto
                .createHash('sha256')
                .update(JSON.stringify({
                    ruleId: entry.ruleId,
                    tier: entry.tier,
                    input: entry.input,
                    output: entry.output,
                    timestamp: entry.timestamp,
                }))
                .digest('hex')
            if (expected !== entry.hash) {
                tampered.push(entry.id)
            }
        }
        return { valid: tampered.length === 0, tampered }
    }

    /**
     * Clear the log.
     */
    clear() {
        this.entries = []
        this._entryCounter = 0
    }

    /**
     * Get summary stats.
     */
    stats() {
        const ruleFrequency = {}
        for (const e of this.entries) {
            ruleFrequency[e.ruleId] = (ruleFrequency[e.ruleId] || 0) + 1
        }
        return {
            totalDecisions: this.entries.length,
            uniqueRulesUsed: Object.keys(ruleFrequency).length,
            ruleFrequency,
            escalationCount: this.getEscalations().length,
            gapCount: this.getGaps().length,
        }
    }

    _tierName(tier) {
        switch (tier) {
            case 4: return 'SAFETY'
            case 3: return 'AXIOM-DERIVED'
            case 2: return 'DOMAIN'
            case 1: return 'DEFAULT'
            case 0: return 'GAP'
            case 5: return 'HUMAN-OVERRIDE'
            default: return 'UNKNOWN'
        }
    }
}

export const auditLog = new InferenceAuditLog()
export default auditLog
