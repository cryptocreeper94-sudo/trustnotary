/**
 * ═══════════════════════════════════════════════════════════
 *  LUME DETERMINISTIC INFERENCE RULEBOOK (LDIR) v1.0
 *  Main engine — resolves all inference decisions across the
 *  Lume ecosystem through a 4-tier ordered rule hierarchy.
 *
 *  Tier 4: SAFETY RULES       — Highest priority, never overridden
 *  Tier 3: AXIOM-DERIVED      — From Core Axioms AX-01–AX-07
 *  Tier 2: DOMAIN RULES       — Compiler, Runtime, Voice, Agent
 *  Tier 1: DEFAULT RULES      — Baseline tiebreakers
 *
 *  "A system is only as deterministic as its weakest inference."
 *
 *  By DarkWave Studios LLC — DarkWaveStudios.io
 *  Copyright 2026. Protected by TrustShield.tech
 * ═══════════════════════════════════════════════════════════
 */

import { SAFETY_RULES } from './rules/safety.js'
import { AXIOM_RULES } from './rules/axiom-derived.js'
import { DOMAIN_RULES } from './rules/domain.js'
import { DEFAULT_RULES } from './rules/default.js'
import { InferenceAuditLog } from './audit-log.js'

export class DeterministicRulebook {
    constructor(config = {}) {
        this.version = config.version || '1.0'
        this.compilerVersion = config.compilerVersion || '1.1.0'

        // Initialize the 4-tier rule hierarchy
        this.tiers = [
            { tier: 4, name: 'SAFETY', rules: SAFETY_RULES },
            { tier: 3, name: 'AXIOM-DERIVED', rules: AXIOM_RULES },
            { tier: 2, name: 'DOMAIN', rules: DOMAIN_RULES },
            { tier: 1, name: 'DEFAULT', rules: DEFAULT_RULES },
        ]

        // Audit log — DEF-03 mandates logging everything
        this.auditLog = config.auditLog || new InferenceAuditLog({
            version: this.version,
            compilerVersion: this.compilerVersion,
        })

        // Human decision cache for DEF-05 replay
        this.humanDecisions = config.humanDecisions || []

        // Gate request handler (for escalation)
        this.onGateRequest = config.onGateRequest || null

        // Stats
        this._resolveCount = 0
        this._haltCount = 0
        this._gapCount = 0
    }

    /**
     * Resolve an inference point through the 4-tier hierarchy.
     * This is the core entry point for ALL inference decisions in Lume.
     *
     * §9.8 Decision Flowchart:
     *   START → Tier 4 → Tier 3 → Tier 2 → Tier 1 → HALT (RULEBOOK_GAP)
     *
     * @param {*} inferencePoint - The decision that needs to be made
     * @param {Object} context - All relevant context for rule evaluation
     * @param {string} [pipelineStage] - Where in the pipeline this occurs
     * @returns {Object} resolution — { resolved, result, ruleId, tier, ... }
     */
    resolve(inferencePoint, context = {}, pipelineStage = 'unknown') {
        this._resolveCount++

        // Inject audit log state and human decisions into context
        const enrichedContext = {
            ...context,
            auditLogActive: true,
            previousHumanDecisions: this.humanDecisions,
        }

        // Walk the tiers in order: 4 → 3 → 2 → 1
        for (const { tier, name, rules } of this.tiers) {
            for (const rule of rules) {
                try {
                    const result = rule.fn(inferencePoint, enrichedContext)

                    if (result && result.applies) {
                        // Rule matched — log and return
                        const logEntry = this.auditLog.log({
                            ruleId: rule.id,
                            tier,
                            ruleName: rule.name,
                            input: this._sanitizeForLog(inferencePoint),
                            output: this._sanitizeForLog(result.output),
                            context: pipelineStage,
                            escalation: result.escalation || null,
                        })

                        // Handle escalation if needed
                        if (result.escalation && result.action === 'HALT') {
                            this._haltCount++
                            return this._handleEscalation(
                                inferencePoint, result, logEntry, pipelineStage
                            )
                        }

                        return {
                            resolved: true,
                            result: result.output,
                            action: result.action,
                            ruleId: rule.id,
                            ruleName: rule.name,
                            tier,
                            tierName: name,
                            reason: result.reason,
                            logEntryId: logEntry.id,
                        }
                    }
                } catch (err) {
                    // Rule threw an error — log it and continue to next rule
                    this.auditLog.log({
                        ruleId: rule.id,
                        tier,
                        ruleName: rule.name,
                        input: this._sanitizeForLog(inferencePoint),
                        output: { error: err.message },
                        context: pipelineStage,
                        escalation: `Rule ${rule.id} threw: ${err.message}`,
                    })
                }
            }
        }

        // No rule covered this inference — RULEBOOK GAP
        this._gapCount++
        const gapEntry = this.auditLog.logGap(
            this._sanitizeForLog(inferencePoint),
            pipelineStage
        )

        return {
            resolved: false,
            result: null,
            action: 'HALT',
            ruleId: 'RULEBOOK_GAP',
            ruleName: 'NO RULE FOUND',
            tier: 0,
            tierName: 'GAP',
            reason: 'No rule in any tier covers this inference point — HALT',
            escalation: 'GATE_REQUEST',
            logEntryId: gapEntry.id,
        }
    }

    /**
     * Resolve with a specific domain filter.
     * Only evaluates rules from the specified domain at Tier 2.
     */
    resolveForDomain(inferencePoint, context, domain, pipelineStage) {
        const filteredContext = { ...context, _domainFilter: domain }

        // Build a temporary tier set with filtered domain rules
        const originalDomain = this.tiers[2]
        const filteredRules = originalDomain.rules.filter(r => r.domain === domain)
        this.tiers[2] = { ...originalDomain, rules: filteredRules }

        const result = this.resolve(inferencePoint, filteredContext, pipelineStage)

        // Restore
        this.tiers[2] = originalDomain
        return result
    }

    /**
     * Record a human decision for future deterministic replay (DEF-05).
     */
    recordHumanDecision(inferencePoint, decision, decidedBy = 'human') {
        const entry = {
            input: inferencePoint,
            output: decision,
            timestamp: new Date().toISOString(),
            decidedBy,
        }

        this.humanDecisions.push(entry)

        this.auditLog.logHumanOverride(
            this._sanitizeForLog(inferencePoint),
            decision,
            'human_override'
        )

        return entry
    }

    /**
     * Get a specific rule by ID.
     */
    getRule(ruleId) {
        for (const { tier, name, rules } of this.tiers) {
            const rule = rules.find(r => r.id === ruleId)
            if (rule) return { ...rule, tier, tierName: name }
        }
        return null
    }

    /**
     * List all rules.
     */
    listRules() {
        const all = []
        for (const { tier, name, rules } of this.tiers) {
            for (const rule of rules) {
                all.push({
                    id: rule.id,
                    name: rule.name,
                    tier,
                    tierName: name,
                    domain: rule.domain || null,
                    sourceAxiom: rule.sourceAxiom || null,
                })
            }
        }
        return all
    }

    /**
     * Get rulebook statistics.
     */
    stats() {
        const allRules = this.listRules()
        return {
            version: this.version,
            compilerVersion: this.compilerVersion,
            totalRules: allRules.length,
            byTier: {
                safety: allRules.filter(r => r.tier === 4).length,
                axiomDerived: allRules.filter(r => r.tier === 3).length,
                domain: allRules.filter(r => r.tier === 2).length,
                default: allRules.filter(r => r.tier === 1).length,
            },
            byDomain: {
                compiler: allRules.filter(r => r.domain === 'compiler').length,
                runtime: allRules.filter(r => r.domain === 'runtime').length,
                voice: allRules.filter(r => r.domain === 'voice').length,
                agent: allRules.filter(r => r.domain === 'agent').length,
            },
            performance: {
                totalResolves: this._resolveCount,
                halts: this._haltCount,
                gaps: this._gapCount,
                resolutionRate: this._resolveCount > 0
                    ? ((this._resolveCount - this._haltCount - this._gapCount) / this._resolveCount * 100).toFixed(1) + '%'
                    : 'N/A',
            },
            auditLog: this.auditLog.stats(),
            humanDecisions: this.humanDecisions.length,
        }
    }

    /**
     * Export the complete rulebook state for deterministic re-creation.
     * DEF-04: Version pinning means this export captures everything
     * needed to reproduce behavior.
     */
    export() {
        return {
            version: this.version,
            compilerVersion: this.compilerVersion,
            rules: this.listRules(),
            humanDecisions: this.humanDecisions,
            auditLog: this.auditLog.export(),
            exportedAt: new Date().toISOString(),
        }
    }

    // ── Private ──

    _handleEscalation(inferencePoint, result, logEntry, pipelineStage) {
        if (this.onGateRequest) {
            // Invoke the gate request handler
            const gateRequest = {
                gateId: logEntry.id,
                inferencePoint: this._sanitizeForLog(inferencePoint),
                ruleId: result.ruleId,
                reason: result.reason,
                pipelineStage,
                options: ['APPROVE', 'DENY', 'MODIFY', 'DEFER'],
                timestamp: new Date().toISOString(),
            }

            try {
                const response = this.onGateRequest(gateRequest)
                if (response) {
                    this.recordHumanDecision(inferencePoint, response, 'gate_response')
                    return {
                        resolved: true,
                        result: response,
                        action: 'HUMAN_OVERRIDE',
                        ruleId: result.ruleId,
                        ruleName: result.ruleName,
                        tier: result.tier || 4,
                        tierName: 'ESCALATED',
                        reason: `Escalated via ${result.ruleId} — human responded`,
                        logEntryId: logEntry.id,
                    }
                }
            } catch {
                // Gate handler failed — fall through to HALT
            }
        }

        // No gate handler or it failed — HALT
        return {
            resolved: false,
            result: null,
            action: 'HALT',
            ruleId: result.ruleId,
            ruleName: result.ruleName,
            tier: 4,
            tierName: 'ESCALATED',
            reason: result.reason,
            escalation: result.escalation,
            logEntryId: logEntry.id,
        }
    }

    _sanitizeForLog(value) {
        if (value === undefined || value === null) return value
        if (typeof value === 'string') {
            return value.length > 500 ? value.slice(0, 500) + '...' : value
        }
        if (typeof value === 'object') {
            try {
                const str = JSON.stringify(value)
                if (str.length > 1000) {
                    return JSON.parse(str.slice(0, 1000) + '..."}}')
                }
                return value
            } catch {
                return String(value)
            }
        }
        return value
    }
}

// ── Singleton ──
export const rulebook = new DeterministicRulebook()
export default rulebook
