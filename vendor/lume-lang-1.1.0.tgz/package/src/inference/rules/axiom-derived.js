/**
 * ═══════════════════════════════════════════════════════════
 *  LDIR TIER 3: AXIOM-DERIVED RULES
 *  Derived from Core Axioms AX-01 through AX-07.
 *
 *  A-01: DETERMINISM TIEBREAKER (AX-01)
 *  A-02: INTENT PRIMACY (AX-02)
 *  A-03: COMPILE-TIME TRUST BINDING (AX-03)
 *  A-04: VOICE EQUIVALENCE (AX-04)
 *  A-05: ORGANISM BOUNDEDNESS (AX-05)
 *  A-06: NATIVE LANGUAGE NEUTRALITY (AX-06)
 *  A-07: TIMESTAMP AUTHORITY (AX-07)
 *
 *  By DarkWave Studios LLC — DarkWaveStudios.io
 *  Copyright 2026. Protected by TrustShield.tech
 * ═══════════════════════════════════════════════════════════
 */

import crypto from 'crypto'

/**
 * A-01: DETERMINISM TIEBREAKER (AX-01)
 * When two semantically valid interpretations produce different outputs,
 * select the one with the LOWER canonical SHA-256 hash.
 * Arbitrary but reproducible.
 */
export function determinismTiebreaker(inferencePoint, context) {
    const { candidates } = context

    if (!candidates || !Array.isArray(candidates) || candidates.length < 2) {
        return { applies: false }
    }

    // Check if this is actually a tie (multiple valid candidates)
    if (candidates.length === 1) {
        return { applies: false }
    }

    // Sort candidates by SHA-256 hash of their normalized string representation
    const hashed = candidates.map(c => {
        const normalized = typeof c === 'string' ? c : JSON.stringify(c)
        const hash = crypto
            .createHash('sha256')
            .update(normalized)
            .digest('hex')
        return { candidate: c, hash, normalized }
    })

    hashed.sort((a, b) => a.hash.localeCompare(b.hash))

    return {
        applies: true,
        action: 'SELECT',
        ruleId: 'A-01',
        ruleName: 'DETERMINISM TIEBREAKER',
        reason: `${candidates.length} tied candidates — selecting by lowest SHA-256 hash`,
        output: {
            selected: hashed[0].candidate,
            selectedHash: hashed[0].hash,
            allHashes: hashed.map(h => ({ hash: h.hash.slice(0, 16) + '...', candidate: h.normalized.slice(0, 50) })),
        },
    }
}

/**
 * A-02: INTENT PRIMACY (AX-02)
 * When compiler internals suggest a resolution that differs from
 * the NL-implied resolution, the NL-implied resolution wins.
 */
export function intentPrimacy(inferencePoint, context) {
    const { nlImpliedResolution, compilerResolution } = context

    if (!nlImpliedResolution || !compilerResolution) {
        return { applies: false }
    }

    // Compare the two resolutions
    const nlStr = typeof nlImpliedResolution === 'string'
        ? nlImpliedResolution
        : JSON.stringify(nlImpliedResolution)
    const compStr = typeof compilerResolution === 'string'
        ? compilerResolution
        : JSON.stringify(compilerResolution)

    if (nlStr === compStr) {
        return { applies: false }
    }

    return {
        applies: true,
        action: 'SELECT',
        ruleId: 'A-02',
        ruleName: 'INTENT PRIMACY',
        reason: 'NL-implied resolution differs from compiler resolution — NL wins',
        output: {
            selected: nlImpliedResolution,
            rejected: compilerResolution,
            source: 'nl_implied',
        },
    }
}

/**
 * A-03: COMPILE-TIME TRUST BINDING (AX-03)
 * When a security property could be enforced at compile time OR deferred
 * to runtime, the compile-time enforcement path is selected.
 */
export function compileTimeTrustBinding(inferencePoint, context) {
    const { compileTimeEnforcement, runtimeEnforcement } = context

    if (!compileTimeEnforcement || !runtimeEnforcement) {
        return { applies: false }
    }

    // Both exist — compile-time always wins
    return {
        applies: true,
        action: 'SELECT',
        ruleId: 'A-03',
        ruleName: 'COMPILE-TIME TRUST BINDING',
        reason: 'Security property can be enforced at compile time — selecting compile-time path',
        output: {
            selected: compileTimeEnforcement,
            rejected: runtimeEnforcement,
            enforcementPoint: 'compile-time',
        },
    }
}

/**
 * A-04: VOICE EQUIVALENCE (AX-04)
 * After normalization, if a voice-derived token sequence and a text-derived
 * token sequence are identical, they MUST produce identical compilation outputs.
 */
export function voiceEquivalence(inferencePoint, context) {
    const { voiceTokens, textTokens, voiceResult, textResult } = context

    if (!voiceTokens || !textTokens) {
        return { applies: false }
    }

    const voiceStr = JSON.stringify(voiceTokens)
    const textStr = JSON.stringify(textTokens)

    // Tokens are identical — results must be identical
    if (voiceStr === textStr && voiceResult !== undefined && textResult !== undefined) {
        const voiceResultStr = JSON.stringify(voiceResult)
        const textResultStr = JSON.stringify(textResult)

        if (voiceResultStr !== textResultStr) {
            return {
                applies: true,
                action: 'ENFORCE',
                ruleId: 'A-04',
                ruleName: 'VOICE EQUIVALENCE',
                reason: 'Identical token sequences from voice and text produced different results — enforcing text result for both',
                output: {
                    enforced: textResult,
                    violation: 'voice_text_divergence',
                    tokens: voiceStr.slice(0, 100),
                },
            }
        }
    }

    return { applies: false }
}

/**
 * A-05: ORGANISM BOUNDEDNESS (AX-05)
 * When the runtime must infer resource allocation for a cell,
 * the inference must produce a BOUNDED result. Unbounded allocation
 * is never a valid inference outcome.
 */
export function organismBoundedness(inferencePoint, context) {
    const { resourceAllocation, deploymentDefaults } = context

    if (!resourceAllocation) {
        return { applies: false }
    }

    const { memory, cpu, connections, duration } = resourceAllocation

    // Check for unbounded values
    const unbounded = []
    if (memory === Infinity || memory === undefined || memory === null) unbounded.push('memory')
    if (cpu === Infinity || cpu === undefined || cpu === null) unbounded.push('cpu')
    if (connections === Infinity || connections === undefined || connections === null) unbounded.push('connections')
    if (duration === Infinity || duration === undefined || duration === null) unbounded.push('duration')

    if (unbounded.length === 0) {
        return { applies: false }
    }

    // Apply deployment defaults for unbounded resources
    const defaults = deploymentDefaults || {
        memory: 256 * 1024 * 1024,  // 256MB
        cpu: 1.0,                     // 1 core
        connections: 100,             // 100 connections
        duration: 300000,             // 5 minutes
    }

    const bounded = { ...resourceAllocation }
    for (const field of unbounded) {
        bounded[field] = defaults[field]
    }

    return {
        applies: true,
        action: 'BOUND',
        ruleId: 'A-05',
        ruleName: 'ORGANISM BOUNDEDNESS',
        reason: `Unbounded resource allocation detected for: ${unbounded.join(', ')} — applying deployment defaults`,
        output: {
            original: resourceAllocation,
            bounded,
            defaultsApplied: unbounded,
        },
    }
}

/**
 * A-06: NATIVE LANGUAGE NEUTRALITY (AX-06)
 * When resolving ambiguity in multilingual intent, no language receives
 * preferential treatment. English is not a tiebreaker.
 */
export function nativeLanguageNeutrality(inferencePoint, context) {
    const { candidatesByLanguage, preferredLanguage } = context

    if (!candidatesByLanguage || typeof candidatesByLanguage !== 'object') {
        return { applies: false }
    }

    const languages = Object.keys(candidatesByLanguage)
    if (languages.length < 2) {
        return { applies: false }
    }

    // Check if any language is being given preferential treatment
    if (preferredLanguage && languages.includes(preferredLanguage)) {
        return {
            applies: true,
            action: 'NEUTRALIZE',
            ruleId: 'A-06',
            ruleName: 'NATIVE LANGUAGE NEUTRALITY',
            reason: `Language preference "${preferredLanguage}" detected — all languages must map to universal Intent IR with equal authority`,
            output: {
                violation: 'language_preference_detected',
                languages,
                correctedTo: 'equal_authority',
            },
        }
    }

    return { applies: false }
}

/**
 * A-07: TIMESTAMP AUTHORITY (AX-07)
 * When two artifacts or certificates conflict on temporal ordering,
 * the cryptographically-timestamped record takes precedence.
 * Authority: (1) cryptographic timestamp service, (2) compilation timestamp, (3) system clock.
 */
export function timestampAuthority(inferencePoint, context) {
    const { timestamps } = context

    if (!timestamps || !Array.isArray(timestamps) || timestamps.length < 2) {
        return { applies: false }
    }

    // Classify each timestamp by authority
    const classified = timestamps.map(ts => ({
        ...ts,
        authority: ts.cryptographic ? 1 : ts.compilation ? 2 : 3,
        authorityName: ts.cryptographic ? 'cryptographic' : ts.compilation ? 'compilation' : 'system_clock',
    }))

    // Sort by authority (lower = higher authority), then by timestamp value
    classified.sort((a, b) => {
        if (a.authority !== b.authority) return a.authority - b.authority
        return new Date(a.value).getTime() - new Date(b.value).getTime()
    })

    // If highest-authority timestamps disagree with lower-authority ones
    const topAuthority = classified[0].authority
    const topTimestamps = classified.filter(t => t.authority === topAuthority)

    return {
        applies: true,
        action: 'SELECT',
        ruleId: 'A-07',
        ruleName: 'TIMESTAMP AUTHORITY',
        reason: `Temporal ordering resolved by ${classified[0].authorityName} timestamp authority`,
        output: {
            authoritative: topTimestamps[0],
            allTimestamps: classified,
            authorityHierarchy: ['cryptographic', 'compilation', 'system_clock'],
        },
    }
}

// Export all axiom-derived rules
export const AXIOM_RULES = [
    { id: 'A-01', name: 'DETERMINISM TIEBREAKER', fn: determinismTiebreaker, sourceAxiom: 'AX-01' },
    { id: 'A-02', name: 'INTENT PRIMACY', fn: intentPrimacy, sourceAxiom: 'AX-02' },
    { id: 'A-03', name: 'COMPILE-TIME TRUST BINDING', fn: compileTimeTrustBinding, sourceAxiom: 'AX-03' },
    { id: 'A-04', name: 'VOICE EQUIVALENCE', fn: voiceEquivalence, sourceAxiom: 'AX-04' },
    { id: 'A-05', name: 'ORGANISM BOUNDEDNESS', fn: organismBoundedness, sourceAxiom: 'AX-05' },
    { id: 'A-06', name: 'NATIVE LANGUAGE NEUTRALITY', fn: nativeLanguageNeutrality, sourceAxiom: 'AX-06' },
    { id: 'A-07', name: 'TIMESTAMP AUTHORITY', fn: timestampAuthority, sourceAxiom: 'AX-07' },
]

export default AXIOM_RULES
