/**
 * ═══════════════════════════════════════════════════════════
 *  LDIR TIER 1: DEFAULT RULES
 *  Baseline tiebreakers — lowest priority.
 *
 *  DEF-01: LEXICOGRAPHIC TIEBREAKER
 *  DEF-02: DENY BY DEFAULT
 *  DEF-03: LOG EVERYTHING
 *  DEF-04: VERSION PINNING
 *  DEF-05: HUMAN IS FINAL
 *
 *  By DarkWave Studios LLC — DarkWaveStudios.io
 *  Copyright 2026. Protected by TrustShield.tech
 * ═══════════════════════════════════════════════════════════
 */

/**
 * DEF-01: LEXICOGRAPHIC TIEBREAKER
 * When no higher-tier rule resolves a tie, select the option whose
 * canonical string representation (UTF-8, NFC-normalized) sorts first.
 */
export function lexicographicTiebreaker(inferencePoint, context) {
    const { options } = context

    if (!options || !Array.isArray(options) || options.length < 2) {
        return { applies: false }
    }

    // NFC-normalize and sort lexicographically
    const normalized = options.map(o => {
        const str = typeof o === 'string' ? o : JSON.stringify(o)
        return { original: o, normalized: str.normalize('NFC') }
    })

    normalized.sort((a, b) => a.normalized.localeCompare(b.normalized))

    return {
        applies: true,
        action: 'SELECT',
        ruleId: 'DEF-01',
        ruleName: 'LEXICOGRAPHIC TIEBREAKER',
        reason: `${options.length} options tied — selecting first in lexicographic (NFC) order`,
        output: {
            selected: normalized[0].original,
            method: 'utf8_nfc_lexicographic',
            optionCount: options.length,
        },
    }
}

/**
 * DEF-02: DENY BY DEFAULT
 * When no rule explicitly grants a permission, capability, or resource allocation,
 * the default is DENY.
 */
export function denyByDefault(inferencePoint, context) {
    const { requestType, explicitlyGranted } = context

    if (explicitlyGranted === true) {
        return { applies: false }
    }

    // If we reach this rule, nothing above granted the request
    return {
        applies: true,
        action: 'DENY',
        ruleId: 'DEF-02',
        ruleName: 'DENY BY DEFAULT',
        reason: `No rule explicitly grants "${requestType || 'unknown'}" — defaulting to DENY`,
        output: {
            denied: true,
            requestType: requestType || 'unknown',
            reason: 'no_explicit_grant',
        },
    }
}

/**
 * DEF-03: LOG EVERYTHING
 * Every inference decision is logged to the Audit Ledger.
 * This rule is enforced by the Rulebook engine itself, not as a filter.
 * This function validates that logging is active.
 */
export function logEverything(inferencePoint, context) {
    const { auditLogActive } = context

    if (auditLogActive === false) {
        return {
            applies: true,
            action: 'HALT',
            ruleId: 'DEF-03',
            ruleName: 'LOG EVERYTHING',
            reason: 'Audit logging is disabled — this is a determinism violation. Cannot proceed without logging.',
            output: { violation: 'audit_log_disabled' },
        }
    }

    return { applies: false }
}

/**
 * DEF-04: VERSION PINNING
 * All inference rules are versioned with the compiler/runtime release.
 * Programs compiled with version X use rulebook version X.
 */
export function versionPinning(inferencePoint, context) {
    const { compiledWithVersion, currentVersion } = context

    if (!compiledWithVersion || !currentVersion) {
        return { applies: false }
    }

    if (compiledWithVersion !== currentVersion) {
        return {
            applies: true,
            action: 'PIN',
            ruleId: 'DEF-04',
            ruleName: 'VERSION PINNING',
            reason: `Program compiled with v${compiledWithVersion} but running on v${currentVersion} — using pinned rulebook v${compiledWithVersion}`,
            output: {
                pinnedVersion: compiledWithVersion,
                currentVersion,
                action: 'use_compiled_rulebook',
            },
        }
    }

    return { applies: false }
}

/**
 * DEF-05: HUMAN IS FINAL
 * When an inference is escalated to a human, the response is logged as
 * a HUMAN_OVERRIDE rule instance. This response is reproduced deterministically
 * in re-compilation — the human is not asked twice for the same input.
 */
export function humanIsFinal(inferencePoint, context) {
    const { previousHumanDecisions } = context

    if (!previousHumanDecisions || !Array.isArray(previousHumanDecisions)) {
        return { applies: false }
    }

    // Check if there's a previous human decision for this exact inference point
    const pointKey = typeof inferencePoint === 'string'
        ? inferencePoint
        : JSON.stringify(inferencePoint)

    const previousDecision = previousHumanDecisions.find(d =>
        (typeof d.input === 'string' ? d.input : JSON.stringify(d.input)) === pointKey
    )

    if (previousDecision) {
        return {
            applies: true,
            action: 'REPLAY',
            ruleId: 'DEF-05',
            ruleName: 'HUMAN IS FINAL',
            reason: 'Previous human decision found for this inference point — replaying deterministically',
            output: {
                humanDecision: previousDecision.output,
                decidedAt: previousDecision.timestamp,
                decidedBy: previousDecision.decidedBy || 'human',
                replayed: true,
            },
        }
    }

    return { applies: false }
}

// Export all default rules
export const DEFAULT_RULES = [
    { id: 'DEF-01', name: 'LEXICOGRAPHIC TIEBREAKER', fn: lexicographicTiebreaker },
    { id: 'DEF-02', name: 'DENY BY DEFAULT', fn: denyByDefault },
    { id: 'DEF-03', name: 'LOG EVERYTHING', fn: logEverything },
    { id: 'DEF-04', name: 'VERSION PINNING', fn: versionPinning },
    { id: 'DEF-05', name: 'HUMAN IS FINAL', fn: humanIsFinal },
]

export default DEFAULT_RULES
