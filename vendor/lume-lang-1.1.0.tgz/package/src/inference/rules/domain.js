/**
 * ═══════════════════════════════════════════════════════════
 *  LDIR TIER 2: DOMAIN RULES
 *  Language-specific, modality-specific inference rules.
 *
 *  COMPILER DOMAIN: D-CMPL-01 through D-CMPL-04
 *  RUNTIME DOMAIN:  D-SOR-01 through D-SOR-04
 *  VOICE DOMAIN:    D-VOX-01 through D-VOX-03
 *  AGENT DOMAIN:    D-AGT-01 through D-AGT-03
 *
 *  By DarkWave Studios LLC — DarkWaveStudios.io
 *  Copyright 2026. Protected by TrustShield.tech
 * ═══════════════════════════════════════════════════════════
 */

import crypto from 'crypto'

// ═══════════════════════════════════════════
//  COMPILER DOMAIN
// ═══════════════════════════════════════════

/**
 * D-CMPL-01: TOKENIZATION DETERMINISM
 * NL tokenization must use a frozen tokenizer model versioned and locked
 * at compiler release. f(input, version) = tokens, always.
 */
export function tokenizationDeterminism(inferencePoint, context) {
    const { tokenizerVersion, inputText, expectedVersion } = context

    if (!tokenizerVersion || !expectedVersion) {
        return { applies: false }
    }

    if (tokenizerVersion !== expectedVersion) {
        return {
            applies: true,
            action: 'HALT',
            ruleId: 'D-CMPL-01',
            ruleName: 'TOKENIZATION DETERMINISM',
            reason: `Tokenizer version mismatch: expected ${expectedVersion}, got ${tokenizerVersion} — determinism compromised`,
            output: { expected: expectedVersion, actual: tokenizerVersion },
        }
    }

    return { applies: false }
}

/**
 * D-CMPL-02: AST NODE ORDERING
 * Use depth-first left-to-right ordering matching the surface-form word order.
 * For non-left-to-right languages, use the language's canonical reading order.
 */
export function astNodeOrdering(inferencePoint, context) {
    const { nodes, language } = context

    if (!nodes || !Array.isArray(nodes) || nodes.length < 2) {
        return { applies: false }
    }

    // Determine reading direction
    const rtlLanguages = new Set(['ar', 'he', 'fa', 'ur'])
    const isRTL = rtlLanguages.has(language)

    // Sort nodes by their source position
    const sorted = [...nodes].sort((a, b) => {
        // Primary: line number
        if (a.line !== b.line) return a.line - b.line
        // Secondary: column — LTR ascending, RTL descending
        if (isRTL) return b.column - a.column
        return a.column - b.column
    })

    const orderChanged = JSON.stringify(sorted.map(n => n.id)) !== JSON.stringify(nodes.map(n => n.id))

    if (orderChanged) {
        return {
            applies: true,
            action: 'REORDER',
            ruleId: 'D-CMPL-02',
            ruleName: 'AST NODE ORDERING',
            reason: `Nodes reordered to ${isRTL ? 'right-to-left' : 'depth-first left-to-right'} canonical order`,
            output: {
                original: nodes.map(n => n.id),
                reordered: sorted.map(n => n.id),
                readingDirection: isRTL ? 'rtl' : 'ltr',
                language,
            },
        }
    }

    return { applies: false }
}

/**
 * D-CMPL-03: AMBIGUITY ORACLE RULE CASCADE
 * Fixed 6-level cascade. Stops at the first level that produces a unique resolution.
 *
 * Level 1: Syntactic disambiguation (grammar rules)
 * Level 2: Semantic disambiguation (ontology lookup)
 * Level 3: Contextual disambiguation (compilation-unit scope)
 * Level 4: Pragmatic disambiguation (usage-pattern database)
 * Level 5: Deterministic tiebreaker (A-01 hash comparison)
 * Level 6: Human escalation (GATE_REQUEST)
 */
export function ambiguityOracleCascade(inferencePoint, context) {
    const { ambiguousCandidates, syntacticResult, semanticResult,
            contextualResult, pragmaticResult } = context

    if (!ambiguousCandidates || ambiguousCandidates.length < 2) {
        return { applies: false }
    }

    // Level 1: Syntactic
    if (syntacticResult && syntacticResult.unique) {
        return {
            applies: true,
            action: 'RESOLVE',
            ruleId: 'D-CMPL-03',
            ruleName: 'AMBIGUITY ORACLE CASCADE',
            reason: 'Resolved at Level 1 (syntactic disambiguation)',
            output: {
                level: 1,
                levelName: 'syntactic',
                resolved: syntacticResult.value,
                candidateCount: ambiguousCandidates.length,
            },
        }
    }

    // Level 2: Semantic
    if (semanticResult && semanticResult.unique) {
        return {
            applies: true,
            action: 'RESOLVE',
            ruleId: 'D-CMPL-03',
            ruleName: 'AMBIGUITY ORACLE CASCADE',
            reason: 'Resolved at Level 2 (semantic disambiguation)',
            output: {
                level: 2,
                levelName: 'semantic',
                resolved: semanticResult.value,
                candidateCount: ambiguousCandidates.length,
            },
        }
    }

    // Level 3: Contextual
    if (contextualResult && contextualResult.unique) {
        return {
            applies: true,
            action: 'RESOLVE',
            ruleId: 'D-CMPL-03',
            ruleName: 'AMBIGUITY ORACLE CASCADE',
            reason: 'Resolved at Level 3 (contextual disambiguation)',
            output: {
                level: 3,
                levelName: 'contextual',
                resolved: contextualResult.value,
                candidateCount: ambiguousCandidates.length,
            },
        }
    }

    // Level 4: Pragmatic
    if (pragmaticResult && pragmaticResult.unique) {
        return {
            applies: true,
            action: 'RESOLVE',
            ruleId: 'D-CMPL-03',
            ruleName: 'AMBIGUITY ORACLE CASCADE',
            reason: 'Resolved at Level 4 (pragmatic disambiguation)',
            output: {
                level: 4,
                levelName: 'pragmatic',
                resolved: pragmaticResult.value,
                candidateCount: ambiguousCandidates.length,
            },
        }
    }

    // Level 5: SHA-256 tiebreaker (delegates to A-01)
    // Compute hash for each remaining candidate and pick the lowest
    const hashed = ambiguousCandidates.map(c => {
        const str = typeof c === 'string' ? c : JSON.stringify(c)
        return {
            candidate: c,
            hash: crypto.createHash('sha256').update(str).digest('hex'),
        }
    })
    hashed.sort((a, b) => a.hash.localeCompare(b.hash))

    return {
        applies: true,
        action: 'RESOLVE',
        ruleId: 'D-CMPL-03',
        ruleName: 'AMBIGUITY ORACLE CASCADE',
        reason: 'Resolved at Level 5 (deterministic SHA-256 tiebreaker)',
        output: {
            level: 5,
            levelName: 'deterministic_tiebreaker',
            resolved: hashed[0].candidate,
            selectedHash: hashed[0].hash.slice(0, 16) + '...',
            candidateCount: ambiguousCandidates.length,
        },
    }
}

/**
 * D-CMPL-04: OPTIMIZATION PASS ORDERING
 * Fixed, versioned sequence. No adaptive reordering.
 */
export function optimizationPassOrdering(inferencePoint, context) {
    const { requestedOrder } = context

    const CANONICAL_ORDER = [
        'constant_folding',
        'dead_intent_elimination',
        'intent_inlining',
        'trust_proof_propagation',
        'code_emission_preparation',
    ]

    if (!requestedOrder || !Array.isArray(requestedOrder)) {
        return { applies: false }
    }

    const requestedStr = JSON.stringify(requestedOrder)
    const canonicalStr = JSON.stringify(CANONICAL_ORDER)

    if (requestedStr !== canonicalStr) {
        return {
            applies: true,
            action: 'ENFORCE',
            ruleId: 'D-CMPL-04',
            ruleName: 'OPTIMIZATION PASS ORDERING',
            reason: 'Optimization pass order deviates from canonical sequence — enforcing fixed order',
            output: {
                enforced: CANONICAL_ORDER,
                requested: requestedOrder,
            },
        }
    }

    return { applies: false }
}

// ═══════════════════════════════════════════
//  RUNTIME DOMAIN
// ═══════════════════════════════════════════

/**
 * D-SOR-01: CELL SCHEDULING DETERMINISM
 * When multiple cells share the same priority, schedule by cell_id
 * (UUID v7 temporal ordering).
 */
export function cellSchedulingDeterminism(inferencePoint, context) {
    const { readyCells } = context

    if (!readyCells || readyCells.length < 2) {
        return { applies: false }
    }

    // Check if cells share priority
    const priorities = new Set(readyCells.map(c => c.priority))
    if (priorities.size === readyCells.length) {
        return { applies: false }
    }

    // Sort by priority (ascending), then by cell_id (lexicographic for UUID v7 temporal)
    const sorted = [...readyCells].sort((a, b) => {
        if (a.priority !== b.priority) return a.priority - b.priority
        return a.cellId.localeCompare(b.cellId)
    })

    return {
        applies: true,
        action: 'ORDER',
        ruleId: 'D-SOR-01',
        ruleName: 'CELL SCHEDULING DETERMINISM',
        reason: 'Cells with equal priority ordered by cell_id (UUID v7 temporal ordering)',
        output: {
            order: sorted.map(c => c.cellId),
            method: 'uuid_v7_temporal',
        },
    }
}

/**
 * D-SOR-02: SIGNAL DELIVERY ORDER
 * Signals delivered in timestamp order. Ties broken by sender cell_id (lexicographic).
 */
export function signalDeliveryOrder(inferencePoint, context) {
    const { pendingSignals } = context

    if (!pendingSignals || pendingSignals.length < 2) {
        return { applies: false }
    }

    const sorted = [...pendingSignals].sort((a, b) => {
        const timeA = new Date(a.timestamp).getTime()
        const timeB = new Date(b.timestamp).getTime()
        if (timeA !== timeB) return timeA - timeB
        return a.senderId.localeCompare(b.senderId)
    })

    return {
        applies: true,
        action: 'ORDER',
        ruleId: 'D-SOR-02',
        ruleName: 'SIGNAL DELIVERY ORDER',
        reason: 'Signals ordered by timestamp, ties broken by sender cell_id',
        output: {
            order: sorted.map(s => s.id || s.senderId),
            method: 'timestamp_then_sender_id',
        },
    }
}

/**
 * D-SOR-03: HOMEOSTASIS THRESHOLD INFERENCE
 * threshold = deployment_default × safety_factor (0.8)
 * Fixed formula, not adaptive.
 */
export function homeostasisThresholdInference(inferencePoint, context) {
    const { resourceType, deploymentDefault, configuredThreshold } = context

    if (!resourceType || configuredThreshold !== undefined) {
        return { applies: false }
    }

    if (!deploymentDefault) {
        return { applies: false }
    }

    const SAFETY_FACTOR = 0.8
    const threshold = deploymentDefault * SAFETY_FACTOR

    return {
        applies: true,
        action: 'COMPUTE',
        ruleId: 'D-SOR-03',
        ruleName: 'HOMEOSTASIS THRESHOLD INFERENCE',
        reason: `No configured threshold for ${resourceType} — computing: ${deploymentDefault} × ${SAFETY_FACTOR} = ${threshold}`,
        output: {
            resourceType,
            deploymentDefault,
            safetyFactor: SAFETY_FACTOR,
            computedThreshold: threshold,
        },
    }
}

/**
 * D-SOR-04: ROLLBACK SCOPE
 * Minimum set of cells affected by the triggering event.
 * Computed from Signal Bus propagation graph.
 */
export function rollbackScope(inferencePoint, context) {
    const { triggeringCellId, propagationGraph, allCells } = context

    if (!triggeringCellId || !propagationGraph) {
        return { applies: false }
    }

    // BFS from the triggering cell through the propagation graph
    const affected = new Set()
    const queue = [triggeringCellId]
    affected.add(triggeringCellId)

    while (queue.length > 0) {
        const current = queue.shift()
        const neighbors = propagationGraph[current] || []
        for (const neighbor of neighbors) {
            if (!affected.has(neighbor)) {
                affected.add(neighbor)
                queue.push(neighbor)
            }
        }
    }

    return {
        applies: true,
        action: 'SCOPE',
        ruleId: 'D-SOR-04',
        ruleName: 'ROLLBACK SCOPE',
        reason: `Minimum rollback scope: ${affected.size} cells affected (of ${allCells?.length || 'unknown'} total)`,
        output: {
            triggeringCell: triggeringCellId,
            affectedCells: [...affected],
            totalCells: allCells?.length || null,
            method: 'signal_bus_propagation_bfs',
        },
    }
}

// ═══════════════════════════════════════════
//  VOICE DOMAIN
// ═══════════════════════════════════════════

/**
 * D-VOX-01: ASR CANDIDATE SELECTION
 * Discard below 0.85 confidence. Among remaining, select lowest SHA-256 hash.
 * If none meet threshold, reject the utterance.
 */
export function asrCandidateSelection(inferencePoint, context) {
    const { candidates } = context

    if (!candidates || !Array.isArray(candidates) || candidates.length === 0) {
        return { applies: false }
    }

    const CONFIDENCE_THRESHOLD = 0.85

    // Filter by confidence
    const qualifying = candidates.filter(c => c.confidence >= CONFIDENCE_THRESHOLD)

    if (qualifying.length === 0) {
        return {
            applies: true,
            action: 'REJECT',
            ruleId: 'D-VOX-01',
            ruleName: 'ASR CANDIDATE SELECTION',
            reason: `No candidates meet confidence threshold ${CONFIDENCE_THRESHOLD} — rejecting utterance`,
            output: {
                rejected: true,
                threshold: CONFIDENCE_THRESHOLD,
                bestConfidence: Math.max(...candidates.map(c => c.confidence)),
                candidateCount: candidates.length,
            },
        }
    }

    if (qualifying.length === 1) {
        return {
            applies: true,
            action: 'SELECT',
            ruleId: 'D-VOX-01',
            ruleName: 'ASR CANDIDATE SELECTION',
            reason: 'Single candidate above confidence threshold',
            output: { selected: qualifying[0], method: 'single_qualifying' },
        }
    }

    // Multiple qualifying — select by lowest SHA-256 hash of normalized text
    const hashed = qualifying.map(c => ({
        ...c,
        hash: crypto.createHash('sha256')
            .update(c.normalized || c.text || '')
            .digest('hex'),
    }))
    hashed.sort((a, b) => a.hash.localeCompare(b.hash))

    return {
        applies: true,
        action: 'SELECT',
        ruleId: 'D-VOX-01',
        ruleName: 'ASR CANDIDATE SELECTION',
        reason: `${qualifying.length} candidates above threshold — selecting by lowest SHA-256 hash`,
        output: {
            selected: hashed[0],
            method: 'sha256_tiebreaker',
            qualifyingCount: qualifying.length,
        },
    }
}

/**
 * D-VOX-02: NORMALIZATION IDEMPOTENCY
 * normalize(normalize(x)) == normalize(x) for all inputs.
 */
export function normalizationIdempotency(inferencePoint, context) {
    const { normalizeFunction, testInput } = context

    if (!normalizeFunction || testInput === undefined) {
        return { applies: false }
    }

    const once = normalizeFunction(testInput)
    const twice = normalizeFunction(once)

    if (JSON.stringify(once) !== JSON.stringify(twice)) {
        return {
            applies: true,
            action: 'HALT',
            ruleId: 'D-VOX-02',
            ruleName: 'NORMALIZATION IDEMPOTENCY',
            reason: 'Normalization function is NOT idempotent — f(f(x)) ≠ f(x)',
            output: {
                input: testInput,
                firstPass: once,
                secondPass: twice,
                violation: true,
            },
        }
    }

    return { applies: false }
}

/**
 * D-VOX-03: SILENCE HANDLING
 * Silence > 3.0s = UTTERANCE_END. Silence < 3.0s = stripped during normalization.
 * Fixed threshold, not adaptive.
 */
export function silenceHandling(inferencePoint, context) {
    const { silenceDuration } = context

    if (silenceDuration === undefined || silenceDuration === null) {
        return { applies: false }
    }

    const THRESHOLD = 3.0  // seconds

    if (silenceDuration >= THRESHOLD) {
        return {
            applies: true,
            action: 'INTERPRET',
            ruleId: 'D-VOX-03',
            ruleName: 'SILENCE HANDLING',
            reason: `Silence ${silenceDuration}s >= ${THRESHOLD}s threshold — interpreted as UTTERANCE_END`,
            output: {
                interpretation: 'UTTERANCE_END',
                duration: silenceDuration,
                threshold: THRESHOLD,
            },
        }
    }

    return {
        applies: true,
        action: 'STRIP',
        ruleId: 'D-VOX-03',
        ruleName: 'SILENCE HANDLING',
        reason: `Silence ${silenceDuration}s < ${THRESHOLD}s threshold — stripped during normalization`,
        output: {
            interpretation: 'STRIPPED',
            duration: silenceDuration,
            threshold: THRESHOLD,
        },
    }
}

// ═══════════════════════════════════════════
//  AGENT DOMAIN
// ═══════════════════════════════════════════

/**
 * D-AGT-01: TASK DELEGATION DETERMINISM
 * When agents have equivalent capability/trust, delegate by agent_id
 * (UUID v7 temporal ordering).
 */
export function taskDelegationDeterminism(inferencePoint, context) {
    const { eligibleAgents } = context

    if (!eligibleAgents || eligibleAgents.length < 2) {
        return { applies: false }
    }

    const sorted = [...eligibleAgents].sort((a, b) =>
        a.agentId.localeCompare(b.agentId)
    )

    return {
        applies: true,
        action: 'ORDER',
        ruleId: 'D-AGT-01',
        ruleName: 'TASK DELEGATION DETERMINISM',
        reason: 'Equivalent agents ordered by agent_id (UUID v7 temporal ordering)',
        output: {
            delegationOrder: sorted.map(a => a.agentId),
            method: 'uuid_v7_temporal',
            agentCount: eligibleAgents.length,
        },
    }
}

/**
 * D-AGT-02: CONSENSUS VALUE COMPUTATION
 * All agents compute from same evidence + same rulebook.
 * Disagreement = faulty agent, not rulebook error.
 */
export function consensusValueComputation(inferencePoint, context) {
    const { agentResults, evidence } = context

    if (!agentResults || !Array.isArray(agentResults) || agentResults.length < 2) {
        return { applies: false }
    }

    // Check if all agents computed the same value
    const values = agentResults.map(r => JSON.stringify(r.value))
    const unique = [...new Set(values)]

    if (unique.length === 1) {
        return { applies: false } // Consensus achieved
    }

    // Disagreement — identify the faulty agent(s)
    const valueCounts = {}
    for (const r of agentResults) {
        const key = JSON.stringify(r.value)
        valueCounts[key] = (valueCounts[key] || 0) + 1
    }

    // Majority value is presumed correct
    const majorityValue = Object.entries(valueCounts)
        .sort((a, b) => b[1] - a[1])[0][0]

    const faultyAgents = agentResults
        .filter(r => JSON.stringify(r.value) !== majorityValue)
        .map(r => r.agentId)

    return {
        applies: true,
        action: 'FLAG',
        ruleId: 'D-AGT-02',
        ruleName: 'CONSENSUS VALUE COMPUTATION',
        reason: `${faultyAgents.length} agent(s) produced different values from same evidence — flagged for audit`,
        output: {
            consensusValue: JSON.parse(majorityValue),
            faultyAgents,
            totalAgents: agentResults.length,
            disagreementRate: faultyAgents.length / agentResults.length,
        },
    }
}

/**
 * D-AGT-03: CONFLICT CLASSIFICATION
 * Deterministic classification by type-match, not severity judgment.
 */
export function conflictClassification(inferencePoint, context) {
    const { conflictType } = context

    if (!conflictType) {
        return { applies: false }
    }

    const CLASSIFICATIONS = {
        trust_violation: {
            class: 'CLASS-A',
            action: 'IMMEDIATE_SESSION_TERMINATION',
            description: 'Trust violation — immediate session termination',
        },
        value_disagreement: {
            class: 'CLASS-B',
            action: 'CONSENSUS_RE_ROUND',
            maxRounds: 2,
            description: 'Value disagreement — consensus re-round (max 2)',
        },
        timeout: {
            class: 'CLASS-C',
            action: 'TASK_REASSIGNMENT',
            description: 'Timeout — task reassignment by agent_id',
        },
        resource_contention: {
            class: 'CLASS-D',
            action: 'HOMEOSTASIS_ARBITRATION',
            description: 'Resource contention — homeostasis arbitration',
        },
    }

    const classification = CLASSIFICATIONS[conflictType]

    if (!classification) {
        return {
            applies: true,
            action: 'ESCALATE',
            ruleId: 'D-AGT-03',
            ruleName: 'CONFLICT CLASSIFICATION',
            reason: `Unknown conflict type "${conflictType}" — escalating to human`,
            escalation: 'GATE_REQUEST',
            output: { unknownType: conflictType },
        }
    }

    return {
        applies: true,
        action: 'CLASSIFY',
        ruleId: 'D-AGT-03',
        ruleName: 'CONFLICT CLASSIFICATION',
        reason: classification.description,
        output: {
            ...classification,
            conflictType,
        },
    }
}

// ═══════════════════════════════════════════
//  COMPILER DOMAIN — INTENT RESOLVER RULES
//  D-CMPL-05 through D-CMPL-10
//  These rules catch NL patterns that fall through
//  the pattern library's regex matching.
// ═══════════════════════════════════════════

/**
 * D-CMPL-05: NEGATION PATTERN RESOLUTION
 * "don't show X", "skip X", "exclude X", "without X", "never X"
 * Converts negation + verb into the inverse operation AST node.
 */
export function negationPatternResolution(inferencePoint, context) {
    if (context._domainFilter && context._domainFilter !== 'compiler') return { applies: false }
    if (typeof inferencePoint !== 'string') return { applies: false }
    const text = inferencePoint.toLowerCase().trim()

    const negationMatch = text.match(
        /^(?:don'?t|do not|never|stop|skip|exclude|without|remove|avoid|disable|hide)\s+(?:the\s+)?(.+)$/i
    )
    if (!negationMatch) return { applies: false }

    const target = negationMatch[1].trim()

    // Determine the negation type
    if (text.startsWith('don') || text.startsWith('do not') || text.startsWith('never')) {
        // "don't show X" → hide X
        const verbMatch = target.match(/^(\w+)\s+(.+)$/)
        if (verbMatch) {
            const VERB_NEGATIONS = {
                show: 'StyleOperation', display: 'StyleOperation', render: 'StyleOperation',
                save: 'DeleteOperation', store: 'DeleteOperation',
                send: 'CancelOperation', emit: 'CancelOperation',
                run: 'CancelOperation', execute: 'CancelOperation',
                include: 'FilterOperation', allow: 'FilterOperation',
            }
            const negType = VERB_NEGATIONS[verbMatch[1].toLowerCase()]
            if (negType) {
                return {
                    applies: true,
                    action: 'RESOLVE',
                    ruleId: 'D-CMPL-05',
                    ruleName: 'NEGATION PATTERN RESOLUTION',
                    reason: `Negation detected: "don't ${verbMatch[1]}" → inverse operation`,
                    output: { type: negType, target: verbMatch[2].replace(/\s+/g, '_').toLowerCase(), negated: true, style: 'hidden' },
                }
            }
        }
    }

    if (text.startsWith('skip') || text.startsWith('exclude') || text.startsWith('without')) {
        return {
            applies: true,
            action: 'RESOLVE',
            ruleId: 'D-CMPL-05',
            ruleName: 'NEGATION PATTERN RESOLUTION',
            reason: `Exclusion pattern: "${text.split(' ')[0]}" → filter-out operation`,
            output: { type: 'FilterOperation', target: target.replace(/\s+/g, '_').toLowerCase(), condition: `!${target}`, negated: true },
        }
    }

    if (text.startsWith('hide') || text.startsWith('disable')) {
        return {
            applies: true,
            action: 'RESOLVE',
            ruleId: 'D-CMPL-05',
            ruleName: 'NEGATION PATTERN RESOLUTION',
            reason: `Visibility negation: "${text.split(' ')[0]}"`,
            output: { type: 'StyleOperation', target: target.replace(/\s+/g, '_').toLowerCase(), style: 'hidden' },
        }
    }

    return { applies: false }
}

/**
 * D-CMPL-06: IMPLICIT DECLARATION RESOLUTION
 * "start with X", "begin with X", "initialize X to Y", "X starts at Y"
 * Converts to VariableDeclaration AST nodes.
 */
export function implicitDeclarationResolution(inferencePoint, context) {
    if (context._domainFilter && context._domainFilter !== 'compiler') return { applies: false }
    if (typeof inferencePoint !== 'string') return { applies: false }
    const text = inferencePoint.toLowerCase().trim()

    // "start with X set to Y" / "begin with X as Y"
    const startWithMatch = text.match(
        /^(?:start|begin|initialize)\s+(?:with\s+)?(?:a\s+|an?\s+)?(\w[\w\s]*?)\s+(?:set to|as|at|=|of)\s+(.+)$/i
    )
    if (startWithMatch) {
        return {
            applies: true,
            action: 'RESOLVE',
            ruleId: 'D-CMPL-06',
            ruleName: 'IMPLICIT DECLARATION RESOLUTION',
            reason: `Implicit declaration: "${startWithMatch[1]}" initialized to "${startWithMatch[2]}"`,
            output: { type: 'VariableDeclaration', name: startWithMatch[1].replace(/\s+/g, '_').toLowerCase(), value: startWithMatch[2] },
        }
    }

    // "X starts at Y" / "counter begins at 0"
    const subjectStartsMatch = text.match(
        /^(?:the\s+)?(\w[\w\s]*?)\s+(?:starts?|begins?)\s+(?:at|with|from)\s+(.+)$/i
    )
    if (subjectStartsMatch) {
        return {
            applies: true,
            action: 'RESOLVE',
            ruleId: 'D-CMPL-06',
            ruleName: 'IMPLICIT DECLARATION RESOLUTION',
            reason: `Subject-starts declaration: "${subjectStartsMatch[1]}" = "${subjectStartsMatch[2]}"`,
            output: { type: 'VariableDeclaration', name: subjectStartsMatch[1].replace(/\s+/g, '_').toLowerCase(), value: subjectStartsMatch[2] },
        }
    }

    return { applies: false }
}

/**
 * D-CMPL-07: QUESTION-AS-INTENT RESOLUTION
 * "what is X?", "how many X?", "where is X?"
 * Converts interrogative forms to data access operations.
 */
export function questionAsIntentResolution(inferencePoint, context) {
    if (context._domainFilter && context._domainFilter !== 'compiler') return { applies: false }
    if (typeof inferencePoint !== 'string') return { applies: false }
    const text = inferencePoint.toLowerCase().trim().replace(/\?+$/, '')

    // "what is X" / "what's X"
    const whatIsMatch = text.match(/^what(?:'s| is| are)\s+(?:the\s+)?(.+)$/i)
    if (whatIsMatch) {
        return {
            applies: true,
            action: 'RESOLVE',
            ruleId: 'D-CMPL-07',
            ruleName: 'QUESTION-AS-INTENT RESOLUTION',
            reason: `Interrogative → data access: "what is ${whatIsMatch[1]}"`,
            output: { type: 'ShowStatement', value: whatIsMatch[1].replace(/\s+/g, '_').toLowerCase(), target: 'default' },
        }
    }

    // "how many X" / "how much X"
    const howManyMatch = text.match(/^how (?:many|much)\s+(?:the\s+)?(.+)$/i)
    if (howManyMatch) {
        return {
            applies: true,
            action: 'RESOLVE',
            ruleId: 'D-CMPL-07',
            ruleName: 'QUESTION-AS-INTENT RESOLUTION',
            reason: `Interrogative → count: "how many ${howManyMatch[1]}"`,
            output: { type: 'MemberExpression', object: howManyMatch[1].replace(/\s+/g, '_').toLowerCase(), property: 'length' },
        }
    }

    // "where is X"
    const whereIsMatch = text.match(/^where(?:'s| is| are)\s+(?:the\s+)?(.+)$/i)
    if (whereIsMatch) {
        return {
            applies: true,
            action: 'RESOLVE',
            ruleId: 'D-CMPL-07',
            ruleName: 'QUESTION-AS-INTENT RESOLUTION',
            reason: `Interrogative → search: "where is ${whereIsMatch[1]}"`,
            output: { type: 'VariableAccess', target: whereIsMatch[1].replace(/\s+/g, '_').toLowerCase(), source: null },
        }
    }

    // "is X Y?" → boolean check
    const isXYMatch = text.match(/^is\s+(?:the\s+)?(.+?)\s+(empty|null|valid|ready|running|active|enabled|visible|open|closed|done|finished|complete)$/i)
    if (isXYMatch) {
        return {
            applies: true,
            action: 'RESOLVE',
            ruleId: 'D-CMPL-07',
            ruleName: 'QUESTION-AS-INTENT RESOLUTION',
            reason: `Interrogative → validation: "is ${isXYMatch[1]} ${isXYMatch[2]}"`,
            output: { type: 'ValidationCheck', target: isXYMatch[1].replace(/\s+/g, '_').toLowerCase(), check: isXYMatch[2].toLowerCase(), negated: false },
        }
    }

    return { applies: false }
}

/**
 * D-CMPL-08: EXCLAMATORY INTENT RESOLUTION
 * "show me the data!", "delete everything!", "save now!"
 * Strips exclamatory markers and retries as imperative.
 */
export function exclamatoryIntentResolution(inferencePoint, context) {
    if (context._domainFilter && context._domainFilter !== 'compiler') return { applies: false }
    if (typeof inferencePoint !== 'string') return { applies: false }
    const text = inferencePoint.trim()

    // "show me X" → "show X"
    const showMeMatch = text.match(/^(\w+)\s+me\s+(?:the\s+)?(.+?)!?$/i)
    if (showMeMatch) {
        const verb = showMeMatch[1].toLowerCase()
        const target = showMeMatch[2].replace(/\s+/g, '_').toLowerCase()

        const VERB_TYPES = {
            show: 'ShowStatement', give: 'ShowStatement', tell: 'ShowStatement',
            get: 'VariableAccess', fetch: 'VariableAccess', find: 'VariableAccess',
            send: 'SendOperation', email: 'SendOperation',
        }

        if (VERB_TYPES[verb]) {
            return {
                applies: true,
                action: 'RESOLVE',
                ruleId: 'D-CMPL-08',
                ruleName: 'EXCLAMATORY INTENT RESOLUTION',
                reason: `"${verb} me" pattern → "${verb}" with dative stripped`,
                output: { type: VERB_TYPES[verb], value: target, target: verb === 'send' ? null : 'default' },
            }
        }
    }

    return { applies: false }
}

/**
 * D-CMPL-09: BARE NOUN REFERENCE RESOLUTION
 * When the intent resolver gets just a noun (e.g., "users", "config", "settings"),
 * interpret it as a variable access (show that value).
 */
export function bareNounResolution(inferencePoint, context) {
    if (context._domainFilter && context._domainFilter !== 'compiler') return { applies: false }
    if (typeof inferencePoint !== 'string') return { applies: false }
    const text = inferencePoint.trim().toLowerCase()

    // Must be 1-3 words, no verbs, no special chars
    const words = text.split(/\s+/)
    if (words.length > 3 || words.length === 0) return { applies: false }
    if (/[^a-z0-9\s_-]/.test(text)) return { applies: false }

    const COMMON_VERBS = new Set([
        'get', 'set', 'show', 'create', 'delete', 'update', 'send', 'save', 'check',
        'sort', 'filter', 'connect', 'wait', 'return', 'log', 'print', 'call', 'run',
        'deploy', 'monitor', 'heal', 'optimize', 'evolve', 'fetch', 'display', 'store',
        'remove', 'make', 'build', 'draw', 'verify', 'test', 'if', 'when', 'while',
        'for', 'try', 'else', 'add', 'subtract', 'multiply', 'divide', 'import',
        'export', 'use', 'toggle', 'reset', 'clone', 'merge', 'reverse', 'flatten',
        'combine', 'split', 'replace', 'convert', 'format', 'swap', 'pipe', 'alert',
        'throw', 'schedule', 'every', 'repeat', 'navigate', 'redirect', 'focus',
        'hide', 'order', 'group', 'count', 'trim', 'configure', 'mode',
    ])

    // If the first word is a verb, this isn't a bare noun
    if (COMMON_VERBS.has(words[0])) return { applies: false }

    return {
        applies: true,
        action: 'RESOLVE',
        ruleId: 'D-CMPL-09',
        ruleName: 'BARE NOUN REFERENCE RESOLUTION',
        reason: `Bare noun reference: "${text}" → variable access`,
        output: { type: 'VariableAccess', target: text.replace(/\s+/g, '_'), source: null },
    }
}

/**
 * D-CMPL-10: COMPARISON SHORTHAND RESOLUTION
 * "X > Y", "X < Y", "X == Y" — math/comparison shorthands
 * that don't match the verbose pattern library.
 */
export function comparisonShorthandResolution(inferencePoint, context) {
    if (context._domainFilter && context._domainFilter !== 'compiler') return { applies: false }
    if (typeof inferencePoint !== 'string') return { applies: false }
    const text = inferencePoint.trim()

    const compMatch = text.match(/^(.+?)\s*(===?|!==?|>=?|<=?)\s*(.+)$/)
    if (compMatch) {
        return {
            applies: true,
            action: 'RESOLVE',
            ruleId: 'D-CMPL-10',
            ruleName: 'COMPARISON SHORTHAND RESOLUTION',
            reason: `Operator shorthand: "${compMatch[2]}"`,
            output: {
                type: 'BinaryExpression',
                operator: compMatch[2],
                left: compMatch[1].trim().replace(/\s+/g, '_').toLowerCase(),
                right: compMatch[3].trim(),
            },
        }
    }

    return { applies: false }
}

// Export all domain rules
export const DOMAIN_RULES = [
    // Compiler domain
    { id: 'D-CMPL-01', name: 'TOKENIZATION DETERMINISM', fn: tokenizationDeterminism, domain: 'compiler' },
    { id: 'D-CMPL-02', name: 'AST NODE ORDERING', fn: astNodeOrdering, domain: 'compiler' },
    { id: 'D-CMPL-03', name: 'AMBIGUITY ORACLE CASCADE', fn: ambiguityOracleCascade, domain: 'compiler' },
    { id: 'D-CMPL-04', name: 'OPTIMIZATION PASS ORDERING', fn: optimizationPassOrdering, domain: 'compiler' },
    { id: 'D-CMPL-05', name: 'NEGATION PATTERN RESOLUTION', fn: negationPatternResolution, domain: 'compiler' },
    { id: 'D-CMPL-06', name: 'IMPLICIT DECLARATION RESOLUTION', fn: implicitDeclarationResolution, domain: 'compiler' },
    { id: 'D-CMPL-07', name: 'QUESTION-AS-INTENT RESOLUTION', fn: questionAsIntentResolution, domain: 'compiler' },
    { id: 'D-CMPL-08', name: 'EXCLAMATORY INTENT RESOLUTION', fn: exclamatoryIntentResolution, domain: 'compiler' },
    { id: 'D-CMPL-09', name: 'BARE NOUN REFERENCE RESOLUTION', fn: bareNounResolution, domain: 'compiler' },
    { id: 'D-CMPL-10', name: 'COMPARISON SHORTHAND RESOLUTION', fn: comparisonShorthandResolution, domain: 'compiler' },
    // Runtime domain
    { id: 'D-SOR-01', name: 'CELL SCHEDULING DETERMINISM', fn: cellSchedulingDeterminism, domain: 'runtime' },
    { id: 'D-SOR-02', name: 'SIGNAL DELIVERY ORDER', fn: signalDeliveryOrder, domain: 'runtime' },
    { id: 'D-SOR-03', name: 'HOMEOSTASIS THRESHOLD INFERENCE', fn: homeostasisThresholdInference, domain: 'runtime' },
    { id: 'D-SOR-04', name: 'ROLLBACK SCOPE', fn: rollbackScope, domain: 'runtime' },
    // Voice domain
    { id: 'D-VOX-01', name: 'ASR CANDIDATE SELECTION', fn: asrCandidateSelection, domain: 'voice' },
    { id: 'D-VOX-02', name: 'NORMALIZATION IDEMPOTENCY', fn: normalizationIdempotency, domain: 'voice' },
    { id: 'D-VOX-03', name: 'SILENCE HANDLING', fn: silenceHandling, domain: 'voice' },
    // Agent domain
    { id: 'D-AGT-01', name: 'TASK DELEGATION DETERMINISM', fn: taskDelegationDeterminism, domain: 'agent' },
    { id: 'D-AGT-02', name: 'CONSENSUS VALUE COMPUTATION', fn: consensusValueComputation, domain: 'agent' },
    { id: 'D-AGT-03', name: 'CONFLICT CLASSIFICATION', fn: conflictClassification, domain: 'agent' },
]

export default DOMAIN_RULES

