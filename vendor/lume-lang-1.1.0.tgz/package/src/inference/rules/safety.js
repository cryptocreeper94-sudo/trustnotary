/**
 * ═══════════════════════════════════════════════════════════
 *  LDIR TIER 4: SAFETY RULES
 *  Highest priority — never overridden.
 *
 *  S-01: HALT ON UNBOUNDED INFERENCE
 *  S-02: DENY PRIVILEGE ESCALATION BY INFERENCE
 *  S-03: PRESERVE INTENT FIDELITY
 *  S-04: NEVER INFER FROM ABSENCE
 *  S-05: CRYPTOGRAPHIC INTEGRITY OVER PERFORMANCE
 *
 *  By DarkWave Studios LLC — DarkWaveStudios.io
 *  Copyright 2026. Protected by TrustShield.tech
 * ═══════════════════════════════════════════════════════════
 */

/**
 * S-01: HALT ON UNBOUNDED INFERENCE
 * If an inference path has no provable termination bound, halt immediately.
 * Do not attempt iterative deepening or probabilistic cutoffs.
 */
export function haltOnUnboundedInference(inferencePoint, context) {
    const { candidates, depth, maxDepth } = context

    // Check for infinite recursion in resolution
    if (depth !== undefined && maxDepth !== undefined && depth > maxDepth) {
        return {
            applies: true,
            action: 'HALT',
            ruleId: 'S-01',
            ruleName: 'HALT ON UNBOUNDED INFERENCE',
            reason: `Inference depth ${depth} exceeds maximum bound ${maxDepth}`,
            escalation: 'GATE_REQUEST',
        }
    }

    // Check for unbounded candidate sets
    if (candidates && !Array.isArray(candidates)) {
        return {
            applies: true,
            action: 'HALT',
            ruleId: 'S-01',
            ruleName: 'HALT ON UNBOUNDED INFERENCE',
            reason: 'Candidate set is not finitely enumerable',
            escalation: 'GATE_REQUEST',
        }
    }

    // Check for cycles in resolution paths
    if (context.visitedNodes) {
        const current = JSON.stringify(inferencePoint)
        if (context.visitedNodes.has(current)) {
            return {
                applies: true,
                action: 'HALT',
                ruleId: 'S-01',
                ruleName: 'HALT ON UNBOUNDED INFERENCE',
                reason: 'Cycle detected in inference path — node already visited',
                escalation: 'GATE_REQUEST',
            }
        }
    }

    return { applies: false }
}

/**
 * S-02: DENY PRIVILEGE ESCALATION BY INFERENCE
 * No inference result may grant permissions, trust levels, or resource access
 * beyond what the originating trust certificate explicitly allows.
 */
export function denyPrivilegeEscalation(inferencePoint, context) {
    const { requestedPermissions, certificatePermissions } = context

    if (!requestedPermissions || !certificatePermissions) {
        return { applies: false }
    }

    const allowed = new Set(certificatePermissions.allowed || [])
    const denied = new Set(certificatePermissions.denied || [])

    for (const perm of requestedPermissions) {
        // Explicitly denied
        if (denied.has(perm)) {
            return {
                applies: true,
                action: 'DENY',
                ruleId: 'S-02',
                ruleName: 'DENY PRIVILEGE ESCALATION BY INFERENCE',
                reason: `Permission "${perm}" is explicitly denied by trust certificate`,
                output: { denied: perm, source: 'certificate_explicit_deny' },
            }
        }

        // Not explicitly allowed — check wildcard patterns
        const isAllowed = [...allowed].some(a => {
            if (a === perm) return true
            if (a.endsWith('*')) {
                return perm.startsWith(a.slice(0, -1))
            }
            return false
        })

        if (!isAllowed) {
            return {
                applies: true,
                action: 'DENY',
                ruleId: 'S-02',
                ruleName: 'DENY PRIVILEGE ESCALATION BY INFERENCE',
                reason: `Permission "${perm}" not granted by trust certificate — inference cannot escalate privileges`,
                output: { denied: perm, source: 'not_in_certificate' },
            }
        }
    }

    return { applies: false }
}

/**
 * S-03: PRESERVE INTENT FIDELITY
 * If the deterministic resolution of an ambiguity would alter the programmer's
 * expressed intent (as determined by semantic distance from the original NL input),
 * halt and request clarification rather than silently reinterpreting.
 */
export function preserveIntentFidelity(inferencePoint, context) {
    const { originalIntent, resolvedIntent, semanticDistanceThreshold } = context

    if (!originalIntent || !resolvedIntent) {
        return { applies: false }
    }

    const threshold = semanticDistanceThreshold || 0.3
    const distance = computeSemanticDistance(originalIntent, resolvedIntent)

    if (distance > threshold) {
        return {
            applies: true,
            action: 'HALT',
            ruleId: 'S-03',
            ruleName: 'PRESERVE INTENT FIDELITY',
            reason: `Semantic distance ${distance.toFixed(3)} exceeds threshold ${threshold} — resolution would alter programmer intent`,
            escalation: 'GATE_REQUEST — Clarification needed',
            output: { distance, threshold, originalIntent, resolvedIntent },
        }
    }

    return { applies: false }
}

/**
 * S-04: NEVER INFER FROM ABSENCE
 * The absence of a constraint, permission, or statement in the intent-source
 * is NOT evidence that the constraint doesn't apply.
 * Default: DENY for permissions, BOUNDED for resources, EXPLICIT for intent.
 */
export function neverInferFromAbsence(inferencePoint, context) {
    const { inferenceType, sourceExplicit } = context

    // Only applies when something is being inferred from missing information
    if (sourceExplicit !== false) {
        return { applies: false }
    }

    switch (inferenceType) {
        case 'permission':
            return {
                applies: true,
                action: 'DENY',
                ruleId: 'S-04',
                ruleName: 'NEVER INFER FROM ABSENCE',
                reason: 'Permission not explicitly stated in intent — defaulting to DENY',
                output: { default: 'DENY', inferenceType: 'permission' },
            }
        case 'resource':
            return {
                applies: true,
                action: 'BOUND',
                ruleId: 'S-04',
                ruleName: 'NEVER INFER FROM ABSENCE',
                reason: 'Resource allocation not explicitly stated — defaulting to BOUNDED',
                output: { default: 'BOUNDED', inferenceType: 'resource' },
            }
        case 'intent':
            return {
                applies: true,
                action: 'HALT',
                ruleId: 'S-04',
                ruleName: 'NEVER INFER FROM ABSENCE',
                reason: 'Intent not explicitly stated — cannot infer from absence',
                escalation: 'GATE_REQUEST — Explicit intent required',
                output: { default: 'EXPLICIT', inferenceType: 'intent' },
            }
        default:
            return { applies: false }
    }
}

/**
 * S-05: CRYPTOGRAPHIC INTEGRITY OVER PERFORMANCE
 * If a deterministic inference path conflicts with an optimization that would
 * reduce cryptographic verification coverage, the inference path preserving
 * full verification wins.
 */
export function cryptographicIntegrityOverPerformance(inferencePoint, context) {
    const { pathA, pathB } = context

    if (!pathA || !pathB) {
        return { applies: false }
    }

    const aPreservesCrypto = pathA.preservesCryptoVerification !== false
    const bPreservesCrypto = pathB.preservesCryptoVerification !== false

    // Only applies when paths differ on crypto coverage
    if (aPreservesCrypto === bPreservesCrypto) {
        return { applies: false }
    }

    const chosen = aPreservesCrypto ? pathA : pathB
    const rejected = aPreservesCrypto ? pathB : pathA

    return {
        applies: true,
        action: 'SELECT',
        ruleId: 'S-05',
        ruleName: 'CRYPTOGRAPHIC INTEGRITY OVER PERFORMANCE',
        reason: `Path "${rejected.name || 'B'}" reduces cryptographic verification coverage — selecting "${chosen.name || 'A'}" instead`,
        output: { selected: chosen, rejected, reason: 'crypto_integrity' },
    }
}

/**
 * Compute semantic distance between two intent strings.
 * Uses Jaccard distance on word sets as a deterministic proxy.
 * (No ML/embeddings — deterministic by design)
 */
function computeSemanticDistance(a, b) {
    if (!a || !b) return 1.0
    const wordsA = new Set(normalizeForDistance(a))
    const wordsB = new Set(normalizeForDistance(b))

    if (wordsA.size === 0 && wordsB.size === 0) return 0.0

    const intersection = new Set([...wordsA].filter(w => wordsB.has(w)))
    const union = new Set([...wordsA, ...wordsB])

    return 1.0 - (intersection.size / union.size)
}

function normalizeForDistance(text) {
    return text
        .toLowerCase()
        .replace(/[^a-z0-9\s]/g, '')
        .split(/\s+/)
        .filter(w => w.length > 1)
}

// Export all safety rules as an array for the rulebook engine
export const SAFETY_RULES = [
    { id: 'S-01', name: 'HALT ON UNBOUNDED INFERENCE', fn: haltOnUnboundedInference },
    { id: 'S-02', name: 'DENY PRIVILEGE ESCALATION BY INFERENCE', fn: denyPrivilegeEscalation },
    { id: 'S-03', name: 'PRESERVE INTENT FIDELITY', fn: preserveIntentFidelity },
    { id: 'S-04', name: 'NEVER INFER FROM ABSENCE', fn: neverInferFromAbsence },
    { id: 'S-05', name: 'CRYPTOGRAPHIC INTEGRITY OVER PERFORMANCE', fn: cryptographicIntegrityOverPerformance },
]

export default SAFETY_RULES
