/**
 * ═══════════════════════════════════════════════════════════
 *  LUME INTENT RESOLVER — Auto-Correct Layer
 *  Spell check + context-aware correction + voice cleanup
 *  Runs BEFORE the Tolerance Chain
 * ═══════════════════════════════════════════════════════════
 */

import { correctSentence } from './fuzzy-matcher.js'

/* ═══════════════════════════════════════════════════════════════
 *  FILLER WORDS — 80+ speech patterns (synced with voice-input.js)
 * ═══════════════════════════════════════════════════════════════ */
const FILLER_WORDS = new Set([
    // Classic fillers
    'um', 'uh', 'erm', 'er', 'ah', 'hmm', 'hm', 'mm', 'mmm', 'uhh', 'umm',
    'mhm', 'aha', 'ehm', 'ahem', 'huh',
    // Discourse markers
    'like', 'basically', 'so', 'well', 'right', 'okay', 'ok', 'honestly',
    'literally', 'obviously', 'clearly', 'anyway', 'anyways', 'essentially',
    'apparently', 'presumably', 'supposedly', 'technically', 'actually',
    'whatever', 'anyhow', 'furthermore',
    // Multi-word fillers
    'you know', 'i mean', 'i guess', 'you see', 'i think',
    'sort of', 'kind of', 'let me think', 'how should i say',
    'in other words', 'if you will', 'as i was saying',
    'for what its worth', 'at the end of the day',
    'to be honest', 'to be fair', 'i suppose',
    'in a way', 'in a sense', 'as it were', 'so to speak',
    'if you know what i mean', 'you know what i mean',
    'at any rate', 'in any case', 'in any event',
    'as a matter of fact', 'the thing is', 'the point is',
    'i would say', 'let me see', 'how do i put this',
    // Hedge words
    'maybe', 'perhaps', 'probably', 'possibly', 'presumably',
    'roughly', 'approximately', 'more or less',
    // Verbal tics
    'look', 'see', 'listen', 'hear me out',
])

/* ═══════════════════════════════════════════════════════════════
 *  VOICE PHONETIC CORRECTIONS — 100+ tech terms
 *  Maps speech-to-text engine misinterpretations to their
 *  correct technical spelling. Critical for voice-to-code.
 * ═══════════════════════════════════════════════════════════════ */
const VOICE_CORRECTIONS = {
    // ── Database & Query Terms ────────────────────────────────
    'sequel': 'SQL', 'es queue el': 'SQL', 'es q l': 'SQL', 'my sequel': 'MySQL',
    'my s q l': 'MySQL', 'post gress': 'PostgreSQL', 'post gree': 'PostgreSQL',
    'postgres q l': 'PostgreSQL', 'post graph': 'PostgreSQL',
    'mongo db': 'MongoDB', 'mango db': 'MongoDB', 'mango d b': 'MongoDB',
    'redis': 'Redis', 'read is': 'Redis',
    'no sequel': 'NoSQL', 'no s q l': 'NoSQL',
    'dy namo db': 'DynamoDB', 'dynamo db': 'DynamoDB',
    'fire base': 'Firebase', 'fire store': 'Firestore',
    'sue pa base': 'Supabase', 'super base': 'Supabase',

    // ── Web Standards & Protocols ────────────────────────────
    'h t t p': 'HTTP', 'h t t p s': 'HTTPS', 'h t m l': 'HTML',
    'u r l': 'URL', 'a p i': 'API', 'c s s': 'CSS', 'j s': 'JS',
    'jason': 'JSON', 'jay son': 'JSON', 'j son': 'JSON',
    'rest': 'REST', 'rest full': 'RESTful', 'rest fool': 'RESTful',
    'graph q l': 'GraphQL', 'graph queue el': 'GraphQL',
    'web socket': 'WebSocket', 'web sockets': 'WebSocket',
    'soap': 'SOAP', 'grpc': 'gRPC', 'g r p c': 'gRPC',
    'oh auth': 'OAuth', 'oh auth two': 'OAuth2', 'o auth': 'OAuth',
    'j w t': 'JWT', 'jay double you tee': 'JWT',
    'd n s': 'DNS', 's s l': 'SSL', 't l s': 'TLS',
    'f t p': 'FTP', 's f t p': 'SFTP', 's s h': 'SSH',
    'tcp ip': 'TCP/IP', 'i p': 'IP', 'tcp': 'TCP', 'udp': 'UDP',
    'u d p': 'UDP', 'dom': 'DOM', 'd o m': 'DOM',
    'cors': 'CORS', 'c o r s': 'CORS',
    'a j a x': 'AJAX', 'ajax': 'AJAX',

    // ── Runtime & Tools ──────────────────────────────────────
    'no js': 'Node.js', 'node js': 'Node.js', 'node j s': 'Node.js',
    'react js': 'React', 'vue js': 'Vue', 'view js': 'Vue',
    'next js': 'Next.js', 'next j s': 'Next.js',
    'bun js': 'Bun', 'deno': 'Deno', 'dee know': 'Deno',
    'express js': 'Express', 'express j s': 'Express',
    'type script': 'TypeScript', 'java script': 'JavaScript',
    'python': 'Python', 'pie thon': 'Python',
    'c sharp': 'C#', 'c plus plus': 'C++',
    'swift': 'Swift', 'kotlin': 'Kotlin', 'cat lin': 'Kotlin',
    'go lang': 'Go', 'golang': 'Go',
    'rust lang': 'Rust', 'rust': 'Rust',

    // ── Cloud & DevOps ───────────────────────────────────────
    'docker': 'Docker', 'doc er': 'Docker',
    'kubernetes': 'Kubernetes', 'koober netties': 'Kubernetes',
    'kube': 'Kubernetes', 'k 8 s': 'Kubernetes', 'k8s': 'Kubernetes',
    'aws': 'AWS', 'a w s': 'AWS', 'amazon web services': 'AWS',
    'g c p': 'GCP', 'google cloud': 'GCP',
    'azure': 'Azure', 'a sure': 'Azure',
    'vercel': 'Vercel', 'ver sell': 'Vercel', 'ver cell': 'Vercel',
    'net lie fy': 'Netlify', 'netlify': 'Netlify',
    'render': 'Render', 'heroku': 'Heroku', 'hair oh koo': 'Heroku',
    'ci cd': 'CI/CD', 'c i c d': 'CI/CD',
    'circle ci': 'CircleCI', 'jenkins': 'Jenkins',
    'get hub': 'GitHub', 'git hub': 'GitHub', 'git lab': 'GitLab',
    'bit bucket': 'Bitbucket',
    'terraform': 'Terraform', 'tear a form': 'Terraform',
    'ansible': 'Ansible', 'aim the bowl': 'Ansible',

    // ── Data Formats & Standards ─────────────────────────────
    'yaml': 'YAML', 'y a m l': 'YAML',
    'xml': 'XML', 'x m l': 'XML',
    'csv': 'CSV', 'c s v': 'CSV',
    'base 64': 'Base64', 'base sixty four': 'Base64',
    'utf 8': 'UTF-8', 'u t f eight': 'UTF-8', 'you t f eight': 'UTF-8',
    'regex': 'Regex', 'reg ex': 'Regex', 'regular expression': 'Regex',
    'i d': 'ID', 'u u i d': 'UUID', 'you you i d': 'UUID',

    // ── Frontend Frameworks & Libraries ──────────────────────
    'tailwind': 'Tailwind', 'tail wind': 'Tailwind',
    'boot strap': 'Bootstrap', 'bootstrap': 'Bootstrap',
    'angular': 'Angular', 'angle lar': 'Angular',
    'svelte': 'Svelte', 's felt': 'Svelte',
    'web pack': 'Webpack', 'webpack': 'Webpack',
    'rollup': 'Rollup', 'roll up': 'Rollup',
    'veet': 'Vite', 'vite': 'Vite', 'fight': 'Vite',
    'e s lint': 'ESLint', 'es lint': 'ESLint',
    'prettier': 'Prettier', 'pretty er': 'Prettier',
    'storybook': 'Storybook', 'story book': 'Storybook',

    // ── Payment & Services ───────────────────────────────────
    'stripe': 'Stripe', 'resend': 'Resend', 're send': 'Resend',
    'twilio': 'Twilio', 'twill ee oh': 'Twilio',
    'send grid': 'SendGrid', 'mail gun': 'Mailgun',
    'pay pal': 'PayPal', 'paypal': 'PayPal',
    'sentry': 'Sentry', 'data dog': 'Datadog',
    'new relic': 'New Relic',

    // ── Lume Ecosystem ───────────────────────────────────────
    'loom': 'Lume', 'loom e': 'Lume', 'l u m e': 'Lume',
    'trust layer': 'Trust Layer', 'trust gen': 'TrustGen',
    'dark wave': 'DarkWave', 'signal chat': 'Signal Chat',
    'guardian scanner': 'Guardian Scanner',

    // ── Common Tech Jargon ───────────────────────────────────
    'crud': 'CRUD', 'c r u d': 'CRUD',
    'agile': 'Agile', 'a jile': 'Agile',
    'scrum': 'Scrum', 'dev ops': 'DevOps',
    'e s module': 'ES Module', 'common js': 'CommonJS',
    'n p m': 'npm', 'npm': 'npm',
    'yarn': 'yarn', 'p n p m': 'pnpm',
    'i d e': 'IDE', 'ide': 'IDE',
    'v s code': 'VS Code', 'visual studio code': 'VS Code',
    'vs code': 'VS Code',
    'cli': 'CLI', 'c l i': 'CLI',
    's d k': 'SDK', 'sdk': 'SDK',
    'a s t': 'AST', 'ast': 'AST',
    'i r': 'IR', 'intermediate representation': 'IR',
    's a s s': 'Sass', 'sass': 'Sass',
    'less': 'Less', 'post css': 'PostCSS',
    'web assembly': 'WebAssembly', 'wasm': 'WASM', 'w a s m': 'WASM',
    'prisma': 'Prisma', 'prism a': 'Prisma',
    'drizzle': 'Drizzle', 'type o r m': 'TypeORM',
    'sequel eyes': 'Sequelize', 'sequelize': 'Sequelize',
    'red ex': 'Redux', 'redux': 'Redux',
    'zustand': 'Zustand', 'zoo stand': 'Zustand',
    'jotai': 'Jotai', 'joe tie': 'Jotai',
    'mob x': 'MobX', 'recoil': 'Recoil',
    'three js': 'Three.js', 'three j s': 'Three.js',

    // ── Testing & CI Tools ──────────────────────────────────
    'jest': 'Jest', 'just test': 'Jest',
    'mocha': 'Mocha', 'mock a': 'Mocha',
    'chai': 'Chai', 'shy': 'Chai',
    'cypress': 'Cypress', 'sigh press': 'Cypress',
    'playwright': 'Playwright', 'play right': 'Playwright',
    'selenium': 'Selenium', 'cell any um': 'Selenium',
    'puppeteer': 'Puppeteer', 'puppet ear': 'Puppeteer',
    'storybook': 'Storybook', 'story book': 'Storybook',
    'vitest': 'Vitest', 'v test': 'Vitest',

    // ── Additional Frameworks & Tools ────────────────────────
    'fastify': 'Fastify', 'fast a fy': 'Fastify',
    'nest js': 'NestJS', 'nest j s': 'NestJS',
    'nuxt': 'Nuxt', 'nucks': 'Nuxt', 'nuxt js': 'Nuxt',
    'astro': 'Astro', 'as tro': 'Astro',
    'remix': 'Remix', 're mix': 'Remix',
    'gatsby': 'Gatsby', 'gats by': 'Gatsby',
    'electron': 'Electron', 'elect ron': 'Electron',
    'tauri': 'Tauri', 'tower ee': 'Tauri',
    'turbo pack': 'Turbopack', 'turbopack': 'Turbopack',
    'turbo repo': 'Turborepo', 'turborepo': 'Turborepo',
    'bable': 'Babel', 'babel': 'Babel', 'babble': 'Babel',
    'swc': 'SWC', 's w c': 'SWC',
    'esbuild': 'esbuild', 'e s build': 'esbuild',
    'biome': 'Biome', 'buy ohm': 'Biome',
    'panda css': 'Panda CSS', 'panda c s s': 'Panda CSS',
    'chakra': 'Chakra', 'chalk ra': 'Chakra',
    'material ui': 'Material UI', 'material u i': 'Material UI',
    'ant design': 'Ant Design', 'ant d': 'Ant Design',
    'shadcn': 'shadcn', 'shad c n': 'shadcn',
    'zod': 'Zod', 'z o d': 'Zod',
    'yup': 'Yup',
    'tRPC': 'tRPC', 't r p c': 'tRPC',
}

/* ── Self-Correction Phrases ─────────────────────────── */
const CORRECTION_TRIGGERS = [
    'no,', 'no ', 'i mean', 'actually,', 'actually ', 'wait,', 'wait ',
    'sorry,', 'sorry ', 'i meant', 'scratch that', 'not that',
    'correction', 'let me rephrase', 'hold on', 'never mind',
    'oops', 'my bad', 'what i said was', 'rather',
]

/* ── Number Word Map ─────────────────────────────────── */
const NUMBER_WORDS = {
    zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7,
    eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12, thirteen: 13,
    fourteen: 14, fifteen: 15, sixteen: 16, seventeen: 17, eighteen: 18,
    nineteen: 19, twenty: 20, thirty: 30, forty: 40, fifty: 50,
    sixty: 60, seventy: 70, eighty: 80, ninety: 90,
    hundred: 100, thousand: 1000, million: 1000000,
    a: 1, couple: 2, few: 3, several: 5, dozen: 12,
}

/**
 * Main auto-correct pipeline.
 * Returns { corrected, corrections[], wasModified }
 */
export function autoCorrect(input, context = {}, options = {}) {
    if (options.noAutocorrect) return { corrected: input, corrections: [], wasModified: false }

    const corrections = []
    let text = input

    // Step 1: Strip filler words
    text = stripFillers(text, corrections)

    // Step 2: Handle self-corrections ("no, I mean...")
    text = handleSelfCorrections(text, corrections)

    // Step 3: Voice phonetic corrections
    text = applyVoiceCorrections(text, corrections)

    // Step 4: Number word → digit conversion (in numeric contexts)
    text = convertNumberWords(text, corrections)

    // Step 5: Misspelling dictionary + contraction normalization
    const { corrected: spellChecked, corrections: spellCorrections } = correctSentence(text)
    text = spellChecked
    corrections.push(...spellCorrections.map(c => ({ type: 'spelling', original: c.original, fixed: c.fixed })))

    // Step 6: Context-aware corrections (uses project data if available)
    if (context.variables || context.tables || context.functions) {
        text = contextCorrect(text, context, corrections)
    }

    return {
        corrected: text.trim(),
        corrections,
        wasModified: corrections.length > 0,
    }
}

/* ── Step 1: Strip Filler Words ──────────────────────── */
function stripFillers(text, corrections) {
    let result = text
    for (const filler of FILLER_WORDS) {
        const regex = new RegExp(`\\b${filler}\\b,?\\s*`, 'gi')
        if (regex.test(result)) {
            corrections.push({ type: 'filler', original: filler, fixed: '' })
            result = result.replace(regex, ' ')
        }
    }
    return result.replace(/\s+/g, ' ').trim()
}

/* ── Step 2: Handle Self-Corrections ─────────────────── */
function handleSelfCorrections(text, corrections) {
    for (const trigger of CORRECTION_TRIGGERS) {
        const idx = text.toLowerCase().lastIndexOf(trigger)
        if (idx > 0) {
            const before = text.substring(0, idx).trim()
            const after = text.substring(idx + trigger.length).trim()
            if (after.length > 0) {
                corrections.push({ type: 'self-correction', original: before, fixed: after })
                return after
            }
        }
    }
    return text
}

/* ── Step 3: Voice Phonetic Corrections ──────────────── */
function applyVoiceCorrections(text, corrections) {
    let result = text
    for (const [spoken, correct] of Object.entries(VOICE_CORRECTIONS)) {
        const regex = new RegExp(`\\b${spoken}\\b`, 'gi')
        if (regex.test(result)) {
            corrections.push({ type: 'voice', original: spoken, fixed: correct })
            result = result.replace(regex, correct)
        }
    }
    return result
}

/* ── Step 4: Number Word Conversion ──────────────────── */
function convertNumberWords(text, corrections) {
    return text.replace(/\b(zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand|million|couple|few|several|dozen)\b/gi, (match) => {
        const num = NUMBER_WORDS[match.toLowerCase()]
        if (num !== undefined) {
            corrections.push({ type: 'number', original: match, fixed: String(num) })
            return String(num)
        }
        return match
    })
}

/* ── Step 6: Context-Aware Corrections ───────────────── */
function contextCorrect(text, context, corrections) {
    const words = text.split(/\s+/)
    const knownNames = [
        ...(context.variables || []),
        ...(context.tables || []),
        ...(context.functions || []),
    ]

    return words.map(word => {
        const clean = word.replace(/[^a-zA-Z0-9_]/g, '')
        if (!clean || clean.length < 3) return word

        // Check if the word is close to a known project name
        for (const name of knownNames) {
            if (clean.toLowerCase() === name.toLowerCase()) return word
            const distance = levenshteinLight(clean.toLowerCase(), name.toLowerCase())
            const sim = 1 - distance / Math.max(clean.length, name.length)
            if (sim >= 0.75 && sim < 1) {
                corrections.push({ type: 'context', original: clean, fixed: name })
                return word.replace(clean, name)
            }
        }
        return word
    }).join(' ')
}

/* ── Lightweight Levenshtein (inline for context correct) */
function levenshteinLight(a, b) {
    const la = a.length, lb = b.length
    if (la === 0) return lb
    if (lb === 0) return la
    const dp = Array.from({ length: la + 1 }, (_, i) => {
        const row = new Array(lb + 1)
        row[0] = i
        return row
    })
    for (let j = 1; j <= lb; j++) dp[0][j] = j
    for (let i = 1; i <= la; i++) {
        for (let j = 1; j <= lb; j++) {
            dp[i][j] = Math.min(
                dp[i - 1][j] + 1, dp[i][j - 1] + 1,
                dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
            )
        }
    }
    return dp[la][lb]
}

/**
 * Format corrections for compiler output
 */
export function formatCorrections(corrections, lineNum) {
    return corrections.map(c =>
        `[auto-correct] Line ${lineNum}: "${c.original}" -> "${c.fixed}" (${c.type})`
    )
}
