/**
 * ═══════════════════════════════════════════════════════════
 *  LUME DOMAIN MODULE REGISTRY
 *  Pluggable domain-specific verb modules that extend the
 *  Intent Resolver with specialized vocabulary.
 *
 *  Constitutional Compliance:
 *    - All domain verbs are deterministic regex → AST (Layer A)
 *    - No AI dependency — domain verbs are pattern-matched
 *    - Guardian Scanner runs on every domain-generated node
 *    - All verbs are speakable (voice-first)
 * ═══════════════════════════════════════════════════════════
 */

/**
 * @typedef {Object} DomainModule
 * @property {string} name - Module identifier (e.g., 'web', 'data')
 * @property {string} description - Human-readable description
 * @property {string} outputType - Primary output format ('js' | 'html' | 'data' | 'api' | 'cron')
 * @property {string[]} sandboxCapabilities - What the output needs ('fetch', 'fs', 'dom', etc.)
 * @property {Array<{match: RegExp, resolve: Function, tags: string[]}>} patterns - Verb patterns (same format as pattern-library.js)
 * @property {Object} synonymRings - Domain-specific synonym rings
 */

const registry = new Map()
const activeModules = new Set()

/**
 * Register a domain module.
 * @param {DomainModule} module
 */
export function registerDomain(module) {
    if (!module.name || !module.patterns || !Array.isArray(module.patterns)) {
        throw new Error(`Invalid domain module: must have name and patterns array`)
    }
    registry.set(module.name, module)
}

/**
 * Activate a domain module for the current compilation context.
 * @param {string} name - Module name
 * @returns {boolean} true if module was found and activated
 */
export function activateDomain(name) {
    const key = name.toLowerCase().trim()
    if (!registry.has(key)) return false
    activeModules.add(key)
    return true
}

/**
 * Deactivate a domain module.
 * @param {string} name
 */
export function deactivateDomain(name) {
    activeModules.delete(name.toLowerCase().trim())
}

/**
 * Reset all active modules (called between compilations).
 */
export function resetActiveDomains() {
    activeModules.clear()
}

/**
 * Get all registered domain modules.
 * @returns {Map<string, DomainModule>}
 */
export function getRegisteredDomains() {
    return new Map(registry)
}

/**
 * Get currently active domain modules.
 * @returns {Set<string>}
 */
export function getActiveDomains() {
    return new Set(activeModules)
}

/**
 * Get a specific domain module by name.
 * @param {string} name
 * @returns {DomainModule|null}
 */
export function getDomain(name) {
    return registry.get(name.toLowerCase().trim()) || null
}

/**
 * Match input against all active domain module patterns.
 * Domain verbs take PRIORITY over general patterns when their module is active.
 *
 * @param {string} input - The cleaned, autocorrected input text
 * @returns {{ matched: boolean, ast: Object|null, domain: string|null, pattern: string|null }}
 */
export function matchDomainPattern(input) {
    // Try active modules first (priority)
    for (const name of activeModules) {
        const module = registry.get(name)
        if (!module) continue

        for (const pattern of module.patterns) {
            const m = typeof pattern.match === 'function'
                ? pattern.match(input)
                : input.match(pattern.match)

            if (m) {
                const ast = pattern.resolve(m)
                return {
                    matched: true,
                    ast: { ...ast, _domain: name, _outputType: module.outputType },
                    domain: name,
                    pattern: pattern.match.toString(),
                }
            }
        }
    }

    // If no active modules matched, try ALL registered modules for auto-detection
    for (const [name, module] of registry) {
        if (activeModules.has(name)) continue  // Already tried

        for (const pattern of module.patterns) {
            const m = typeof pattern.match === 'function'
                ? pattern.match(input)
                : input.match(pattern.match)

            if (m) {
                const ast = pattern.resolve(m)
                return {
                    matched: true,
                    ast: { ...ast, _domain: name, _outputType: module.outputType, _autoDetected: true },
                    domain: name,
                    pattern: pattern.match.toString(),
                }
            }
        }
    }

    return { matched: false, ast: null, domain: null, pattern: null }
}

/**
 * Detect `use <module>` directives in source text.
 * Returns the module name if found, null otherwise.
 *
 * @param {string} line - A single line of source
 * @returns {string|null} Module name or null
 */
export function detectUseDomainDirective(line) {
    const m = line.match(/^use\s+(web|data|api|email|schedule|vault)\s*$/i)
    return m ? m[1].toLowerCase() : null
}

/**
 * Get a summary of all registered domains (for docs/API).
 */
export function domainSummary() {
    const summary = []
    for (const [name, module] of registry) {
        summary.push({
            name,
            description: module.description,
            outputType: module.outputType,
            verbCount: module.patterns.length,
            sandboxCapabilities: module.sandboxCapabilities,
            active: activeModules.has(name),
        })
    }
    return summary
}
