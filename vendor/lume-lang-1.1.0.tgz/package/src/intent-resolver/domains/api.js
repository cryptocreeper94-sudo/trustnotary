/**
 * ═══════════════════════════════════════════════════════════
 *  LUME DOMAIN MODULE: API
 *  Natural language → HTTP orchestration
 * ═══════════════════════════════════════════════════════════
 */

function slug(str) {
    return str.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '')
}

const apiDomain = {
    name: 'api',
    description: 'HTTP requests, API chaining, response parsing, and webhooks',
    outputType: 'js',
    sandboxCapabilities: ['fetch'],
    synonymRings: {
        fetch: ['fetch', 'get', 'request', 'call', 'hit'],
        post: ['post', 'send', 'submit', 'push'],
        extract: ['extract', 'get', 'pull', 'grab', 'pluck'],
        poll: ['poll', 'check', 'ping', 'watch'],
    },
    patterns: [
        // ── GET request ──
        {
            match: /^(?:fetch|get|request|call|hit)\s+(?:data\s+from\s+|the\s+)?(?:api\s+(?:at\s+)?)?["""]?(\S+?)["""]?\s*(?:as\s+(json|text|html))?$/i,
            resolve: (m) => ({
                type: 'ApiFetch', method: 'GET', url: m[1], format: m[2] || 'json',
                code: `const __response = await (async()=>{const r=await fetch(${JSON.stringify(m[1])});return await r.${(m[2]||'json')=='json'?'json':'text'}()})();`,
            }),
            tags: ['api', 'http', 'get'],
        },
        // ── POST request ──
        {
            match: /^(?:post|send|submit|push)\s+(?:data\s+)?to\s+["""]?(\S+?)["""]?\s*(?:with\s+(.+))?$/i,
            resolve: (m) => ({
                type: 'ApiFetch', method: 'POST', url: m[1], body: m[2] || null,
                code: `const __response = await (async()=>{const r=await fetch(${JSON.stringify(m[1])},{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(${m[2]||'{}'})});return await r.json()})();`,
            }),
            tags: ['api', 'http', 'post'],
        },
        // ── PUT request ──
        {
            match: /^(?:update|put)\s+(?:data\s+)?(?:at|to)\s+["""]?(\S+?)["""]?\s*(?:with\s+(.+))?$/i,
            resolve: (m) => ({
                type: 'ApiFetch', method: 'PUT', url: m[1], body: m[2] || null,
                code: `const __response = await (async()=>{const r=await fetch(${JSON.stringify(m[1])},{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(${m[2]||'{}'})});return await r.json()})();`,
            }),
            tags: ['api', 'http', 'put'],
        },
        // ── DELETE request ──
        {
            match: /^(?:delete|remove)\s+(?:the\s+)?(?:resource\s+)?(?:at|from)\s+["""]?(\S+?)["""]?$/i,
            resolve: (m) => ({
                type: 'ApiFetch', method: 'DELETE', url: m[1],
                code: `const __response = await (async()=>{const r=await fetch(${JSON.stringify(m[1])},{method:'DELETE'});return r.ok?{deleted:true}:await r.json()})();`,
            }),
            tags: ['api', 'http', 'delete'],
        },
        // ── EXTRACT field from response ──
        {
            match: /^(?:extract|get|pull|grab|pluck)\s+(?:the\s+)?(.+?)\s+from\s+(?:the\s+)?(?:response|result|data|output)$/i,
            resolve: (m) => {
                const path = m[1].split(/\s*\.\s*/).map(slug).join('.')
                return { type: 'ApiExtract', path, code: `const __extracted = __response.${path};` }
            },
            tags: ['api', 'parsing'],
        },
        // ── POLL every N seconds ──
        {
            match: /^(?:poll|check|ping)\s+["""]?(\S+?)["""]?\s+every\s+(\d+)\s*(seconds?|minutes?|s|m)$/i,
            resolve: (m) => {
                const ms = parseInt(m[2]) * (m[3].startsWith('m') ? 60000 : 1000)
                return { type: 'ApiPoll', url: m[1], intervalMs: ms, code: `setInterval(async()=>{const r=await fetch(${JSON.stringify(m[1])});const d=await r.json();console.log(d)},${ms});` }
            },
            tags: ['api', 'polling'],
        },
        // ── CHAIN: fetch then for each ──
        {
            match: /^(?:fetch|get)\s+(.+?)\s+then\s+for\s+each\s+(.+?)\s+(?:fetch|get)\s+(?:their\s+|the\s+)?(.+)$/i,
            resolve: (m) => ({
                type: 'ApiChain', first: m[1], item: slug(m[2]), second: m[3],
                code: `const __chained = await (async()=>{const list=await(await fetch(${JSON.stringify(m[1])})).json();return Promise.all(list.map(async item=>{const detail=await(await fetch(item.url||'')).json();return{...item,...detail}}))})();`,
            }),
            tags: ['api', 'chaining'],
        },
        // ── SET HEADER ──
        {
            match: /^(?:set|add)\s+(?:the\s+)?(?:header|authorization)\s+(.+?)\s+to\s+["""]?(.+?)["""]?$/i,
            resolve: (m) => ({
                type: 'ApiConfig', setting: 'header', key: m[1].trim(), value: m[2].trim(),
                code: `const __headers = {...(__headers||{}), ${JSON.stringify(m[1].trim())}: ${JSON.stringify(m[2].trim())}};`,
            }),
            tags: ['api', 'config'],
        },
        // ── CHECK STATUS ──
        {
            match: /^(?:check|verify)\s+(?:if\s+)?(?:the\s+)?(?:api|endpoint|url)\s+["""]?(\S+?)["""]?\s+is\s+(?:up|alive|working|healthy)$/i,
            resolve: (m) => ({
                type: 'ApiHealthCheck', url: m[1],
                code: `const __healthy = await (async()=>{try{const r=await fetch(${JSON.stringify(m[1])});return r.ok}catch{return false}})();`,
            }),
            tags: ['api', 'health'],
        },
    ],
}

export default apiDomain
