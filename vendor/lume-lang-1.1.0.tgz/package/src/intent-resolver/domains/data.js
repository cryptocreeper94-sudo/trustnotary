/**
 * ═══════════════════════════════════════════════════════════
 *  LUME DOMAIN MODULE: DATA
 *  Natural language → data manipulation + visualization
 * ═══════════════════════════════════════════════════════════
 */

function slug(str) {
    return str.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '')
}

const dataDomain = {
    name: 'data',
    description: 'Read, transform, analyze, and visualize data from CSV, JSON, and APIs',
    outputType: 'data',
    sandboxCapabilities: ['fetch'],
    synonymRings: {
        read: ['read', 'load', 'open', 'import', 'parse'],
        chart: ['chart', 'graph', 'plot', 'visualize', 'draw'],
        filter: ['filter', 'where', 'only', 'exclude'],
        group: ['group', 'categorize', 'bucket'],
        export: ['export', 'download', 'save', 'write out'],
        aggregate: ['sum', 'average', 'count', 'total', 'min', 'max'],
    },
    patterns: [
        // ── READ CSV ──
        {
            match: /^(?:read|load|open|import|parse)\s+(?:the\s+)?(?:csv|CSV)\s*(?:(?:file\s+)?(?:from\s+|at\s+|called\s+)?["""]?(.+?)["""]?)?$/i,
            resolve: (m) => ({
                type: 'DataRead', format: 'csv', source: m[1] || null,
                code: `const __data = await (async()=>{const r=await fetch(${m[1]?JSON.stringify(m[1]):"'data.csv'"});const t=await r.text();const[h,...rows]=t.trim().split('\\n');const k=h.split(',').map(x=>x.trim());return rows.map(r=>{const v=r.split(',');return Object.fromEntries(k.map((x,i)=>[x,v[i]?.trim()]))})})();`,
            }),
            tags: ['data', 'read', 'csv'],
        },
        // ── READ JSON ──
        {
            match: /^(?:read|load|open|import|parse)\s+(?:the\s+)?(?:json|JSON|data)\s*(?:(?:file\s+)?(?:from\s+|at\s+)?["""]?(.+?)["""]?)?$/i,
            resolve: (m) => ({
                type: 'DataRead', format: 'json', source: m[1] || null,
                code: `const __data = await(async()=>{const r=await fetch(${m[1]?JSON.stringify(m[1]):"'data.json'"});return await r.json()})();`,
            }),
            tags: ['data', 'read', 'json'],
        },
        // ── LOAD FROM URL ──
        {
            match: /^(?:load|fetch|get)\s+(?:the\s+)?data\s+from\s+(?:url\s+)?["""]?(.+?)["""]?$/i,
            resolve: (m) => ({
                type: 'DataRead', format: 'auto', source: m[1],
                code: `const __data = await(async()=>{const r=await fetch(${JSON.stringify(m[1])});const ct=r.headers.get('content-type')||'';return ct.includes('json')?await r.json():(await r.text()).trim().split('\\n').map(r=>r.split(','))})();`,
            }),
            tags: ['data', 'read', 'url'],
        },
        // ── FILTER WHERE ──
        {
            match: /^(?:filter|select|pick|only)\s+(?:the\s+)?(?:rows?\s+)?(?:where\s+|that\s+have\s+)?(.+?)\s+(is|equals?|>|<|>=|<=|!=|contains?)\s+(.+)$/i,
            resolve: (m) => {
                const f = slug(m[1]), op = m[2].toLowerCase(), v = m[3].trim()
                let js
                if (op.includes('equal') || op === 'is') js = `r.${f}==${JSON.stringify(v)}`
                else if (op === '>') js = `Number(r.${f})>${v}`
                else if (op === '<') js = `Number(r.${f})<${v}`
                else if (op === '>=') js = `Number(r.${f})>=${v}`
                else if (op === '<=') js = `Number(r.${f})<=${v}`
                else if (op === '!=') js = `r.${f}!=${JSON.stringify(v)}`
                else if (op.includes('contain')) js = `String(r.${f}).includes(${JSON.stringify(v)})`
                else js = `r.${f}==${JSON.stringify(v)}`
                return { type: 'DataTransform', operation: 'filter', field: f, code: `const __data = __data.filter(r=>${js});` }
            },
            tags: ['data', 'transform', 'filter'],
        },
        // ── GROUP BY ──
        {
            match: /^(?:group|categorize|bucket)\s+(?:the\s+)?(?:data\s+)?by\s+(.+)$/i,
            resolve: (m) => {
                const f = slug(m[1])
                return { type: 'DataTransform', operation: 'group', field: f, code: `const __grouped=__data.reduce((a,r)=>{const k=r.${f}||'unknown';(a[k]=a[k]||[]).push(r);return a},{});` }
            },
            tags: ['data', 'transform', 'group'],
        },
        // ── SORT BY ──
        {
            match: /^sort\s+(?:the\s+)?(?:data\s+)?by\s+(.+?)(?:\s+(asc|desc|ascending|descending))?$/i,
            resolve: (m) => {
                const f = slug(m[1]), d = m[2] && m[2].match(/desc/) ? -1 : 1
                return { type: 'DataTransform', operation: 'sort', field: f, code: `__data.sort((a,b)=>(a.${f}<b.${f}?-1:a.${f}>b.${f}?1:0)*${d});` }
            },
            tags: ['data', 'transform', 'sort'],
        },
        // ── AGGREGATE ──
        {
            match: /^(?:calculate\s+)?(?:the\s+)?(?:total|sum|average|avg|count|min|max)\s+(?:of\s+)?(?:the\s+)?(.+)$/i,
            resolve: (m) => {
                const full = m[0].toLowerCase(), f = slug(m[1])
                let op = 'sum'
                if (full.includes('average') || full.includes('avg')) op = 'average'
                else if (full.includes('count')) op = 'count'
                else if (full.includes('min')) op = 'min'
                else if (full.includes('max')) op = 'max'
                const c = { sum: `__data.reduce((s,r)=>s+Number(r.${f}||0),0)`, average: `__data.reduce((s,r)=>s+Number(r.${f}||0),0)/__data.length`, count: `__data.length`, min: `Math.min(...__data.map(r=>Number(r.${f})))`, max: `Math.max(...__data.map(r=>Number(r.${f})))` }
                return { type: 'DataAggregate', operation: op, field: f, code: `const __result = ${c[op]};` }
            },
            tags: ['data', 'aggregate'],
        },
        // ── CHART ──
        {
            match: /^(?:chart|graph|plot|visualize)\s+(?:the\s+)?(.+?)\s+(?:by|per|vs|over)\s+(.+?)(?:\s+(?:as\s+)?(?:a\s+)?(bar|line|pie|doughnut|scatter))?$/i,
            resolve: (m) => {
                const vf = slug(m[1]), lf = slug(m[2]), ct = m[3] || 'bar'
                return { type: 'DataVisualization', chartType: ct, valueField: vf, labelField: lf, code: `(()=>{const g={};__data.forEach(r=>{const k=r.${lf}||'?';g[k]=(g[k]||0)+Number(r.${vf}||0)});return{type:'${ct}',data:{labels:Object.keys(g),datasets:[{label:'${m[1]}',data:Object.values(g),backgroundColor:['#00d4ff','#7b2ff7','#ff6b6b','#ffd93d','#6bcb77','#4d96ff']}]}}})()` }
            },
            tags: ['data', 'visualization', 'chart'],
        },
        // ── EXPORT CSV ──
        {
            match: /^(?:export|save|download)\s+(?:the\s+)?(?:data\s+)?(?:as|to)\s+(?:a\s+)?csv/i,
            resolve: () => ({ type: 'DataExport', format: 'csv', code: `(()=>{if(!__data.length)return'';const k=Object.keys(__data[0]);return[k.join(','),...__data.map(r=>k.map(x=>JSON.stringify(r[x]||'')).join(','))].join('\\n')})()` }),
            tags: ['data', 'export', 'csv'],
        },
        // ── EXPORT JSON ──
        {
            match: /^(?:export|save|download)\s+(?:the\s+)?(?:data\s+)?(?:as|to)\s+(?:a\s+)?json/i,
            resolve: () => ({ type: 'DataExport', format: 'json', code: `JSON.stringify(__data,null,2)` }),
            tags: ['data', 'export', 'json'],
        },
        // ── SHOW TABLE ──
        {
            match: /^(?:show|display|render)\s+(?:the\s+)?(?:data\s+)?(?:as\s+)?(?:a\s+)?table$/i,
            resolve: () => ({ type: 'DataVisualization', chartType: 'table', code: `(()=>{if(!__data.length)return'No data';const k=Object.keys(__data[0]);return'<table><thead><tr>'+k.map(x=>'<th>'+x+'</th>').join('')+'</tr></thead><tbody>'+__data.slice(0,50).map(r=>'<tr>'+k.map(x=>'<td>'+(r[x]||'')+'</td>').join('')+'</tr>').join('')+'</tbody></table>'})()` }),
            tags: ['data', 'visualization', 'table'],
        },
        // ── COUNT ──
        {
            match: /^(?:how\s+many|count)\s+(?:rows?|items?|records?)$/i,
            resolve: () => ({ type: 'DataAggregate', operation: 'count', code: `const __result = __data.length;` }),
            tags: ['data', 'aggregate', 'count'],
        },
    ],
}

export default dataDomain
