/**
 * ═══════════════════════════════════════════════════════════
 *  LUME DOMAIN MODULE: EMAIL
 *  Natural language → email composition (STUBBED)
 *  All send operations require confirmation - no live sends
 *
 *  Constitutional: No unnecessary security risks.
 *  All email verbs produce confirmation prompts, never fire.
 * ═══════════════════════════════════════════════════════════
 */

const emailDomain = {
    name: 'email',
    description: 'Compose and preview emails with templates (sends require confirmation)',
    outputType: 'js',
    sandboxCapabilities: [],
    synonymRings: {
        send: ['send', 'email', 'mail', 'dispatch', 'deliver'],
        compose: ['compose', 'write', 'draft', 'create'],
    },
    patterns: [
        // ── SEND EMAIL TO ──
        {
            match: /^(?:send|email|mail|deliver)\s+(?:an?\s+)?(?:email\s+)?to\s+(\S+@\S+)(?:\s+(?:with\s+)?(?:subject\s+)?["""](.+?)["""])?$/i,
            resolve: (m) => ({
                type: 'EmailCompose', to: m[1], subject: m[2] || null,
                _requiresConfirmation: true,
                code: `/* ✉ EMAIL STUB — requires confirmation */\nconst __emailDraft = { to: ${JSON.stringify(m[1])}, subject: ${JSON.stringify(m[2]||'(no subject)')}, body: '', status: 'draft' };\nconsole.log('[email] Draft created for ' + __emailDraft.to + ' — subject: ' + __emailDraft.subject);\nconsole.log('[email] ⚠ Send requires confirmation via /api/email/confirm');`,
            }),
            tags: ['email', 'send'],
        },
        // ── WITH SUBJECT ──
        {
            match: /^(?:with\s+)?subject\s+["""](.+?)["""]$/i,
            resolve: (m) => ({
                type: 'EmailSubject', subject: m[1],
                code: `if(typeof __emailDraft!=='undefined') __emailDraft.subject = ${JSON.stringify(m[1])};`,
            }),
            tags: ['email', 'compose'],
        },
        // ── WITH BODY ──
        {
            match: /^(?:with\s+)?(?:body|message|content)\s+["""](.+?)["""]$/i,
            resolve: (m) => ({
                type: 'EmailBody', body: m[1],
                code: `if(typeof __emailDraft!=='undefined') __emailDraft.body = ${JSON.stringify(m[1])};`,
            }),
            tags: ['email', 'compose'],
        },
        // ── USE TEMPLATE ──
        {
            match: /^use\s+(?:the\s+)?(welcome|invoice|newsletter|confirmation|reset|onboarding)\s+(?:email\s+)?template$/i,
            resolve: (m) => ({
                type: 'EmailTemplate', template: m[1].toLowerCase(),
                code: `if(typeof __emailDraft!=='undefined') __emailDraft.template = ${JSON.stringify(m[1].toLowerCase())};`,
            }),
            tags: ['email', 'template'],
        },
        // ── SEND TO ALL (Guardian triggers MASS_OPERATIONS) ──
        {
            match: /^(?:send|email)\s+(?:to\s+)?all\s+(?:users?|customers?|subscribers?|members?)\s*(?:in\s+(?:the\s+)?(?:csv|list|database))?$/i,
            resolve: () => ({
                type: 'EmailBulk', _requiresConfirmation: true, _guardianFlag: 'MASS_OPERATIONS',
                code: `/* ✉ BULK EMAIL STUB — requires admin confirmation */\nconsole.log('[email] ⚠ Bulk email requested — this requires admin approval');\nconsole.log('[email] Draft queued. Use /api/email/confirm-bulk to approve.');`,
            }),
            tags: ['email', 'bulk'],
        },
        // ── COMPOSE / DRAFT ──
        {
            match: /^(?:compose|write|draft|create)\s+(?:an?\s+)?email\s+(?:to\s+)?(\S+@\S+)?/i,
            resolve: (m) => ({
                type: 'EmailCompose', to: m[1] || null, _requiresConfirmation: true,
                code: `const __emailDraft = { to: ${JSON.stringify(m[1]||'')}, subject: '', body: '', status: 'draft' };\nconsole.log('[email] New draft created' + (${JSON.stringify(m[1]||'')} ? ' for '+${JSON.stringify(m[1]||'')} : ''));`,
            }),
            tags: ['email', 'compose'],
        },
    ],
}

export default emailDomain
