/**
 * ═══════════════════════════════════════════════════════════
 *  LUME DOMAIN MODULE: SCHEDULE
 *  Natural language → cron expressions + automation metadata
 *  Execution handled by server/scheduler.js
 * ═══════════════════════════════════════════════════════════
 */

/* ── Day name → cron mapping ──────────────────────────── */
const DAYS = { sunday: 0, monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6, sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6 }

function parseDayToCron(dayStr) {
    const d = dayStr.toLowerCase().trim()
    return DAYS[d] !== undefined ? DAYS[d] : '*'
}

function parseTimeToCron(timeStr) {
    const t = timeStr.toLowerCase().trim()
    // Handle "9am", "3pm", "9:30am", "midnight", "noon"
    if (t === 'midnight') return { hour: 0, minute: 0 }
    if (t === 'noon') return { hour: 12, minute: 0 }
    const m = t.match(/^(\d{1,2})(?::(\d{2}))?\s*(am|pm)?$/i)
    if (!m) return { hour: 9, minute: 0 }
    let hour = parseInt(m[1])
    const minute = m[2] ? parseInt(m[2]) : 0
    if (m[3]?.toLowerCase() === 'pm' && hour < 12) hour += 12
    if (m[3]?.toLowerCase() === 'am' && hour === 12) hour = 0
    return { hour, minute }
}

const scheduleDomain = {
    name: 'schedule',
    description: 'Define cron schedules, one-shot timers, and recurring intervals',
    outputType: 'cron',
    sandboxCapabilities: [],
    synonymRings: {
        every: ['every', 'each', 'per'],
        once: ['once', 'one time', 'at'],
        repeat: ['repeat', 'loop', 'recur'],
        daily: ['daily', 'every day', 'each day'],
        weekly: ['weekly', 'every week', 'each week'],
    },
    patterns: [
        // ── EVERY [DAY] AT [TIME] ──
        {
            match: /^every\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday|mon|tue|wed|thu|fri|sat|sun)\s+at\s+(.+)$/i,
            resolve: (m) => {
                const day = parseDayToCron(m[1])
                const { hour, minute } = parseTimeToCron(m[2])
                return {
                    type: 'ScheduleDefinition', scheduleType: 'cron',
                    cronExpression: `${minute} ${hour} * * ${day}`,
                    humanReadable: `Every ${m[1]} at ${m[2]}`,
                }
            },
            tags: ['schedule', 'cron', 'weekly'],
        },
        // ── DAILY AT [TIME] ──
        {
            match: /^(?:daily|every\s+day)\s+at\s+(.+)$/i,
            resolve: (m) => {
                const { hour, minute } = parseTimeToCron(m[1])
                return {
                    type: 'ScheduleDefinition', scheduleType: 'cron',
                    cronExpression: `${minute} ${hour} * * *`,
                    humanReadable: `Daily at ${m[1]}`,
                }
            },
            tags: ['schedule', 'cron', 'daily'],
        },
        // ── EVERY [N] MINUTES/HOURS ──
        {
            match: /^every\s+(\d+)\s*(minutes?|mins?|hours?|hrs?|seconds?|secs?)$/i,
            resolve: (m) => {
                const n = parseInt(m[1])
                const unit = m[2].toLowerCase()
                let cron
                if (unit.startsWith('sec')) cron = `*/${n} * * * * *`
                else if (unit.startsWith('min')) cron = `*/${n} * * * *`
                else if (unit.startsWith('hour') || unit.startsWith('hr')) cron = `0 */${n} * * *`
                else cron = `*/${n} * * * *`
                return {
                    type: 'ScheduleDefinition', scheduleType: 'cron',
                    cronExpression: cron,
                    humanReadable: `Every ${n} ${unit}`,
                }
            },
            tags: ['schedule', 'cron', 'interval'],
        },
        // ── EVERY HOUR / HOURLY ──
        {
            match: /^(?:every\s+hour|hourly)$/i,
            resolve: () => ({
                type: 'ScheduleDefinition', scheduleType: 'cron',
                cronExpression: '0 * * * *',
                humanReadable: 'Every hour',
            }),
            tags: ['schedule', 'cron', 'hourly'],
        },
        // ── ONCE AT [DATETIME] ──
        {
            match: /^once\s+(?:at|on)\s+(.+)$/i,
            resolve: (m) => ({
                type: 'ScheduleDefinition', scheduleType: 'once',
                datetime: m[1].trim(),
                humanReadable: `Once at ${m[1].trim()}`,
            }),
            tags: ['schedule', 'once'],
        },
        // ── REPEAT EVERY [N] [UNIT] ──
        {
            match: /^repeat\s+every\s+(\d+)\s*(minutes?|mins?|hours?|hrs?|seconds?|secs?)$/i,
            resolve: (m) => {
                const n = parseInt(m[1]), u = m[2].toLowerCase()
                let ms = n * 1000
                if (u.startsWith('min')) ms = n * 60000
                else if (u.startsWith('hour') || u.startsWith('hr')) ms = n * 3600000
                return {
                    type: 'ScheduleDefinition', scheduleType: 'interval',
                    intervalMs: ms,
                    humanReadable: `Repeat every ${n} ${m[2]}`,
                }
            },
            tags: ['schedule', 'interval'],
        },
        // ── WEEKDAYS AT [TIME] ──
        {
            match: /^(?:every\s+)?weekdays?\s+at\s+(.+)$/i,
            resolve: (m) => {
                const { hour, minute } = parseTimeToCron(m[1])
                return {
                    type: 'ScheduleDefinition', scheduleType: 'cron',
                    cronExpression: `${minute} ${hour} * * 1-5`,
                    humanReadable: `Weekdays at ${m[1]}`,
                }
            },
            tags: ['schedule', 'cron', 'weekday'],
        },
        // ── WEEKENDS AT [TIME] ──
        {
            match: /^(?:every\s+)?weekends?\s+at\s+(.+)$/i,
            resolve: (m) => {
                const { hour, minute } = parseTimeToCron(m[1])
                return {
                    type: 'ScheduleDefinition', scheduleType: 'cron',
                    cronExpression: `${minute} ${hour} * * 0,6`,
                    humanReadable: `Weekends at ${m[1]}`,
                }
            },
            tags: ['schedule', 'cron', 'weekend'],
        },
        // ── MONTHLY ON [DAY] ──
        {
            match: /^(?:monthly|every\s+month)\s+on\s+(?:the\s+)?(\d{1,2})(?:st|nd|rd|th)?\s*(?:at\s+(.+))?$/i,
            resolve: (m) => {
                const day = parseInt(m[1])
                const { hour, minute } = m[2] ? parseTimeToCron(m[2]) : { hour: 9, minute: 0 }
                return {
                    type: 'ScheduleDefinition', scheduleType: 'cron',
                    cronExpression: `${minute} ${hour} ${day} * *`,
                    humanReadable: `Monthly on the ${m[1]}${m[2] ? ' at ' + m[2] : ''}`,
                }
            },
            tags: ['schedule', 'cron', 'monthly'],
        },
    ],
}

export default scheduleDomain
