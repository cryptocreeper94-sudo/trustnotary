/**
 * ═══════════════════════════════════════════════════════════
 *  LUME DOMAIN MODULE: VAULT (TrustVault Integration)
 *  Natural language → TrustVault API calls
 *
 *  Closes the intent-to-ownership loop:
 *    Lume compiles → Guardian certifies → TrustVault stores provenance
 *
 *  Security: All operations are tenant-scoped at the TrustVault API layer.
 *  The compiled fetch() calls require an authenticated session token.
 *  Delete operations are flagged in the Lume-cert audit trail.
 *
 *  Voice-tested: All verbs speakable via cleanup layer
 * ═══════════════════════════════════════════════════════════
 */

const VAULT_BASE = 'https://trustvault.tlid.io/api'

/* ── Vault Domain Module ─────────────────────────────── */
const vaultDomain = {
    name: 'vault',
    description: 'Store, certify, and manage digital assets in TrustVault with blockchain-verified provenance',
    outputType: 'api',
    sandboxCapabilities: ['fetch'],

    synonymRings: {
        certify:    ['certify', 'hallmark', 'mint', 'register', 'stamp', 'seal'],
        store:      ['store', 'save', 'upload', 'put', 'deposit', 'archive'],
        verify:     ['verify', 'check', 'validate', 'authenticate', 'confirm'],
        list:       ['list', 'show', 'display', 'view', 'get'],
        search:     ['search', 'find', 'look for', 'filter', 'query'],
        share:      ['share', 'send', 'grant access', 'give access'],
        collect:    ['collect', 'organize', 'group', 'bundle', 'folder'],
        provenance: ['provenance', 'origin', 'history', 'chain', 'trail', 'lineage'],
        delete:     ['delete', 'remove', 'trash', 'discard', 'erase'],
        tag:        ['tag', 'label', 'mark', 'categorize', 'classify'],
        favorite:   ['favorite', 'star', 'bookmark', 'pin', 'like'],
    },

    patterns: [
        // ═══ 1. CERTIFY — Create a hallmark provenance record ═══
        {
            match: /^(?:certify|hallmark|mint|register|seal)(?:\s+(?:this|my|the))?\s+(?:asset|render|creation|file|output|work|project|deployment|build)(?:\s+(?:called|named|titled)\s+(.+?))?$/i,
            resolve: (m) => ({
                type: 'VaultCertify',
                productName: m[1] || null,
                description: 'Create a TrustVault hallmark with SHA-256 provenance chain',
                code: `await fetch('${VAULT_BASE}/hallmark', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + __lumeScopeToken },
  body: JSON.stringify({
    appId: 'lume-compiler',
    productName: ${m[1] ? JSON.stringify(m[1]) : '__lumeCert.source.slice(0, 50)'},
    releaseType: 'lume-compiled',
    metadata: {
      lumeCertHash: __lumeCert.hash,
      sourceHash: __lumeCert.sourceHash,
      outputHash: __lumeCert.outputHash,
      guardianScore: __lumeCert.threatScore,
      compiledAt: __lumeCert.timestamp,
      compiler: 'lume-v1.0.0'
    }
  })
}).then(r => r.json())`,
            }),
            tags: ['vault', 'certify', 'hallmark', 'provenance'],
        },

        // ═══ 2. STORE — Upload compiled output to TrustVault ═══
        {
            match: /^(?:store|save|upload|put|deposit|archive)(?:\s+(?:this|my|the))?\s+(?:(?:compiled\s+)?(?:output|result|code|html|file|asset|render|work)|(?:it|this))\s+(?:in|to|into)?\s*(?:my\s+)?(?:vault|trustvault|trust\s*vault|storage)$/i,
            resolve: () => ({
                type: 'VaultStore',
                description: 'Upload compiled output to TrustVault media library',
                code: `await fetch('${VAULT_BASE}/media', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + __lumeScopeToken },
  body: JSON.stringify({
    title: __lumeCert ? __lumeCert.source.slice(0, 80) : 'Lume Output',
    filename: 'lume-output-' + Date.now() + '.html',
    contentType: 'text/html',
    url: __lumeOutputUrl || 'data:text/html;base64,' + btoa(__lumeOutput),
    category: 'document',
    tags: ['lume-compiled', 'auto-stored'],
    provenanceId: __lumeCert ? __lumeCert.hash : undefined
  })
}).then(r => r.json())`,
            }),
            tags: ['vault', 'store', 'upload'],
        },

        // ═══ 3. VERIFY — Check a hallmark's authenticity ═══
        {
            match: /^(?:verify|check|validate|authenticate|confirm)\s+(?:hallmark|provenance|certificate|cert)\s+([A-Z]{2}-\d{8}|[a-f0-9]{8,})$/i,
            resolve: (m) => ({
                type: 'VaultVerify',
                hallmarkId: m[1],
                description: `Verify hallmark ${m[1]} against TrustVault ledger`,
                code: `await fetch('${VAULT_BASE}/hallmark/${m[1]}/verify')
  .then(r => r.json())`,
            }),
            tags: ['vault', 'verify', 'hallmark'],
        },

        // ═══ 4. LIST — Show vault contents ═══
        {
            match: /^(?:list|show|display|view|get)\s+(?:my\s+)?(?:vault\s+)?(?:items|assets|files|media|contents|everything)(?:\s+in\s+(?:my\s+)?(?:vault|storage))?$/i,
            resolve: () => ({
                type: 'VaultList',
                description: 'List all media items in the user\'s TrustVault',
                code: `await fetch('${VAULT_BASE}/media', {
  headers: { 'Authorization': 'Bearer ' + __lumeScopeToken }
}).then(r => r.json())`,
            }),
            tags: ['vault', 'list', 'media'],
        },

        // ═══ 5. SEARCH — Filter vault by category ═══
        {
            match: /^(?:search|find|look\s+for|filter|query)\s+(?:(?:for\s+)?(?:my\s+)?)?(?:(images?|videos?|audio|documents?|renders?)\s+)?(?:in\s+)?(?:my\s+)?(?:vault|storage|trustvault)(?:\s+(?:for|matching|with)\s+(.+))?$/i,
            resolve: (m) => {
                const categoryMap = { image: 'image', images: 'image', video: 'video', videos: 'video', audio: 'audio', document: 'document', documents: 'document', render: 'image', renders: 'image' }
                const category = m[1] ? categoryMap[m[1].toLowerCase()] || 'other' : null
                const query = m[2] || null
                const qs = category ? `?category=${category}` : ''
                return {
                    type: 'VaultSearch',
                    category,
                    query,
                    description: `Search vault${category ? ` for ${category}s` : ''}${query ? ` matching "${query}"` : ''}`,
                    code: `await fetch('${VAULT_BASE}/media${qs}', {
  headers: { 'Authorization': 'Bearer ' + __lumeScopeToken }
}).then(r => r.json())${query ? `.then(items => items.filter(i => i.title.toLowerCase().includes(${JSON.stringify(query.toLowerCase())})))` : ''}`,
                }
            },
            tags: ['vault', 'search', 'filter'],
        },

        // ═══ 6. SHARE — Share a collection with another tenant ═══
        {
            match: /^(?:share|send|give\s+access\s+to)\s+(?:(?:this|my|the)\s+)?(?:collection|folder|bundle)\s+(?:(?:called|named)\s+)?(.+?)\s+(?:with|to)\s+(.+)$/i,
            resolve: (m) => ({
                type: 'VaultShare',
                collectionName: m[1].trim(),
                shareWith: m[2].trim(),
                description: `Share collection "${m[1].trim()}" with ${m[2].trim()}`,
                code: `// Resolve collection by name, then share
const cols = await fetch('${VAULT_BASE}/collections', {
  headers: { 'Authorization': 'Bearer ' + __lumeScopeToken }
}).then(r => r.json());
const col = cols.find(c => c.name.toLowerCase() === ${JSON.stringify(m[1].trim().toLowerCase())});
if (!col) throw new Error('Collection not found: ${m[1].trim()}');
await fetch('${VAULT_BASE}/collections/' + col.id + '/share', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + __lumeScopeToken },
  body: JSON.stringify({ sharedWithTenantIds: [${JSON.stringify(m[2].trim())}] })
}).then(r => r.json())`,
            }),
            tags: ['vault', 'share', 'collection'],
        },

        // ═══ 7. COLLECT — Create a new collection ═══
        {
            match: /^(?:create|make|add|start)\s+(?:a\s+)?(?:new\s+)?(?:collection|folder|bundle|group)\s+(?:(?:called|named|titled)\s+)?(.+?)(?:\s+(?:in|for)\s+(?:my\s+)?(?:vault|storage))?$/i,
            resolve: (m) => ({
                type: 'VaultCollection',
                name: m[1].trim(),
                description: `Create collection "${m[1].trim()}" in TrustVault`,
                code: `await fetch('${VAULT_BASE}/collections', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + __lumeScopeToken },
  body: JSON.stringify({ name: ${JSON.stringify(m[1].trim())} })
}).then(r => r.json())`,
            }),
            tags: ['vault', 'collection', 'organize'],
        },

        // ═══ 8. STAMP — Create a lightweight trust stamp ═══
        {
            match: /^(?:trust\s+)?stamp\s+(?:this|my|the)\s+(?:deployment|build|output|project|asset|release|version)(?:\s+(?:as|with\s+category)\s+(.+))?$/i,
            resolve: (m) => ({
                type: 'VaultStamp',
                category: m[1] || 'lume-output',
                description: 'Create a trust stamp (lightweight provenance record)',
                code: `await fetch('${VAULT_BASE}/trust-stamps', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + __lumeScopeToken },
  body: JSON.stringify({
    category: ${JSON.stringify(m[1] || 'lume-output')},
    data: {
      source: 'lume-compiler',
      lumeCertHash: __lumeCert ? __lumeCert.hash : 'uncertified',
      timestamp: new Date().toISOString()
    }
  })
}).then(r => r.json())`,
            }),
            tags: ['vault', 'stamp', 'provenance'],
        },

        // ═══ 9. PROVENANCE — Show full provenance chain ═══
        {
            match: /^(?:show|get|view|display)\s+(?:the\s+)?(?:provenance|origin|history|chain|lineage|trail)\s+(?:for|of)\s+(?:asset|item|media|file)\s+(\d+)$/i,
            resolve: (m) => ({
                type: 'VaultProvenance',
                assetId: parseInt(m[1], 10),
                description: `Show full provenance chain for asset #${m[1]}`,
                code: `await fetch('${VAULT_BASE}/media/${m[1]}', {
  headers: { 'Authorization': 'Bearer ' + __lumeScopeToken }
}).then(r => r.json()).then(item => ({
  id: item.id,
  title: item.title,
  fileHash: item.fileHash,
  provenanceId: item.provenanceId,
  provenanceTxHash: item.provenanceTxHash,
  provenanceBlockNumber: item.provenanceBlockNumber,
  provenanceTimestamp: item.provenanceTimestamp,
  createdAt: item.createdAt
}))`,
            }),
            tags: ['vault', 'provenance', 'chain'],
        },

        // ═══ 10. STATS — Show vault usage statistics ═══
        {
            match: /^(?:show|get|view|display|what(?:'s|\s+is))\s+(?:my\s+)?(?:vault\s+)?(?:stats|statistics|usage|storage|space|quota)$/i,
            resolve: () => ({
                type: 'VaultStats',
                description: 'Show vault storage statistics and usage breakdown',
                code: `await fetch('${VAULT_BASE}/stats', {
  headers: { 'Authorization': 'Bearer ' + __lumeScopeToken }
}).then(r => r.json())`,
            }),
            tags: ['vault', 'stats', 'usage'],
        },

        // ═══ 11. FAVORITE — Toggle favorite on an asset ═══
        {
            match: /^(?:favorite|star|bookmark|pin|like|unfavorite|unstar|unpin)\s+(?:(?:this|my|the)\s+)?(?:asset|item|file|media)?\s*(?:#?\s*)?(\d+)?$/i,
            resolve: (m) => {
                const id = m[1] || '__lastAssetId'
                const isFav = !/^(?:un)/.test(m[0])
                return {
                    type: 'VaultFavorite',
                    assetId: m[1] ? parseInt(m[1], 10) : null,
                    isFavorite: isFav,
                    description: `${isFav ? 'Favorite' : 'Unfavorite'} asset${m[1] ? ` #${m[1]}` : ''}`,
                    code: `await fetch('${VAULT_BASE}/media/${id}/favorite', {
  method: 'PATCH',
  headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + __lumeScopeToken },
  body: JSON.stringify({ isFavorite: ${isFav} })
}).then(r => r.json())`,
                }
            },
            tags: ['vault', 'favorite', 'organize'],
        },

        // ═══ 12. TAG — Add tags to an asset ═══
        {
            match: /^(?:tag|label|mark|categorize|classify)\s+(?:(?:this|my|the)\s+)?(?:asset|item|file|media)?\s*(?:#?\s*)?(\d+)?\s+(?:with|as)\s+(.+)$/i,
            resolve: (m) => {
                const id = m[1] || '__lastAssetId'
                const tags = m[2].split(/,\s*|\s+and\s+/).map(t => t.trim().toLowerCase())
                return {
                    type: 'VaultTag',
                    assetId: m[1] ? parseInt(m[1], 10) : null,
                    tags,
                    description: `Tag asset with: ${tags.join(', ')}`,
                    code: `await fetch('${VAULT_BASE}/media/${id}', {
  method: 'PATCH',
  headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + __lumeScopeToken },
  body: JSON.stringify({ tags: ${JSON.stringify(tags)} })
}).then(r => r.json())`,
                }
            },
            tags: ['vault', 'tag', 'organize'],
        },

        // ═══ 13. DELETE — Remove an asset (tenant-scoped, audit-logged) ═══
        {
            match: /^(?:delete|remove|trash|discard|erase)\s+(?:(?:this|my|the)\s+)?(?:asset|item|file|media)\s*(?:#?\s*)?(\d+)\s*(?:from\s+(?:my\s+)?(?:vault|storage))?$/i,
            resolve: (m) => ({
                type: 'VaultDelete',
                assetId: parseInt(m[1], 10),
                destructive: true,
                description: `Delete asset #${m[1]} from vault (tenant-scoped, requires auth)`,
                code: `if (!confirm('Delete asset #${m[1]} from your vault? This cannot be undone.')) throw new Error('Delete cancelled by user');
await fetch('${VAULT_BASE}/media/${m[1]}', {
  method: 'DELETE',
  headers: { 'Authorization': 'Bearer ' + __lumeScopeToken }
}).then(r => { if (!r.ok) throw new Error('Delete failed: ' + r.status); return { deleted: true, id: ${m[1]} }; })`,
            }),
            tags: ['vault', 'delete', 'destructive'],
        },

        // ═══ 14. HISTORY — Show vault activity log ═══
        {
            match: /^(?:show|get|view|display|what)\s+(?:my\s+)?(?:vault\s+)?(?:activity|history|log|recent\s+actions|audit\s+log|audit\s+trail)$/i,
            resolve: () => ({
                type: 'VaultHistory',
                description: 'Show recent vault activity log (audit trail)',
                code: `await fetch('${VAULT_BASE}/activity', {
  headers: { 'Authorization': 'Bearer ' + __lumeScopeToken }
}).then(r => r.json())`,
            }),
            tags: ['vault', 'history', 'audit'],
        },
    ],
}

export default vaultDomain
