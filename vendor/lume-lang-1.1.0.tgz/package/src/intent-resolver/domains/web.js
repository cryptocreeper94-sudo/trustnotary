/**
 * ═══════════════════════════════════════════════════════════
 *  LUME DOMAIN MODULE: WEB
 *  Natural language → HTML/CSS/JS compilation
 *  Ported from TrustGen's LumeStudioAgent patterns
 *
 *  Voice-tested: All verbs speakable via cleanup layer
 * ═══════════════════════════════════════════════════════════
 */

/* ── Helper: slugify for identifiers ──────────────────── */
function slug(str) {
    return str.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '')
}

/* ── Template Definitions ─────────────────────────────── */
const TEMPLATES = {
    'landing page': {
        html: (title, desc) => `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title}</title>
<style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Inter',system-ui,sans-serif;color:#e0e0e0;background:#0a0a0f}
.hero{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;background:linear-gradient(135deg,#0a0a0f 0%,#1a1a2e 50%,#0a0a0f 100%);padding:2rem}
.hero h1{font-size:3.5rem;background:linear-gradient(135deg,#00d4ff,#7b2ff7);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:1rem}
.hero p{font-size:1.25rem;color:#a0a0b0;max-width:600px;margin-bottom:2rem}
.btn{display:inline-block;padding:0.875rem 2rem;background:linear-gradient(135deg,#00d4ff,#7b2ff7);border:none;border-radius:8px;color:#fff;font-size:1rem;font-weight:600;cursor:pointer;text-decoration:none;transition:transform 0.2s}
.btn:hover{transform:translateY(-2px)}</style></head>
<body><section class="hero"><h1>${title}</h1><p>${desc || 'Welcome to our site.'}</p><a href="#" class="btn">Get Started</a></section></body></html>`,
    },
    'portfolio': {
        html: (title) => `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title} — Portfolio</title>
<style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Inter',system-ui,sans-serif;background:#0a0a0f;color:#e0e0e0}
header{padding:2rem 4rem;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid rgba(255,255,255,0.08)}
header h2{font-size:1.5rem;background:linear-gradient(135deg,#00d4ff,#7b2ff7);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
nav a{color:#a0a0b0;text-decoration:none;margin-left:2rem;transition:color 0.2s}nav a:hover{color:#00d4ff}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:2rem;padding:4rem}
.card{background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:12px;padding:2rem;transition:transform 0.2s,border-color 0.2s}
.card:hover{transform:translateY(-4px);border-color:rgba(0,212,255,0.3)}.card h3{margin-bottom:0.5rem;color:#fff}.card p{color:#a0a0b0;font-size:0.9rem}</style></head>
<body><header><h2>${title}</h2><nav><a href="#">Work</a><a href="#">About</a><a href="#">Contact</a></nav></header>
<main class="grid"><div class="card"><h3>Project One</h3><p>Description of your first project.</p></div>
<div class="card"><h3>Project Two</h3><p>Description of your second project.</p></div>
<div class="card"><h3>Project Three</h3><p>Description of your third project.</p></div></main></body></html>`,
    },
    'restaurant': {
        html: (name) => `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${name}</title>
<style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Inter',system-ui,sans-serif;background:#0a0a0f;color:#e0e0e0}
.hero{min-height:80vh;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:2rem;background:linear-gradient(180deg,#1a0a0a 0%,#0a0a0f 100%)}
.hero h1{font-size:3.5rem;color:#fff;margin-bottom:0.5rem}.hero .tagline{font-size:1.2rem;color:#d4a574;margin-bottom:2rem}
.menu{max-width:800px;margin:4rem auto;padding:0 2rem}.menu h2{text-align:center;color:#d4a574;margin-bottom:2rem;font-size:2rem}
.menu-item{display:flex;justify-content:space-between;padding:1rem 0;border-bottom:1px solid rgba(255,255,255,0.06)}
.menu-item .name{font-weight:600;color:#fff}.menu-item .price{color:#d4a574;font-weight:600}
.menu-item .desc{font-size:0.85rem;color:#a0a0b0;margin-top:0.25rem}</style></head>
<body><section class="hero"><h1>${name}</h1><p class="tagline">Fine Dining Experience</p><a href="#menu" style="color:#d4a574;font-size:1rem">View Menu ↓</a></section>
<section class="menu" id="menu"><h2>Our Menu</h2>
<div class="menu-item"><div><span class="name">Appetizer</span><p class="desc">Seasonal selection</p></div><span class="price">$14</span></div>
<div class="menu-item"><div><span class="name">Main Course</span><p class="desc">Chef's special</p></div><span class="price">$32</span></div>
<div class="menu-item"><div><span class="name">Dessert</span><p class="desc">House favorite</p></div><span class="price">$12</span></div></section></body></html>`,
    },
    'saas': {
        html: (name, desc) => `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${name}</title>
<style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Inter',system-ui,sans-serif;background:#0a0a0f;color:#e0e0e0}
nav{display:flex;justify-content:space-between;align-items:center;padding:1.5rem 4rem;border-bottom:1px solid rgba(255,255,255,0.06)}
nav .logo{font-size:1.25rem;font-weight:700;background:linear-gradient(135deg,#00d4ff,#7b2ff7);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
nav .links a{color:#a0a0b0;margin-left:2rem;text-decoration:none}nav .links a:hover{color:#00d4ff}
.hero{text-align:center;padding:8rem 2rem 4rem;max-width:800px;margin:0 auto}
.hero h1{font-size:3.5rem;color:#fff;line-height:1.15;margin-bottom:1.5rem}.hero p{font-size:1.2rem;color:#a0a0b0;margin-bottom:2rem}
.cta{display:inline-block;padding:0.875rem 2rem;background:linear-gradient(135deg,#00d4ff,#7b2ff7);border-radius:8px;color:#fff;font-weight:600;text-decoration:none;margin-right:1rem}
.cta-secondary{display:inline-block;padding:0.875rem 2rem;border:1px solid rgba(255,255,255,0.15);border-radius:8px;color:#e0e0e0;text-decoration:none}
.features{display:grid;grid-template-columns:repeat(3,1fr);gap:2rem;max-width:1000px;margin:4rem auto;padding:0 2rem}
.feature{text-align:center;padding:2rem}.feature .icon{font-size:2rem;margin-bottom:1rem}
.feature h3{color:#fff;margin-bottom:0.5rem}.feature p{color:#a0a0b0;font-size:0.9rem}</style></head>
<body><nav><span class="logo">${name}</span><div class="links"><a href="#">Features</a><a href="#">Pricing</a><a href="#">Login</a></div></nav>
<section class="hero"><h1>${desc || 'The modern platform for modern teams.'}</h1><p>Streamline your workflow and boost productivity.</p>
<a href="#" class="cta">Start Free Trial</a><a href="#" class="cta-secondary">Learn More</a></section>
<section class="features"><div class="feature"><div class="icon">⚡</div><h3>Fast</h3><p>Lightning performance</p></div>
<div class="feature"><div class="icon">🔒</div><h3>Secure</h3><p>Enterprise-grade security</p></div>
<div class="feature"><div class="icon">📊</div><h3>Analytics</h3><p>Rich insights built in</p></div></section></body></html>`,
    },
}

/* ── Web Domain Module ────────────────────────────────── */
const webDomain = {
    name: 'web',
    description: 'Create web pages, UI components, and full websites from natural language',
    outputType: 'html',
    sandboxCapabilities: ['dom'],

    synonymRings: {
        page: ['page', 'website', 'site', 'webpage', 'web page'],
        section: ['section', 'area', 'block', 'part', 'region'],
        navbar: ['navbar', 'navigation', 'nav bar', 'menu bar', 'header nav', 'top bar'],
        hero: ['hero', 'hero section', 'banner', 'header section', 'splash', 'intro'],
        footer: ['footer', 'bottom', 'page footer', 'site footer'],
        form: ['form', 'contact form', 'input form', 'submission form', 'sign up form'],
        button: ['button', 'btn', 'call to action', 'cta'],
        card: ['card', 'tile', 'panel', 'box'],
        grid: ['grid', 'layout', 'columns', 'row'],
        image: ['image', 'picture', 'photo', 'img', 'graphic'],
    },

    patterns: [
        // ── CREATE PAGE (with template) ──
        {
            match: /^(?:create|make|build|generate)(?:\s+(?:me|us))?\s+(?:a\s+)?(?:landing\s+page|website|site|web\s*page|page)\s+(?:for|about|called)\s+(?:(?:my|our|a|the)\s+)?(.+?)(?:\s+(?:with|that\s+has|including)\s+(.+))?$/i,
            resolve: (m) => {
                const name = m[1].trim()
                const extras = m[2] || ''
                // Detect template type from name/context
                const lower = (name + ' ' + extras).toLowerCase()
                let template = 'landing page'
                if (lower.includes('restaurant') || lower.includes('bakery') || lower.includes('cafe') || lower.includes('food') || lower.includes('menu')) template = 'restaurant'
                else if (lower.includes('portfolio') || lower.includes('resume') || lower.includes('personal')) template = 'portfolio'
                else if (lower.includes('saas') || lower.includes('startup') || lower.includes('app') || lower.includes('software') || lower.includes('platform')) template = 'saas'

                const gen = TEMPLATES[template]
                return {
                    type: 'WebPageGeneration',
                    template,
                    title: name,
                    description: extras || null,
                    html: gen.html(name, extras),
                }
            },
            tags: ['web', 'page', 'template'],
        },

        // ── ADD HERO SECTION ──
        {
            match: /^(?:add|create|put|insert)\s+(?:a\s+)?(?:hero\s+(?:section|banner|area)|splash|banner|intro\s+(?:section|area))\s*(?:(?:with|saying|that\s+says)\s+(.+))?$/i,
            resolve: (m) => ({
                type: 'WebComponent',
                component: 'hero',
                content: m[1] || null,
                html: `<section class="hero"><h1>${m[1] || 'Welcome'}</h1></section>`,
                css: `.hero{min-height:60vh;display:flex;align-items:center;justify-content:center;text-align:center;background:linear-gradient(135deg,#0a0a0f,#1a1a2e);padding:2rem}.hero h1{font-size:3.5rem;background:linear-gradient(135deg,#00d4ff,#7b2ff7);-webkit-background-clip:text;-webkit-text-fill-color:transparent}`,
            }),
            tags: ['web', 'component', 'hero'],
        },

        // ── ADD NAVBAR ──
        {
            match: /^(?:add|create|put|insert)\s+(?:a\s+)?(?:nav\s*bar|navigation|header\s+nav|top\s+bar|menu\s+bar)\s*(?:(?:with|having|containing)\s+(?:links?\s+(?:to\s+)?)?(.+))?$/i,
            resolve: (m) => {
                const links = m[1] ? m[1].split(/,\s*|\s+and\s+/).map(l => l.trim()) : ['Home', 'About', 'Contact']
                const linkHtml = links.map(l => `<a href="#${slug(l)}">${l}</a>`).join('')
                return {
                    type: 'WebComponent',
                    component: 'navbar',
                    links,
                    html: `<nav class="navbar"><span class="logo">Logo</span><div class="nav-links">${linkHtml}</div></nav>`,
                    css: `.navbar{display:flex;justify-content:space-between;align-items:center;padding:1.5rem 4rem;background:rgba(10,10,15,0.95);border-bottom:1px solid rgba(255,255,255,0.06)}.logo{font-size:1.25rem;font-weight:700;color:#fff}.nav-links a{color:#a0a0b0;text-decoration:none;margin-left:2rem;transition:color 0.2s}.nav-links a:hover{color:#00d4ff}`,
                }
            },
            tags: ['web', 'component', 'navbar'],
        },

        // ── ADD CONTACT FORM ──
        {
            match: /^(?:add|create|put|insert)\s+(?:a\s+)?(?:contact\s+form|form|sign\s*up\s+form|email\s+form|submission\s+form)\s*(?:(?:with|having|for)\s+(.+))?$/i,
            resolve: (m) => ({
                type: 'WebComponent',
                component: 'form',
                fields: m[1] ? m[1].split(/,\s*|\s+and\s+/) : ['name', 'email', 'message'],
                html: `<form class="contact-form"><h2>Get In Touch</h2><input type="text" placeholder="Your Name" required><input type="email" placeholder="Your Email" required><textarea placeholder="Your Message" rows="4" required></textarea><button type="submit" class="btn">Send</button></form>`,
                css: `.contact-form{max-width:500px;margin:4rem auto;padding:2rem;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:12px}.contact-form h2{color:#fff;margin-bottom:1.5rem;text-align:center}.contact-form input,.contact-form textarea{width:100%;padding:0.875rem;margin-bottom:1rem;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);border-radius:8px;color:#e0e0e0;font-size:1rem;outline:none}.contact-form input:focus,.contact-form textarea:focus{border-color:#00d4ff}.contact-form .btn{width:100%;padding:0.875rem;background:linear-gradient(135deg,#00d4ff,#7b2ff7);border:none;border-radius:8px;color:#fff;font-size:1rem;font-weight:600;cursor:pointer}`,
            }),
            tags: ['web', 'component', 'form'],
        },

        // ── ADD FOOTER ──
        {
            match: /^(?:add|create|put|insert)\s+(?:a\s+)?(?:footer|page\s+footer|site\s+footer|bottom\s+(?:section|bar))\s*(?:(?:with|saying|containing)\s+(.+))?$/i,
            resolve: (m) => ({
                type: 'WebComponent',
                component: 'footer',
                content: m[1] || null,
                html: `<footer class="site-footer"><p>${m[1] || '© 2026 All rights reserved.'}</p></footer>`,
                css: `.site-footer{text-align:center;padding:3rem 2rem;border-top:1px solid rgba(255,255,255,0.06);color:#606070;font-size:0.85rem}`,
            }),
            tags: ['web', 'component', 'footer'],
        },

        // ── ADD BUTTON ──
        {
            match: /^(?:add|create|put|insert)\s+(?:a\s+)?(?:button|btn|call\s+to\s+action|cta)\s+(?:(?:that\s+)?says?\s+|saying\s+|labeled?\s+|with\s+text\s+)?["""]?(.+?)["""]?\s*$/i,
            resolve: (m) => ({
                type: 'WebComponent',
                component: 'button',
                text: m[1],
                html: `<button class="btn">${m[1]}</button>`,
                css: `.btn{display:inline-block;padding:0.875rem 2rem;background:linear-gradient(135deg,#00d4ff,#7b2ff7);border:none;border-radius:8px;color:#fff;font-size:1rem;font-weight:600;cursor:pointer;transition:transform 0.2s}.btn:hover{transform:translateY(-2px)}`,
            }),
            tags: ['web', 'component', 'button'],
        },

        // ── ADD CARD / GRID ──
        {
            match: /^(?:add|create|put|insert)\s+(?:a\s+)?(?:card|tile|panel)\s+(?:for|about|with\s+title)\s+["""]?(.+?)["""]?\s*(?:(?:and|with)\s+(?:description|text|content)\s+["""]?(.+?)["""]?)?$/i,
            resolve: (m) => ({
                type: 'WebComponent',
                component: 'card',
                title: m[1],
                description: m[2] || null,
                html: `<div class="card"><h3>${m[1]}</h3>${m[2] ? `<p>${m[2]}</p>` : ''}</div>`,
                css: `.card{background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:12px;padding:2rem;transition:transform 0.2s,border-color 0.2s}.card:hover{transform:translateY(-4px);border-color:rgba(0,212,255,0.3)}.card h3{color:#fff;margin-bottom:0.5rem}.card p{color:#a0a0b0;font-size:0.9rem}`,
            }),
            tags: ['web', 'component', 'card'],
        },

        // ── MAKE IT DARK MODE ──
        {
            match: /^(?:make|switch|change|set)\s+(?:it|this|the\s+(?:page|site))?\s*(?:to\s+)?(?:dark\s+mode|dark\s+theme|dark)$/i,
            resolve: () => ({
                type: 'WebStyleModification',
                modification: 'dark-mode',
                css: `body{background:#0a0a0f!important;color:#e0e0e0!important}a{color:#00d4ff}`,
            }),
            tags: ['web', 'style', 'theme'],
        },

        // ── MAKE IT LIGHT MODE ──
        {
            match: /^(?:make|switch|change|set)\s+(?:it|this|the\s+(?:page|site))?\s*(?:to\s+)?(?:light\s+mode|light\s+theme|light)$/i,
            resolve: () => ({
                type: 'WebStyleModification',
                modification: 'light-mode',
                css: `body{background:#ffffff!important;color:#1a1a2e!important}a{color:#7b2ff7}`,
            }),
            tags: ['web', 'style', 'theme'],
        },

        // ── STYLE: Change color ──
        {
            match: /^(?:make|change|set)\s+(?:the\s+)?(?:background|bg|header|text|title|heading)\s+(?:color\s+)?(?:to\s+)?(.+)$/i,
            resolve: (m) => {
                const target = m[0].match(/(?:background|bg|header|text|title|heading)/i)[0].toLowerCase()
                const color = m[1].trim()
                const prop = (target === 'background' || target === 'bg') ? 'background' : 'color'
                const selector = (target === 'header' || target === 'title' || target === 'heading') ? 'h1,h2,h3' : 'body'
                return {
                    type: 'WebStyleModification',
                    modification: 'color-change',
                    target,
                    color,
                    css: `${selector}{${prop}:${color}!important}`,
                }
            },
            tags: ['web', 'style', 'color'],
        },

        // ── ADD IMAGE ──
        {
            match: /^(?:add|insert|put)\s+(?:an?\s+)?(?:image|picture|photo|graphic)\s*(?:(?:of|showing|from)\s+(.+))?$/i,
            resolve: (m) => ({
                type: 'WebComponent',
                component: 'image',
                description: m[1] || 'placeholder',
                html: `<img class="content-image" src="https://via.placeholder.com/800x400?text=${encodeURIComponent(m[1] || 'Image')}" alt="${m[1] || 'Image'}">`,
                css: `.content-image{width:100%;max-width:800px;border-radius:12px;margin:2rem auto;display:block}`,
            }),
            tags: ['web', 'component', 'media'],
        },

        // ── ADD TEXT / PARAGRAPH ──
        {
            match: /^(?:add|write|put|insert)\s+(?:a\s+)?(?:paragraph|text|copy|content)\s+(?:that\s+)?(?:says?\s+|saying\s+|reading\s+)?["""](.+?)["""]$/i,
            resolve: (m) => ({
                type: 'WebComponent',
                component: 'text',
                content: m[1],
                html: `<p class="content-text">${m[1]}</p>`,
                css: `.content-text{max-width:700px;margin:2rem auto;padding:0 2rem;color:#a0a0b0;font-size:1.1rem;line-height:1.7}`,
            }),
            tags: ['web', 'component', 'text'],
        },

        // ── ADD HEADING ──
        {
            match: /^(?:add|write|put|insert)\s+(?:a\s+)?(?:heading|title|headline|h[1-6])\s+(?:that\s+)?(?:says?\s+|saying\s+|reading\s+)?["""](.+?)["""]$/i,
            resolve: (m) => ({
                type: 'WebComponent',
                component: 'heading',
                content: m[1],
                html: `<h2 class="section-heading">${m[1]}</h2>`,
                css: `.section-heading{text-align:center;font-size:2.5rem;color:#fff;margin:3rem auto 1rem;max-width:800px}`,
            }),
            tags: ['web', 'component', 'text'],
        },

        // ── MAKE IT RESPONSIVE ──
        {
            match: /^(?:make|ensure)\s+(?:it|this|the\s+(?:page|site))\s+(?:is\s+)?(?:responsive|mobile\s+friendly|work\s+on\s+(?:mobile|phones?))$/i,
            resolve: () => ({
                type: 'WebStyleModification',
                modification: 'responsive',
                css: `@media(max-width:768px){.hero h1{font-size:2rem}.grid,.features{grid-template-columns:1fr}.navbar{padding:1rem 2rem;flex-direction:column;gap:1rem}.nav-links{display:flex;flex-wrap:wrap;justify-content:center}}`,
            }),
            tags: ['web', 'style', 'responsive'],
        },

        // ── ADD SECTION (generic) ──
        {
            match: /^(?:add|create|insert)\s+(?:a\s+)?(?:new\s+)?section\s+(?:(?:called|named|titled|for|about)\s+)?["""]?(.+?)["""]?\s*$/i,
            resolve: (m) => ({
                type: 'WebComponent',
                component: 'section',
                title: m[1],
                html: `<section class="content-section"><h2>${m[1]}</h2></section>`,
                css: `.content-section{max-width:1000px;margin:4rem auto;padding:0 2rem}.content-section h2{font-size:2rem;color:#fff;margin-bottom:1.5rem}`,
            }),
            tags: ['web', 'component', 'section'],
        },
    ],
}

export default webDomain
