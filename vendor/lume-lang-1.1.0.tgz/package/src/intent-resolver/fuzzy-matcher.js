/**
 * ═══════════════════════════════════════════════════════════
 *  LUME INTENT RESOLVER — Fuzzy Matcher
 *  Levenshtein distance, word-bag matching, phonetic matching,
 *  common misspelling dictionary
 * ═══════════════════════════════════════════════════════════
 */

/* ── Levenshtein Distance ────────────────────────────── */
export function levenshtein(a, b) {
    const la = a.length, lb = b.length
    const dp = Array.from({ length: la + 1 }, (_, i) => {
        const row = new Array(lb + 1)
        row[0] = i
        return row
    })
    for (let j = 1; j <= lb; j++) dp[0][j] = j
    for (let i = 1; i <= la; i++) {
        for (let j = 1; j <= lb; j++) {
            const cost = a[i - 1] === b[j - 1] ? 0 : 1
            dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost)
        }
    }
    return dp[la][lb]
}

/**
 * Similarity ratio: 0.0 (completely different) to 1.0 (identical)
 */
export function similarity(a, b) {
    if (a === b) return 1.0
    const maxLen = Math.max(a.length, b.length)
    if (maxLen === 0) return 1.0
    return 1 - levenshtein(a.toLowerCase(), b.toLowerCase()) / maxLen
}

/* ── Word-Bag Matching ───────────────────────────────── */
const STOP_WORDS = new Set([
    'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
    'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
    'should', 'may', 'might', 'shall', 'can', 'need', 'dare',
    'to', 'of', 'in', 'for', 'on', 'with', 'at', 'by', 'from',
    'into', 'through', 'during', 'before', 'after', 'above', 'below',
    'between', 'under', 'over', 'about', 'against', 'along', 'among',
    'around', 'upon', 'within', 'without', 'toward', 'towards',
    'it', 'its', 'this', 'that', 'these', 'those', 'such',
    'i', 'me', 'my', 'mine', 'we', 'us', 'our', 'ours',
    'you', 'your', 'yours', 'he', 'him', 'his', 'she', 'her', 'hers',
    'they', 'them', 'their', 'theirs', 'who', 'whom', 'whose',
    'which', 'what', 'where', 'when', 'why', 'how',
    'and', 'or', 'but', 'so', 'if', 'then', 'than', 'nor', 'yet',
    'not', 'no', 'neither', 'either', 'both', 'each', 'every', 'any',
    'some', 'all', 'most', 'more', 'less', 'few', 'many', 'much',
    'just', 'please', 'also', 'too', 'very', 'really', 'quite',
    'only', 'even', 'still', 'already', 'ever', 'never', 'always',
    'here', 'there', 'now', 'again', 'further', 'once',
])

export function extractKeyWords(sentence) {
    return sentence.toLowerCase()
        .replace(/[^\w\s]/g, '')
        .split(/\s+/)
        .filter(w => w.length > 1 && !STOP_WORDS.has(w))
}

/**
 * Word-bag similarity: ratio of shared key words
 */
export function wordBagSimilarity(a, b) {
    const wordsA = new Set(extractKeyWords(a))
    const wordsB = new Set(extractKeyWords(b))
    if (wordsA.size === 0 || wordsB.size === 0) return 0
    let shared = 0
    for (const w of wordsA) if (wordsB.has(w)) shared++
    return (shared * 2) / (wordsA.size + wordsB.size)
}

/* ── Phonetic Matching (Soundex) ─────────────────────── */
export function soundex(word) {
    const s = word.toUpperCase()
    const map = {
        B: 1, F: 1, P: 1, V: 1, C: 2, G: 2, J: 2, K: 2, Q: 2, S: 2, X: 2, Z: 2,
        D: 3, T: 3, L: 4, M: 5, N: 5, R: 6
    }
    let result = s[0]
    let prev = map[s[0]] || 0
    for (let i = 1; i < s.length && result.length < 4; i++) {
        const code = map[s[i]] || 0
        if (code && code !== prev) result += code
        prev = code
    }
    return result.padEnd(4, '0')
}

export function phoneticMatch(a, b) {
    return soundex(a) === soundex(b)
}

/* ═══════════════════════════════════════════════════════════════
 *  COMMON MISSPELLING DICTIONARY — 1,000+ entries
 *  Covers: programming keywords, tech terms, general English,
 *  voice-transcription errors, and common typing patterns.
 *
 *  Architecture note: this dictionary handles EXACT misspelling
 *  matches. The fuzzy matcher (Levenshtein + Soundex) handles
 *  anything NOT in this dictionary by similarity matching.
 *  Together they provide near-zero error tolerance.
 * ═══════════════════════════════════════════════════════════════ */
export const commonMisspellings = {

    // ── Programming Keywords & Core Terms ─────────────────────
    'fucntion': 'function', 'funtion': 'function', 'funciton': 'function',
    'functoin': 'function', 'fuction': 'function', 'funcion': 'function',
    'funtcion': 'function', 'functon': 'function', 'fnuction': 'function',
    'fynction': 'function', 'functin': 'function', 'funktoin': 'function',
    'retrun': 'return', 'reutrn': 'return', 'retrn': 'return',
    'retunr': 'return', 'reutrn': 'return', 'returm': 'return',
    'rteurn': 'return', 'retutn': 'return', 'reeturn': 'return',
    'varibale': 'variable', 'varialbe': 'variable', 'varaiable': 'variable',
    'variabel': 'variable', 'varialble': 'variable', 'varaible': 'variable',
    'variablee': 'variable', 'varble': 'variable', 'vraible': 'variable',
    'conts': 'const', 'cosnt': 'const', 'cnost': 'const', 'cnst': 'const',
    'consat': 'const', 'ocnst': 'const',
    'asnyc': 'async', 'aysnc': 'async', 'asynch': 'async', 'asnc': 'async',
    'asyc': 'async', 'asynx': 'async', 'aysync': 'async',
    'awiat': 'await', 'awit': 'await', 'awawit': 'await', 'awat': 'await',
    'improt': 'import', 'ipmort': 'import', 'imoprt': 'import',
    'iport': 'import', 'impotr': 'import', 'imprt': 'import',
    'exprot': 'export', 'exoprt': 'export', 'expotr': 'export',
    'exprt': 'export', 'exprort': 'export', 'eport': 'export',
    'calss': 'class', 'clsas': 'class', 'clas': 'class', 'clss': 'class',
    'extneds': 'extends', 'extnds': 'extends', 'extedns': 'extends',
    'implments': 'implements', 'implemnets': 'implements',
    'interafce': 'interface', 'inteface': 'interface', 'interfce': 'interface',
    'booelan': 'boolean', 'boolan': 'boolean', 'boolaen': 'boolean', 'bolean': 'boolean',
    'strig': 'string', 'stirng': 'string', 'strign': 'string', 'strng': 'string',
    'nubmer': 'number', 'numbre': 'number', 'numbr': 'number', 'nuber': 'number',
    'arry': 'array', 'aray': 'array', 'arrya': 'array', 'aaray': 'array', 'arrey': 'array',
    'obejct': 'object', 'ojbect': 'object', 'objcet': 'object', 'obect': 'object',
    'undifined': 'undefined', 'undfined': 'undefined', 'undefineed': 'undefined',
    'breaj': 'break', 'braek': 'break', 'brek': 'break',
    'contiune': 'continue', 'contiue': 'continue', 'contineu': 'continue',
    'swtich': 'switch', 'swich': 'switch', 'swithc': 'switch',
    'defualt': 'default', 'defalt': 'default', 'deafult': 'default',
    'trhow': 'throw', 'thow': 'throw', 'thorw': 'throw',
    'catach': 'catch', 'caatch': 'catch', 'ctach': 'catch',
    'finaly': 'finally', 'finlaly': 'finally', 'fianlly': 'finally',
    'yiled': 'yield', 'yeild': 'yield', 'yeld': 'yield',
    'delet': 'delete', 'deleete': 'delete', 'deleet': 'delete',
    'instnace': 'instance', 'insatnce': 'instance', 'instace': 'instance',
    'typefo': 'typeof', 'tyepof': 'typeof', 'typof': 'typeof',
    'consoel': 'console', 'consle': 'console', 'consloe': 'console',
    'dcoument': 'document', 'documnet': 'document', 'docuemnt': 'document',
    'widnow': 'window', 'windwo': 'window', 'winodw': 'window',
    'promsie': 'promise', 'pormise': 'promise', 'promis': 'promise',
    'promies': 'promise', 'primose': 'promise',
    'callbakc': 'callback', 'callbck': 'callback', 'calback': 'callback',
    'clousre': 'closure', 'closrue': 'closure', 'closuer': 'closure',
    'prottoype': 'prototype', 'protoype': 'prototype', 'prototpye': 'prototype',
    'constuctor': 'constructor', 'costructor': 'constructor', 'constrcutor': 'constructor',
    'destrcutor': 'destructor', 'destrutor': 'destructor',
    'tmplate': 'template', 'templete': 'template', 'tempalte': 'template',
    'tempalate': 'template', 'templat': 'template',

    // ── Database & Backend Terms ──────────────────────────────
    'databse': 'database', 'datbase': 'database', 'databas': 'database',
    'dataase': 'database', 'databsae': 'database', 'dtabase': 'database',
    'qurey': 'query', 'qeury': 'query', 'qury': 'query', 'queyr': 'query',
    'schma': 'schema', 'shcema': 'schema', 'scehma': 'schema', 'scheam': 'schema',
    'tabl': 'table', 'tabel': 'table', 'talbe': 'table',
    'colum': 'column', 'coulmn': 'column', 'columm': 'column', 'colmn': 'column',
    'indx': 'index', 'idnex': 'index', 'inedx': 'index',
    'primay': 'primary', 'primar': 'primary', 'primray': 'primary',
    'foriegn': 'foreign', 'foreing': 'foreign', 'foregin': 'foreign',
    'migraton': 'migration', 'migartion': 'migration', 'mirgation': 'migration',
    'transacion': 'transaction', 'transcation': 'transaction', 'transacton': 'transaction',
    'postgre': 'postgres', 'postgress': 'postgres', 'postgrres': 'postgres',
    'mongdb': 'mongodb', 'mongoDB': 'mongodb', 'monogdb': 'mongodb',
    'selct': 'select', 'selecct': 'select', 'slect': 'select',
    'insret': 'insert', 'insetr': 'insert', 'inert': 'insert',
    'delte': 'delete', 'dleete': 'delete',
    'udpate': 'update', 'upadte': 'update', 'updae': 'update',
    'wher': 'where', 'whre': 'where', 'wehre': 'where',
    'joiin': 'join', 'jion': 'join', 'jon': 'join',
    'gruop': 'group', 'grouop': 'group', 'gropu': 'group',
    'ordr': 'order', 'oerdr': 'order', 'ordeer': 'order',
    'limt': 'limit', 'liimt': 'limit', 'limti': 'limit',
    'ofset': 'offset', 'offest': 'offset', 'offste': 'offset',
    'coutn': 'count', 'cont': 'count', 'conunt': 'count',
    'aggragate': 'aggregate', 'aggreate': 'aggregate', 'aggreegate': 'aggregate',
    'endpont': 'endpoint', 'endpiont': 'endpoint', 'ednpoint': 'endpoint',
    'middelware': 'middleware', 'middlewre': 'middleware', 'middlware': 'middleware',
    'controllr': 'controller', 'controler': 'controller', 'contoller': 'controller',
    'repostiory': 'repository', 'repositry': 'repository', 'repsoitory': 'repository',
    'serivce': 'service', 'servce': 'service', 'srvice': 'service',
    'serializaton': 'serialization', 'serilization': 'serialization',
    'deserializaton': 'deserialization', 'deserilization': 'deserialization',

    // ── Web/Frontend Terms ────────────────────────────────────
    'elment': 'element', 'elemnt': 'element', 'elemet': 'element', 'elemenet': 'element',
    'compoent': 'component', 'componet': 'component', 'compnent': 'component',
    'componenet': 'component', 'compoenent': 'component', 'compoenet': 'component',
    'rendrer': 'renderer', 'renerer': 'renderer', 'rednerer': 'renderer',
    'layuot': 'layout', 'laytou': 'layout', 'laout': 'layout',
    'naviagtion': 'navigation', 'navigaton': 'navigation', 'naviagation': 'navigation',
    'routr': 'router', 'ruoter': 'router', 'rotuer': 'router',
    'heaer': 'header', 'headr': 'header', 'heder': 'header',
    'footr': 'footer', 'fooer': 'footer', 'fooetr': 'footer',
    'sidbar': 'sidebar', 'sdiebar': 'sidebar', 'sideabr': 'sidebar',
    'modla': 'modal', 'moddal': 'modal', 'mdoal': 'modal',
    'tooptip': 'tooltip', 'tooltop': 'tooltip', 'tooltpi': 'tooltip',
    'dropwdon': 'dropdown', 'drodown': 'dropdown', 'drpdown': 'dropdown',
    'carousl': 'carousel', 'carouesl': 'carousel', 'carosel': 'carousel',
    'animaton': 'animation', 'animaion': 'animation', 'aniamtion': 'animation',
    'transiton': 'transition', 'transtion': 'transition', 'tranistion': 'transition',
    'responsve': 'responsive', 'repsonsive': 'responsive', 'resonsive': 'responsive',
    'accesibility': 'accessibility', 'accessiblity': 'accessibility',
    'stlyesheet': 'stylesheet', 'styleshet': 'stylesheet', 'stlesheet': 'stylesheet',
    'viewprot': 'viewport', 'vieport': 'viewport', 'viewprt': 'viewport',
    'bakcground': 'background', 'backgrund': 'background', 'backgroud': 'background',
    'foregroud': 'foreground', 'foregorund': 'foreground',
    'positon': 'position', 'postion': 'position', 'posiiton': 'position',
    'diplay': 'display', 'dsiplay': 'display', 'dispaly': 'display',
    'visiblity': 'visibility', 'visibilty': 'visibility',
    'opactiy': 'opacity', 'opcaity': 'opacity', 'opaicty': 'opacity',
    'overlfow': 'overflow', 'overflwo': 'overflow', 'overfow': 'overflow',
    'maring': 'margin', 'margn': 'margin', 'marign': 'margin',
    'paddng': 'padding', 'padidng': 'padding', 'paddig': 'padding',
    'bordr': 'border', 'boder': 'border', 'boerdr': 'border',
    'fontsize': 'font-size', 'fontisze': 'font-size',
    'fontwieght': 'font-weight', 'fontweigth': 'font-weight',
    'textalgin': 'text-align', 'textaling': 'text-align',
    'clor': 'color', 'colro': 'color', 'coolor': 'color',
    'wdith': 'width', 'widht': 'width', 'witdh': 'width',
    'heigth': 'height', 'hieght': 'height', 'heihgt': 'height', 'hight': 'height',

    // ── API & Networking Terms ────────────────────────────────
    'reqeust': 'request', 'requets': 'request', 'reuqest': 'request',
    'requst': 'request', 'reequst': 'request', 'rquest': 'request',
    'repsonse': 'response', 'resonse': 'response', 'respone': 'response',
    'reponse': 'response', 'repsone': 'response', 'resposne': 'response',
    'autheticate': 'authenticate', 'athenticate': 'authenticate',
    'authentiacte': 'authenticate', 'authenitcate': 'authenticate',
    'authroize': 'authorize', 'authoirze': 'authorize',
    'authorzie': 'authorize', 'authrize': 'authorize',
    'authetication': 'authentication', 'athentication': 'authentication',
    'authorizaton': 'authorization', 'authroization': 'authorization',
    'sesion': 'session', 'sesssion': 'session', 'sesson': 'session',
    'tokn': 'token', 'toekn': 'token', 'toen': 'token',
    'encrpyt': 'encrypt', 'encyrpt': 'encrypt', 'encryt': 'encrypt',
    'decrpyt': 'decrypt', 'decyrpt': 'decrypt', 'decryt': 'decrypt',
    'hashign': 'hashing', 'hasihng': 'hashing',
    'certifcate': 'certificate', 'certficate': 'certificate', 'certiifcate': 'certificate',
    'webhok': 'webhook', 'webhoook': 'webhook', 'weebhook': 'webhook',
    'webscoket': 'websocket', 'websokect': 'websocket', 'websockt': 'websocket',
    'headrs': 'headers', 'hedaers': 'headers', 'haders': 'headers',
    'paylaod': 'payload', 'paylod': 'payload', 'paylaoad': 'payload',
    'fetcg': 'fetch', 'fecth': 'fetch', 'ftch': 'fetch',
    'dowload': 'download', 'donwload': 'download', 'downlaod': 'download',
    'uplaod': 'upload', 'uplod': 'upload', 'upolad': 'upload',
    'chace': 'cache', 'cahce': 'cache', 'cach': 'cache',
    'proxxy': 'proxy', 'prxoy': 'proxy', 'proy': 'proxy',
    'fierwll': 'firewall', 'firwall': 'firewall', 'firewal': 'firewall',
    'timout': 'timeout', 'tmeout': 'timeout', 'tiemout': 'timeout',
    'retrty': 'retry', 'retyr': 'retry', 'rtry': 'retry',
    'trottlhe': 'throttle', 'throtlte': 'throttle', 'trottle': 'throttle',
    'ratelimit': 'rate-limit', 'ratlimit': 'rate-limit',

    // ── Security Terms ───────────────────────────────────────
    'pasword': 'password', 'passowrd': 'password', 'passwrod': 'password',
    'passwrd': 'password', 'pssword': 'password', 'passwor': 'password',
    'vulerability': 'vulnerability', 'vulnerablity': 'vulnerability',
    'vulernability': 'vulnerability', 'vulnerabilty': 'vulnerability',
    'injecttion': 'injection', 'injeciton': 'injection', 'injecton': 'injection',
    'scrpiting': 'scripting', 'scritping': 'scripting',
    'sanitze': 'sanitize', 'sanatize': 'sanitize', 'sanitzie': 'sanitize',
    'validaton': 'validation', 'valiation': 'validation', 'validaiton': 'validation',
    'permisison': 'permission', 'permsision': 'permission', 'permision': 'permission',
    'priviledge': 'privilege', 'privelege': 'privilege', 'privlege': 'privilege',
    'escaltaion': 'escalation', 'escalaiton': 'escalation',
    'encrpytion': 'encryption', 'encrytpion': 'encryption',
    'crytpography': 'cryptography', 'cryptgraphy': 'cryptography',
    'authenication': 'authentication',
    'credentails': 'credentials', 'credntials': 'credentials',
    'secert': 'secret', 'scret': 'secret', 'secrt': 'secret',

    // ── DevOps & Infrastructure ──────────────────────────────
    'containr': 'container', 'contaner': 'container', 'contaienr': 'container',
    'kubernets': 'kubernetes', 'kuberentes': 'kubernetes', 'kubenetes': 'kubernetes',
    'kuberntes': 'kubernetes', 'kuberneets': 'kubernetes',
    'deplyment': 'deployment', 'deploymnet': 'deployment', 'deloyment': 'deployment',
    'infrastrucutre': 'infrastructure', 'infrastucture': 'infrastructure',
    'infrastrcuture': 'infrastructure',
    'orchetration': 'orchestration', 'orchestartion': 'orchestration',
    'environemnt': 'environment', 'enviroment': 'environment',
    'envrionment': 'environment', 'environmet': 'environment',
    'enivornment': 'environment', 'enviornment': 'environment',
    'configration': 'configuration', 'configuraion': 'configuration',
    'configration': 'configuration', 'configuraton': 'configuration',
    'confguration': 'configuration',
    'depedency': 'dependency', 'depenency': 'dependency', 'dependancy': 'dependency',
    'dependecy': 'dependency', 'depndency': 'dependency',
    'registyr': 'registry', 'regsitry': 'registry', 'registy': 'registry',
    'repositroy': 'repository', 'repostory': 'repository', 'repositry': 'repository',
    'monitring': 'monitoring', 'monitoing': 'monitoring', 'monioring': 'monitoring',
    'loggin': 'logging', 'loging': 'logging', 'loggign': 'logging',
    'debuggng': 'debugging', 'deubgging': 'debugging', 'debuging': 'debugging',
    'proifling': 'profiling', 'profliling': 'profiling',
    'pipline': 'pipeline', 'pipelien': 'pipeline', 'piepline': 'pipeline',
    'artifcat': 'artifact', 'artfiact': 'artifact', 'aritfact': 'artifact',

    // ── Common Action Verbs ──────────────────────────────────
    'craete': 'create', 'cretae': 'create', 'creat': 'create',
    'crate': 'create', 'ceate': 'create', 'creatae': 'create',
    'shwo': 'show', 'hsow': 'show', 'sohw': 'show', 'hswo': 'show',
    'svae': 'save', 'saev': 'save', 'sav': 'save',
    'sned': 'send', 'sedn': 'send', 'snd': 'send',
    'conect': 'connect', 'connetc': 'connect', 'conncet': 'connect',
    'concet': 'connect', 'connet': 'connect',
    'recieve': 'receive', 'recive': 'receive', 'receieve': 'receive',
    'retreive': 'retrieve', 'retreve': 'retrieve', 'retireve': 'retrieve',
    'displya': 'display', 'dispay': 'display', 'dosplay': 'display',
    'genrate': 'generate', 'genarate': 'generate', 'genereate': 'generate',
    'calcualte': 'calculate', 'caluclate': 'calculate', 'claculate': 'calculate',
    'maintan': 'maintain', 'mantain': 'maintain', 'maintian': 'maintain',
    'initailize': 'initialize', 'initalize': 'initialize', 'initalise': 'initialize',
    'initilize': 'initialize', 'intialize': 'initialize',
    'implment': 'implement', 'implmenet': 'implement', 'impelment': 'implement',
    'impliment': 'implement',
    'spceify': 'specify', 'specfiy': 'specify', 'sepcify': 'specify',
    'determin': 'determine', 'determin': 'determine', 'detremine': 'determine',
    'proccess': 'process', 'procces': 'process', 'proess': 'process',
    'complie': 'compile', 'comiple': 'compile', 'complei': 'compile',
    'exectue': 'execute', 'execut': 'execute', 'exeucte': 'execute',
    'modfiy': 'modify', 'modifiy': 'modify', 'modfy': 'modify',
    'convret': 'convert', 'convet': 'convert', 'covert': 'convert',
    'transfrom': 'transform', 'trasnform': 'transform', 'transfrm': 'transform',
    'refatcor': 'refactor', 'refactr': 'refactor', 'refacor': 'refactor',
    'optmize': 'optimize', 'optimze': 'optimize', 'opitmize': 'optimize',
    'validte': 'validate', 'valiate': 'validate', 'vlaidate': 'validate',
    'verifiy': 'verify', 'verfiy': 'verify', 'verfy': 'verify',
    'deploiy': 'deploy', 'deplyo': 'deploy', 'deploi': 'deploy',
    'confgure': 'configure', 'configre': 'configure', 'conifgure': 'configure',
    'registr': 'register', 'regsiter': 'register', 'regiser': 'register',
    'subscibe': 'subscribe', 'subscrbie': 'subscribe', 'subscrbe': 'subscribe',
    'publsih': 'publish', 'pubilsh': 'publish', 'publsh': 'publish',
    'downlod': 'download', 'donwlad': 'download',
    'navigat': 'navigate', 'naviage': 'navigate', 'naviagte': 'navigate',
    'rediect': 'redirect', 'redrect': 'redirect', 'rerdirect': 'redirect',
    'interate': 'iterate', 'iteraet': 'iterate', 'iterat': 'iterate',
    'ennumerate': 'enumerate', 'enmuerate': 'enumerate',
    'manipuate': 'manipulate', 'maniplulate': 'manipulate',
    'concatinate': 'concatenate', 'concatnate': 'concatenate',
    'interpolte': 'interpolate', 'interploate': 'interpolate',
    'duplciate': 'duplicate', 'duplicat': 'duplicate',
    'allocte': 'allocate', 'alloacte': 'allocate',
    'instanitate': 'instantiate', 'instantate': 'instantiate',
    'depricate': 'deprecate', 'depracate': 'deprecate',
    'overide': 'override', 'overrid': 'override', 'overrdie': 'override',
    'inheret': 'inherit', 'inhert': 'inherit', 'inheirt': 'inherit',
    'abstarct': 'abstract', 'abstact': 'abstract', 'absract': 'abstract',
    'syncronize': 'synchronize', 'synchronzie': 'synchronize',
    'paralell': 'parallel', 'parralel': 'parallel', 'paralel': 'parallel',

    // ── Common Nouns & Terms ─────────────────────────────────
    'usr': 'user', 'uer': 'user', 'suer': 'user',
    'buttn': 'button', 'buton': 'button', 'butoon': 'button',
    'scren': 'screen', 'screne': 'screen', 'scree': 'screen',
    'serach': 'search', 'saerch': 'search', 'seacrh': 'search',
    'reslut': 'result', 'resutl': 'result', 'rsult': 'result',
    'erorr': 'error', 'eror': 'error', 'errro': 'error', 'erro': 'error',
    'emial': 'email', 'emal': 'email', 'emali': 'email', 'eamil': 'email',
    'floder': 'folder', 'fodler': 'folder', 'flodr': 'folder',
    'flie': 'file', 'fiel': 'file', 'fle': 'file',
    'direcotry': 'directory', 'directroy': 'directory', 'drectory': 'directory',
    'pahth': 'path', 'phat': 'path', 'paht': 'path',
    'mesage': 'message', 'messgae': 'message', 'messag': 'message',
    'messge': 'message', 'meassage': 'message',
    'adress': 'address', 'adres': 'address', 'addres': 'address', 'addrss': 'address',
    'lenght': 'length', 'leght': 'length', 'lengh': 'length', 'lenth': 'length',
    'wieght': 'weight', 'weigth': 'weight', 'wieht': 'weight',
    'heght': 'height', 'hieght': 'height',
    'widht': 'width', 'wdith': 'width', 'witdh': 'width',
    'pxiel': 'pixel', 'pixle': 'pixel', 'pxel': 'pixel',
    'priavte': 'private', 'prviate': 'private', 'pirvate': 'private',
    'pulbic': 'public', 'pubilc': 'public', 'publci': 'public',
    'protetced': 'protected', 'protecetd': 'protected',
    'statc': 'static', 'staitc': 'static', 'statiic': 'static',
    'abstratc': 'abstract',
    'intger': 'integer', 'integr': 'integer', 'intgeer': 'integer',
    'charactrer': 'character', 'charcter': 'character', 'charatcer': 'character',
    'strucutre': 'structure', 'structre': 'structure', 'strcuture': 'structure',
    'algoritm': 'algorithm', 'algorythm': 'algorithm', 'algortihm': 'algorithm',
    'algorihm': 'algorithm', 'alogrithm': 'algorithm',
    'recursoin': 'recursion', 'recusrion': 'recursion', 'recurson': 'recursion',
    'expetion': 'exception', 'excpetion': 'exception', 'excepiton': 'exception',
    'iteraor': 'iterator', 'itreator': 'iterator', 'iteraotr': 'iterator',
    'genertor': 'generator', 'geneartor': 'generator', 'geneator': 'generator',
    'decortor': 'decorator', 'decoartor': 'decorator', 'decoarater': 'decorator',
    'framwork': 'framework', 'framewrok': 'framework', 'frmaework': 'framework',
    'libaray': 'library', 'libray': 'library', 'libary': 'library', 'librray': 'library',
    'pacakge': 'package', 'packge': 'package', 'pakcage': 'package',
    'moduel': 'module', 'modle': 'module', 'mdoule': 'module',
    'plugn': 'plugin', 'plguin': 'plugin', 'pugin': 'plugin',
    'browsre': 'browser', 'brower': 'browser', 'broswer': 'browser',
    'servre': 'server', 'sever': 'server', 'servr': 'server',
    'clinet': 'client', 'cleint': 'client', 'clent': 'client',
    'proejct': 'project', 'projcet': 'project', 'pproject': 'project',
    'apliaction': 'application', 'applicaton': 'application', 'applicaion': 'application',
    'interace': 'interface',
    'secton': 'section', 'scetion': 'section', 'seciton': 'section',
    'contnet': 'content', 'conent': 'content', 'contnet': 'content',
    'versoin': 'version', 'vresion': 'version', 'verion': 'version',
    'relase': 'release', 'relaese': 'release', 'releas': 'release',
    'licesne': 'license', 'licnese': 'license', 'lisence': 'license',
    'tutoral': 'tutorial', 'tutoiral': 'tutorial', 'tuotrial': 'tutorial',
    'exmaple': 'example', 'examlpe': 'example', 'exapmle': 'example',
    'sampel': 'sample', 'sampl': 'sample', 'sapmle': 'sample',
    'documnet': 'document', 'docuemnt': 'document',
    'documnetation': 'documentation', 'documenation': 'documentation',
    'notifcation': 'notification', 'notificaiton': 'notification',
    'permisson': 'permission',
    'operaton': 'operation', 'operaiton': 'operation', 'opreation': 'operation',
    'defintion': 'definition', 'definiion': 'definition', 'defition': 'definition',
    'declaraton': 'declaration', 'declaraion': 'declaration',
    'expresion': 'expression', 'expresssion': 'expression',
    'assignemnt': 'assignment', 'assigment': 'assignment', 'assignmet': 'assignment',

    // ── General English (high-frequency misspellings) ─────────
    'occured': 'occurred', 'ocurred': 'occurred', 'occured': 'occurred',
    'occurance': 'occurrence', 'occurence': 'occurrence',
    'seperate': 'separate', 'seprate': 'separate', 'separete': 'separate',
    'neccessary': 'necessary', 'necesary': 'necessary', 'neccesary': 'necessary',
    'necessery': 'necessary', 'neccessery': 'necessary',
    'definately': 'definitely', 'definatly': 'definitely', 'definetly': 'definitely',
    'definitly': 'definitely', 'definately': 'definitely',
    'apparantly': 'apparently', 'apparentely': 'apparently',
    'basicly': 'basically', 'basicaly': 'basically',
    'begining': 'beginning', 'begginning': 'beginning', 'beggining': 'beginning',
    'beleive': 'believe', 'belive': 'believe', 'beleave': 'believe',
    'buisness': 'business', 'busines': 'business', 'bussiness': 'business',
    'calender': 'calendar', 'calandar': 'calendar', 'calander': 'calendar',
    'catagory': 'category', 'categroy': 'category', 'categoyr': 'category',
    'changable': 'changeable', 'changable': 'changeable',
    'comittee': 'committee', 'commitee': 'committee', 'committe': 'committee',
    'comparision': 'comparison', 'comparsion': 'comparison',
    'completly': 'completely', 'completley': 'completely',
    'concious': 'conscious', 'consious': 'conscious',
    'consistant': 'consistent', 'consistnet': 'consistent',
    'continous': 'continuous', 'continus': 'continuous',
    'convienent': 'convenient', 'convienient': 'convenient', 'conveniant': 'convenient',
    'correspondance': 'correspondence', 'corespondence': 'correspondence',
    'decison': 'decision', 'desicion': 'decision',
    'develope': 'develop', 'devlop': 'develop', 'devleop': 'develop',
    'developement': 'development', 'develpment': 'development', 'developemnt': 'development',
    'difrrent': 'different', 'diffrent': 'different', 'diffeent': 'different',
    'disapear': 'disappear', 'dissapear': 'disappear', 'dissappear': 'disappear',
    'embarras': 'embarrass', 'embarass': 'embarrass', 'embaress': 'embarrass',
    'exagerate': 'exaggerate', 'exagerrate': 'exaggerate',
    'excercise': 'exercise', 'exersize': 'exercise',
    'existance': 'existence', 'existnce': 'existence',
    'experiance': 'experience', 'exprience': 'experience', 'experiece': 'experience',
    'explaination': 'explanation', 'explaantion': 'explanation',
    'familer': 'familiar', 'famialr': 'familiar',
    'finaly': 'finally', 'fianlly': 'finally', 'finlly': 'finally',
    'foriegn': 'foreign', 'forein': 'foreign',
    'freind': 'friend', 'frend': 'friend',
    'goverment': 'government', 'goverrnment': 'government', 'govenrment': 'government',
    'grammer': 'grammar', 'gramer': 'grammar',
    'guage': 'gauge', 'gage': 'gauge',
    'gaurd': 'guard', 'gard': 'guard',
    'happend': 'happened', 'happned': 'happened',
    'harrass': 'harass', 'harras': 'harass',
    'immediatly': 'immediately', 'imediately': 'immediately', 'immedietly': 'immediately',
    'independant': 'independent', 'indpendent': 'independent',
    'intelligance': 'intelligence', 'inteligence': 'intelligence',
    'knowlege': 'knowledge', 'knowlede': 'knowledge', 'knoweldge': 'knowledge',
    'langauge': 'language', 'languge': 'language', 'lanaguage': 'language',
    'languaeg': 'language', 'lanugage': 'language',
    'maintanance': 'maintenance', 'maintenence': 'maintenance', 'maintainence': 'maintenance',
    'millenium': 'millennium', 'milennium': 'millennium',
    'mispell': 'misspell', 'mispel': 'misspell',
    'noticable': 'noticeable', 'noticible': 'noticeable',
    'occassion': 'occasion', 'ocasion': 'occasion',
    'orignal': 'original', 'orginal': 'original', 'orignial': 'original',
    'parliment': 'parliament',
    'particlar': 'particular', 'particullar': 'particular',
    'peice': 'piece', 'peice': 'piece',
    'posession': 'possession', 'possesion': 'possession',
    'potentailly': 'potentially', 'potentialy': 'potentially',
    'prefered': 'preferred', 'preffered': 'preferred',
    'predjudice': 'prejudice', 'prejudise': 'prejudice',
    'privelege': 'privilege', 'privlege': 'privilege',
    'probaly': 'probably', 'proabably': 'probably', 'probabaly': 'probably',
    'profesional': 'professional', 'proffesional': 'professional', 'proffessional': 'professional',
    'programing': 'programming', 'programmin': 'programming', 'porgramming': 'programming',
    'pronunciaton': 'pronunciation',
    'questionaire': 'questionnaire', 'questionnare': 'questionnaire',
    'realy': 'really', 'relly': 'really', 'reallly': 'really',
    'reccomend': 'recommend', 'recomend': 'recommend', 'recommed': 'recommend',
    'refrence': 'reference', 'referece': 'reference', 'refernce': 'reference',
    'relevent': 'relevant', 'releveant': 'relevant', 'releant': 'relevant',
    'religous': 'religious', 'religius': 'religious',
    'remeber': 'remember', 'rember': 'remember', 'remmeber': 'remember',
    'repitition': 'repetition', 'repetetion': 'repetition',
    'rythm': 'rhythm', 'rythym': 'rhythm', 'rhythem': 'rhythm',
    'scedule': 'schedule', 'schedul': 'schedule', 'shedule': 'schedule',
    'sentance': 'sentence', 'sentense': 'sentence',
    'similer': 'similar', 'simliar': 'similar', 'similiar': 'similar',
    'sincerly': 'sincerely', 'sinceerly': 'sincerely',
    'speach': 'speech', 'speach': 'speech',
    'strengh': 'strength', 'strenght': 'strength', 'stength': 'strength',
    'succcess': 'success', 'sucess': 'success', 'succes': 'success',
    'successfull': 'successful', 'succesful': 'successful', 'sucessful': 'successful',
    'suprize': 'surprise', 'suprise': 'surprise', 'surprize': 'surprise',
    'temperture': 'temperature', 'tempreture': 'temperature',
    'teh': 'the', 'hte': 'the', 'thn': 'then', 'thne': 'then', 'taht': 'that',
    'thier': 'their', 'thrie': 'their', 'htere': 'there',
    'throught': 'through', 'trhough': 'through', 'thruogh': 'through',
    'togather': 'together', 'togehter': 'together', 'togethr': 'together',
    'tommorow': 'tomorrow', 'tommorrow': 'tomorrow', 'tomorow': 'tomorrow',
    'truley': 'truly', 'truely': 'truly',
    'untill': 'until', 'untl': 'until', 'untiil': 'until',
    'usally': 'usually', 'ussually': 'usually', 'usualyl': 'usually',
    'vaccum': 'vacuum', 'vaccuum': 'vacuum',
    'wich': 'which', 'whch': 'which', 'wich': 'which',
    'whith': 'with', 'wiht': 'with', 'wth': 'with',
    'withotu': 'without', 'wihtout': 'without', 'withouot': 'without',
    'writting': 'writing', 'wrting': 'writing', 'writng': 'writing',

    // ── Lume-specific terms ──────────────────────────────────
    'toleranc': 'tolerance', 'tolerence': 'tolerance', 'tolernace': 'tolerance',
    'compielr': 'compiler', 'complier': 'compiler', 'comipiler': 'compiler',
    'tranpiler': 'transpiler', 'transpilr': 'transpiler',
    'cognitve': 'cognitive', 'cogntive': 'cognitive', 'cogntiive': 'cognitive',
    'dissonace': 'dissonance', 'dissonence': 'dissonance', 'disonnance': 'dissonance',
    'distanc': 'distance', 'disstance': 'distance',
    'guardan': 'guardian', 'gaurdian': 'guardian', 'gardian': 'guardian',
    'scannr': 'scanner', 'scanenr': 'scanner',
    'certifeid': 'certified', 'certfied': 'certified', 'cerfitied': 'certified',
    'sandox': 'sandbox', 'sandbx': 'sandbox',
    'plagroound': 'playground', 'playgrund': 'playground',
    'transcritpion': 'transcription', 'transcripton': 'transcription',
    'homoohone': 'homophone', 'homopohne': 'homophone',
    'semantci': 'semantic', 'semnatic': 'semantic', 'semanic': 'semantic',
    'anaysis': 'analysis', 'anaylsis': 'analysis', 'analyiss': 'analysis',
    'parsre': 'parser', 'parsr': 'parser', 'praser': 'parser',
    'lexre': 'lexer', 'lexr': 'lexer',
    'tokenizr': 'tokenizer', 'tokenzier': 'tokenizer',
    'synax': 'syntax', 'synthax': 'syntax', 'syntx': 'syntax',

    // ── Testing & QA Terms ──────────────────────────────────
    'asssertion': 'assertion', 'asserrtion': 'assertion', 'asserion': 'assertion',
    'assertoin': 'assertion', 'asserton': 'assertion',
    'expec': 'expect', 'expcet': 'expect', 'expext': 'expect',
    'descrbe': 'describe', 'desribe': 'describe', 'descirbe': 'describe',
    'desrcibe': 'describe',
    'covrage': 'coverage', 'coverge': 'coverage', 'coverag': 'coverage',
    'coveraeg': 'coverage',
    'moch': 'mock', 'mokc': 'mock', 'mok': 'mock',
    'stbu': 'stub', 'stubb': 'stub', 'sutb': 'stub',
    'sput': 'spy', 'spye': 'spy',
    'fixtrue': 'fixture', 'fixutre': 'fixture', 'fixtre': 'fixture',
    'befor': 'before', 'befroe': 'before', 'bfore': 'before',
    'aftre': 'after', 'afetr': 'after', 'aftr': 'after',
    'integretion': 'integration', 'intergation': 'integration',
    'integartion': 'integration', 'intergration': 'integration',
    'regrssion': 'regression', 'regressoin': 'regression', 'regresion': 'regression',
    'benchamrk': 'benchmark', 'benchmakr': 'benchmark', 'bechmark': 'benchmark',
    'snpashot': 'snapshot', 'snapshto': 'snapshot', 'snaphsot': 'snapshot',
    'scenaroi': 'scenario', 'scenerio': 'scenario', 'sceanrio': 'scenario',
    'specifcation': 'specification', 'specfication': 'specification',
    'accpetance': 'acceptance', 'acceptence': 'acceptance',
    'compatability': 'compatibility', 'compatibilty': 'compatibility',
    'performnce': 'performance', 'perfomance': 'performance', 'performace': 'performance',
    'preformance': 'performance',

    // ── Data Science & ML Terms ─────────────────────────────
    'tensr': 'tensor', 'tesnor': 'tensor', 'tnsor': 'tensor',
    'nuerla': 'neural', 'nueral': 'neural', 'nural': 'neural',
    'graident': 'gradient', 'gradiant': 'gradient', 'gradeint': 'gradient',
    'epohc': 'epoch', 'epcoh': 'epoch', 'epch': 'epoch',
    'bacth': 'batch', 'btach': 'batch', 'bathc': 'batch',
    'datset': 'dataset', 'dataseet': 'dataset', 'dataste': 'dataset',
    'traning': 'training', 'trianing': 'training', 'trainnig': 'training',
    'inferrence': 'inference', 'inferece': 'inference', 'infernce': 'inference',
    'prediciton': 'prediction', 'predicton': 'prediction', 'predction': 'prediction',
    'classificaton': 'classification', 'classfication': 'classification',
    'clustring': 'clustering', 'clsutering': 'clustering',
    'normalizaton': 'normalization', 'normlization': 'normalization',
    'embeding': 'embedding', 'embeddign': 'embedding', 'embeddig': 'embedding',
    'tokenizaton': 'tokenization', 'tokenzation': 'tokenization',
    'hyperparamter': 'hyperparameter', 'hyperparameer': 'hyperparameter',
    'overfiting': 'overfitting', 'overfitiing': 'overfitting',
    'underfiting': 'underfitting', 'underfittign': 'underfitting',
    'regularizaton': 'regularization', 'regulariztion': 'regularization',
    'convoluton': 'convolution', 'convoltuion': 'convolution',
    'segmentaton': 'segmentation', 'segmenation': 'segmentation',
    'preprocessng': 'preprocessing', 'preprocessign': 'preprocessing',
    'feaure': 'feature', 'featrue': 'feature', 'feture': 'feature',
    'lable': 'label', 'labal': 'label', 'labeel': 'label',
    'weighht': 'weight', 'wieght': 'weight',
    'biase': 'bias', 'baias': 'bias',
    'acuracy': 'accuracy', 'accuray': 'accuracy', 'accuraccy': 'accuracy',
    'precison': 'precision', 'precsion': 'precision', 'precisoin': 'precision',

    // ── Mobile & Native Terms ───────────────────────────────
    'andriod': 'android', 'andorid': 'android', 'adnroid': 'android',
    'widgt': 'widget', 'wiget': 'widget', 'widgett': 'widget',
    'gesure': 'gesture', 'gestrue': 'gesture', 'gusture': 'gesture',
    'scafflod': 'scaffold', 'sacffold': 'scaffold', 'scafffold': 'scaffold',
    'activty': 'activity', 'activiy': 'activity', 'actvity': 'activity',
    'fragmen': 'fragment', 'fragement': 'fragment', 'fragmnet': 'fragment',
    'adpater': 'adapter', 'adaptr': 'adapter', 'addapter': 'adapter',
    'recycelr': 'recycler', 'recylcer': 'recycler',
    'notifiction': 'notification', 'notifciation': 'notification',
    'permssion': 'permission',
    'emultor': 'emulator', 'emualtor': 'emulator', 'emulatr': 'emulator',
    'simultor': 'simulator', 'simualtor': 'simulator', 'simulatr': 'simulator',
    'platfrom': 'platform', 'platfomr': 'platform', 'platofrm': 'platform',
    'nativve': 'native', 'natvie': 'native', 'natie': 'native',
    'touchscren': 'touchscreen', 'toucscreen': 'touchscreen',
    'swipe': 'swipe', 'swiep': 'swipe',
    'keyborad': 'keyboard', 'keybord': 'keyboard', 'keybard': 'keyboard',
    'orienation': 'orientation', 'orientaton': 'orientation', 'orintation': 'orientation',
    'tabelt': 'tablet', 'tabet': 'tablet', 'tablt': 'tablet',
    'portait': 'portrait', 'portriat': 'portrait', 'portrat': 'portrait',
    'landsacpe': 'landscape', 'landscpe': 'landscape', 'landscap': 'landscape',

    // ── Architecture Patterns ───────────────────────────────
    'microservce': 'microservice', 'microsrvice': 'microservice',
    'microsevice': 'microservice', 'microserivce': 'microservice',
    'singlton': 'singleton', 'singelton': 'singleton', 'singlteon': 'singleton',
    'observr': 'observer', 'obsrever': 'observer', 'obserevr': 'observer',
    'facotry': 'factory', 'fatory': 'factory', 'factroy': 'factory',
    'stratgy': 'strategy', 'stragety': 'strategy', 'startegy': 'strategy',
    'mediator': 'mediator', 'meditaor': 'mediator',
    'adaptor': 'adapter', 'adatper': 'adapter',
    'proxie': 'proxy', 'proxi': 'proxy',
    'fascade': 'facade', 'fecade': 'facade', 'facad': 'facade',
    'itertor': 'iterator',
    'composte': 'composite', 'compsite': 'composite', 'composit': 'composite',
    'decortaor': 'decorator',
    'repositori': 'repository',
    'middlewear': 'middleware', 'midleware': 'middleware',
    'gatway': 'gateway', 'gatewy': 'gateway', 'gatweway': 'gateway',
    'monoltih': 'monolith', 'monlith': 'monolith', 'monoilth': 'monolith',
    'scaleable': 'scalable', 'scalible': 'scalable', 'scallable': 'scalable',
    'idemptotent': 'idempotent', 'idempotnet': 'idempotent',
    'aynchronous': 'asynchronous', 'asynchrnous': 'asynchronous',
    'synchrnous': 'synchronous', 'synchrounous': 'synchronous',
    'concurreny': 'concurrency', 'concurency': 'concurrency', 'concurrancy': 'concurrency',
    'loadbalancer': 'load-balancer', 'loadbalncer': 'load-balancer',
    'abstaction': 'abstraction', 'abstrcation': 'abstraction',
    'encapsulaton': 'encapsulation', 'encapsualtion': 'encapsulation',
    'polymorphsim': 'polymorphism', 'polymorphim': 'polymorphism',
    'inheritence': 'inheritance', 'inheritnce': 'inheritance', 'inhertiance': 'inheritance',

    // ── Git & Version Control ───────────────────────────────
    'comit': 'commit', 'commti': 'commit', 'comitt': 'commit', 'committ': 'commit',
    'brnahc': 'branch', 'brnach': 'branch', 'brach': 'branch', 'barnch': 'branch',
    'merg': 'merge', 'megre': 'merge', 'mereg': 'merge',
    'rebse': 'rebase', 'rebsae': 'rebase', 'rabase': 'rebase',
    'chekout': 'checkout', 'checkot': 'checkout', 'chekcout': 'checkout',
    'stahs': 'stash', 'stahsh': 'stash', 'satsh': 'stash',
    'cherypick': 'cherry-pick', 'cherrypik': 'cherry-pick',
    'conflcit': 'conflict', 'conflit': 'conflict', 'confilct': 'conflict',
    'difff': 'diff', 'dif': 'diff',
    'reposiotry': 'repository', 'repsitory': 'repository',
    'upstrem': 'upstream', 'upstraem': 'upstream', 'upsream': 'upstream',
    'dowstream': 'downstream', 'downstrem': 'downstream',
    'featch': 'fetch', 'fetcch': 'fetch',
    'cloen': 'clone', 'colne': 'clone', 'clon': 'clone',
    'forck': 'fork', 'frok': 'fork',
    'taging': 'tagging', 'taggin': 'tagging',
    'releasee': 'release',
    'changlog': 'changelog', 'changelgo': 'changelog',
    'gitignroe': 'gitignore', 'gitigonre': 'gitignore',
    'submodle': 'submodule', 'submodlue': 'submodule',

    // ── Math & Logic Terms ──────────────────────────────────
    'boolen': 'boolean',
    'intergal': 'integral', 'integeral': 'integral',
    'derivtive': 'derivative', 'derivaive': 'derivative',
    'matirx': 'matrix', 'matrxi': 'matrix', 'matix': 'matrix',
    'vetcor': 'vector', 'vecor': 'vector', 'vcetor': 'vector',
    'scaler': 'scalar', 'scalr': 'scalar',
    'coefficent': 'coefficient', 'coefficeint': 'coefficient',
    'equaton': 'equation', 'equaiton': 'equation',
    'forumla': 'formula', 'formual': 'formula', 'fromula': 'formula',
    'exponentail': 'exponential', 'exponetial': 'exponential',
    'logarithim': 'logarithm', 'logarthim': 'logarithm',
    'trigonmetry': 'trigonometry', 'trigonomtery': 'trigonometry',
    'probabiliy': 'probability', 'probabilty': 'probability',
    'permutaion': 'permutation', 'permutaton': 'permutation',
    'combinaton': 'combination', 'combinaiton': 'combination',
    'determiant': 'determinant', 'determinat': 'determinant',
    'eigenvlaue': 'eigenvalue', 'eigenvale': 'eigenvalue',
    'interpolaton': 'interpolation', 'interploation': 'interpolation',
    'iteraton': 'iteration', 'iteraiton': 'iteration',
    'convergnce': 'convergence', 'convergece': 'convergence',
    'divergnce': 'divergence', 'divergece': 'divergence',
    'infintiy': 'infinity', 'infintiy': 'infinity', 'infinty': 'infinity',
    'randomm': 'random', 'randmo': 'random', 'rndom': 'random',

    // ── Networking Deep ─────────────────────────────────────
    'bandwith': 'bandwidth', 'bandwidht': 'bandwidth', 'bandwitdh': 'bandwidth',
    'latecny': 'latency', 'latecy': 'latency', 'lateny': 'latency',
    'througput': 'throughput', 'throughupt': 'throughput', 'thruoghput': 'throughput',
    'protocl': 'protocol', 'portocol': 'protocol', 'protocal': 'protocol',
    'subent': 'subnet', 'subnett': 'subnet',
    'gatewya': 'gateway',
    'boadcast': 'broadcast', 'bradcast': 'broadcast', 'boradcast': 'broadcast',
    'multicast': 'multicast', 'mulitcast': 'multicast',
    'unicast': 'unicast', 'uincast': 'unicast',
    'handshke': 'handshake', 'handsahke': 'handshake',
    'certifiate': 'certificate',
    'loadbalance': 'load-balance',
    'distrubuted': 'distributed', 'distribued': 'distributed', 'distrbiuted': 'distributed',
    'replciation': 'replication', 'replicaton': 'replication',
    'partiton': 'partition', 'partiiton': 'partition', 'parttion': 'partition',
    'consesnus': 'consensus', 'consesus': 'consensus', 'consnsus': 'consensus',
    'failoevr': 'failover', 'failvoer': 'failover',
    'redudancy': 'redundancy', 'redundacy': 'redundancy', 'redundncy': 'redundancy',
    'heartbet': 'heartbeat', 'heartbat': 'heartbeat',
    'resolvre': 'resolver', 'reolver': 'resolver',
    'nameservr': 'nameserver', 'nameserve': 'nameserver',

    // ── React & Component Terms ─────────────────────────────
    'componnt': 'component', 'comopnent': 'component',
    'porps': 'props', 'prps': 'props', 'prpos': 'props',
    'satte': 'state', 'stae': 'state', 'staet': 'state',
    'efect': 'effect', 'effcet': 'effect', 'effeect': 'effect',
    'rendeer': 'render', 'rnder': 'render', 'rendr': 'render',
    'contetx': 'context', 'contxt': 'context', 'conext': 'context',
    'providr': 'provider', 'provder': 'provider', 'proivder': 'provider',
    'consmer': 'consumer', 'conusmer': 'consumer', 'consumre': 'consumer',
    'suspese': 'suspense', 'suspnse': 'suspense',
    'lazey': 'lazy', 'lzy': 'lazy',
    'fragmnet': 'fragment',
    'portaal': 'portal', 'protal': 'portal',
    'forwardref': 'forwardRef', 'forwardrf': 'forwardRef',
    'useffect': 'useEffect', 'useefect': 'useEffect',
    'usestate': 'useState', 'usesatte': 'useState',
    'usemmo': 'useMemo', 'usememo': 'useMemo',
    'usecalback': 'useCallback', 'usecallbak': 'useCallback',
    'userf': 'useRef', 'uesRef': 'useRef',
    'usecntext': 'useContext', 'usecontxt': 'useContext',
    'usereducer': 'useReducer', 'usereducr': 'useReducer',
    'hyrdate': 'hydrate', 'hydarte': 'hydrate', 'hydrat': 'hydrate',

    // ── Build & Compilation Terms ───────────────────────────
    'transplie': 'transpile', 'transpiel': 'transpile', 'trasnpile': 'transpile',
    'bundel': 'bundle', 'bnudle': 'bundle', 'bundl': 'bundle',
    'minfiy': 'minify', 'minfy': 'minify', 'minfiy': 'minify',
    'uglifiy': 'uglify', 'uglfy': 'uglify',
    'treeshake': 'tree-shake', 'tree-sahke': 'tree-shake',
    'codepslit': 'code-split', 'codeslit': 'code-split',
    'hotrelod': 'hot-reload', 'hotrealod': 'hot-reload',
    'sourcmap': 'sourcemap', 'sourcemp': 'sourcemap', 'soruceamp': 'sourcemap',
    'polyfil': 'polyfill', 'polyfll': 'polyfill', 'polyifll': 'polyfill',
    'shimm': 'shim', 'shm': 'shim',
    'lintr': 'linter', 'litner': 'linter', 'lnter': 'linter',
    'fromatter': 'formatter', 'formattre': 'formatter',
    'prittier': 'prettier', 'pretiier': 'prettier',
    'eslitn': 'eslint', 'elint': 'eslint', 'eslintt': 'eslint',
    'buidl': 'build', 'buld': 'build', 'biuld': 'build',
    'dpenedency': 'dependency',
    'devdependency': 'devDependency', 'devdependecy': 'devDependency',
    'peerdependency': 'peerDependency', 'peerdependecy': 'peerDependency',
    'lockfiel': 'lockfile', 'lockfle': 'lockfile',
    'workspce': 'workspace', 'workpsace': 'workspace', 'worksapce': 'workspace',
    'monoerpo': 'monorepo', 'monrepo': 'monorepo', 'monoerpo': 'monorepo',

    // ── Accessibility Terms ─────────────────────────────────
    'accessibiilty': 'accessibility', 'accessiblity': 'accessibility',
    'accessbility': 'accessibility', 'acessibility': 'accessibility',
    'screenreader': 'screen-reader', 'screenreadr': 'screen-reader',
    'ariaa': 'aria', 'aira': 'aria',
    'semanitc': 'semantic',
    'tabindx': 'tabindex', 'tabidnex': 'tabindex',
    'focusabel': 'focusable', 'focuable': 'focusable',
    'contrst': 'contrast', 'contarst': 'contrast', 'constrat': 'contrast',
    'alternatve': 'alternative', 'alternatie': 'alternative',
    'capion': 'caption', 'catpion': 'caption', 'captoin': 'caption',
    'transcipt': 'transcript', 'trascript': 'transcript', 'transcirpt': 'transcript',
    'subtitels': 'subtitles', 'subtiles': 'subtitles',
    'dysleia': 'dyslexia', 'dyslxeia': 'dyslexia',
    'colobrind': 'colorblind', 'colorblid': 'colorblind',
    'magnifiation': 'magnification', 'magnifcation': 'magnification',
    'localizaton': 'localization', 'localisaton': 'localization',
    'internatonalization': 'internationalization', 'i18n': 'internationalization',

    // ── Performance Terms ───────────────────────────────────
    'optimzation': 'optimization', 'optimisaton': 'optimization',
    'cahcing': 'caching', 'cachign': 'caching', 'cacihng': 'caching',
    'memorey': 'memory', 'memroy': 'memory', 'memoyr': 'memory',
    'cpuu': 'cpu', 'cpy': 'cpu',
    'theard': 'thread', 'thred': 'thread', 'thraed': 'thread',
    'processs': 'process', 'porcess': 'process',
    'contention': 'contention', 'contenion': 'contention',
    'deadlcok': 'deadlock', 'deadlok': 'deadlock', 'daedlock': 'deadlock',
    'raec': 'race', 'rcae': 'race',
    'mutx': 'mutex', 'muetx': 'mutex', 'mutxe': 'mutex',
    'semaphroe': 'semaphore', 'semaphone': 'semaphore', 'semaphor': 'semaphore',
    'garbge': 'garbage', 'garbaeg': 'garbage', 'grabage': 'garbage',
    'colection': 'collection', 'colleciton': 'collection', 'colletion': 'collection',
    'lazyload': 'lazy-load', 'lazylaod': 'lazy-load',
    'memoizaton': 'memoization', 'memoiztion': 'memoization',
    'virtualizaton': 'virtualization', 'virtualiztion': 'virtualization',
    'deboucne': 'debounce', 'debouce': 'debounce', 'debounc': 'debounce',
    'throtlle': 'throttle', 'thottle': 'throttle',
    'profiel': 'profile', 'porfile': 'profile', 'proifle': 'profile',
    'bottlenck': 'bottleneck', 'bottlneck': 'bottleneck', 'bottlenec': 'bottleneck',
    'waterfall': 'waterfall', 'waterfal': 'waterfall',

    // ── Additional Typing Patterns ──────────────────────────
    'paramter': 'parameter', 'parameer': 'parameter', 'parmaeter': 'parameter',
    'paramater': 'parameter', 'paraemter': 'parameter',
    'arguemnt': 'argument', 'arguement': 'argument', 'arugment': 'argument',
    'argumet': 'argument', 'agrument': 'argument',
    'fucntional': 'functional', 'funtional': 'functional', 'funcitonal': 'functional',
    'conditon': 'condition', 'condiiton': 'condition', 'conditoin': 'condition',
    'iterable': 'iterable', 'iterabel': 'iterable',
    'mutalbe': 'mutable', 'mutabel': 'mutable', 'mutble': 'mutable',
    'immutabel': 'immutable', 'immutalbe': 'immutable', 'immutble': 'immutable',
    'deprectaed': 'deprecated', 'depracated': 'deprecated', 'depricated': 'deprecated',
    'compatbile': 'compatible', 'compatiable': 'compatible',
    'executiion': 'execution', 'exectuion': 'execution', 'execuion': 'execution',
    'compleiton': 'completion', 'completoin': 'completion',
    'initializaton': 'initialization', 'initializtion': 'initialization',
    'authenticaton': 'authentication', 'authenticaiton': 'authentication',
    'authoriztaion': 'authorization', 'authoriztion': 'authorization',
    'implementaiton': 'implementation', 'implementaton': 'implementation',
    'communicaton': 'communication', 'communicaiton': 'communication',
    'documetnation': 'documentation', 'documentaton': 'documentation',
    'specificaton': 'specification', 'specificaiton': 'specification',
    'specificiation': 'specification',
    'configuraiton': 'configuration', 'configuartion': 'configuration',
    'synchronizaton': 'synchronization', 'synchroniztion': 'synchronization',
    'authhenticate': 'authenticate',
    'temprary': 'temporary', 'temporray': 'temporary', 'temproary': 'temporary',
    'persisent': 'persistent', 'persistant': 'persistent', 'persistnet': 'persistent',
    'volataile': 'volatile', 'volatiel': 'volatile', 'volitile': 'volatile',
    'instancee': 'instance',
    'refrrence': 'reference', 'rference': 'reference',
    'declartion': 'declaration', 'declration': 'declaration',
    'staement': 'statement', 'statemnet': 'statement', 'statment': 'statement',
    'resoluton': 'resolution', 'resoluion': 'resolution',
    'compilaton': 'compilation', 'compilaiton': 'compilation',
    'encoidng': 'encoding', 'enocding': 'encoding', 'encdoing': 'encoding',
    'decoidng': 'decoding', 'deocding': 'decoding',
    'algoritmic': 'algorithmic', 'algorithmci': 'algorithmic',
    'asynchrnously': 'asynchronously', 'asyncronously': 'asynchronously',
    'synchrounously': 'synchronously', 'syncronously': 'synchronously',
    'programatically': 'programmatically', 'programaticly': 'programmatically',
    'dynamicaly': 'dynamically', 'dynamiclly': 'dynamically',
    'staticaly': 'statically', 'staticlly': 'statically',
    'recursivley': 'recursively', 'recusrively': 'recursively',
    'iterativley': 'iteratively', 'iteratvely': 'iteratively',
    'explicilty': 'explicitly', 'explictly': 'explicitly',
    'implicilty': 'implicitly', 'implictly': 'implicitly',
    'inherentley': 'inherently', 'inherntly': 'inherently',
    'simultanously': 'simultaneously', 'simultaniously': 'simultaneously',
    'automaticlly': 'automatically', 'automaticaly': 'automatically',
    'manaully': 'manually', 'manualy': 'manually',
    'specifiically': 'specifically', 'specificaly': 'specifically',
    'signifcant': 'significant', 'signifiant': 'significant',
    'efficent': 'efficient', 'efficent': 'efficient', 'efficeint': 'efficient',
    'sufficeint': 'sufficient', 'sufficent': 'sufficient',
    'abstrat': 'abstract',
    'concrte': 'concrete', 'concret': 'concrete',
    'genric': 'generic', 'generc': 'generic', 'geneirc': 'generic',
    'specifc': 'specific', 'specfic': 'specific', 'speicfic': 'specific',
    'reusabel': 'reusable', 'reusble': 'reusable', 'reuasble': 'reusable',
    'maintainabel': 'maintainable', 'maintanable': 'maintainable',
    'readabel': 'readable', 'readble': 'readable',
    'writeabel': 'writable', 'writble': 'writable',
    'excutable': 'executable', 'exeutable': 'executable',
    'configrable': 'configurable', 'configurabel': 'configurable',
    'extendabel': 'extendable', 'extenable': 'extendable',
    'injectabel': 'injectable', 'injectble': 'injectable',
    'observabel': 'observable', 'observble': 'observable',
    'subscribabel': 'subscribable', 'subscribble': 'subscribable',
    'serializeable': 'serializable', 'serializble': 'serializable',
    'comparabel': 'comparable', 'comparble': 'comparable',
    'iterabel': 'iterable',
    'nullabel': 'nullable', 'nullble': 'nullable',
    'enumerabel': 'enumerable', 'enumerble': 'enumerable',
    'disposabel': 'disposable', 'disposble': 'disposable',
    'cancelabel': 'cancelable', 'cancelble': 'cancelable',
    'debounabel': 'debounceable',
    'scrolabel': 'scrollable', 'scrollble': 'scrollable',
    'draggabel': 'draggable', 'draggble': 'draggable',
    'resizeable': 'resizable', 'resizble': 'resizable',
    'sortabel': 'sortable', 'sortble': 'sortable',
    'filterabel': 'filterable', 'filterble': 'filterable',
    'searchabel': 'searchable', 'searchble': 'searchable',
    'editabel': 'editable', 'editble': 'editable',
    'clickabel': 'clickable', 'clickble': 'clickable',
    'accessabel': 'accessible', 'accessble': 'accessible',
    'responsabel': 'responsible', 'responsble': 'responsible',
}

/* ═══════════════════════════════════════════════════════════════
 *  CONTRACTION NORMALIZATION — 60+ patterns
 * ═══════════════════════════════════════════════════════════════ */
export const contractions = {
    // Negative contractions
    "dont": "don't", "doesnt": "doesn't", "didnt": "didn't",
    "cant": "can't", "couldnt": "couldn't", "shouldnt": "shouldn't",
    "wouldnt": "wouldn't", "wont": "won't", "isnt": "isn't",
    "arent": "aren't", "wasnt": "wasn't", "werent": "weren't",
    "hasnt": "hasn't", "havent": "haven't", "hadnt": "hadn't",
    "mustnt": "mustn't", "neednt": "needn't", "darent": "daren't",
    "mightnt": "mightn't", "oughtnt": "oughtn't",
    // Pronoun contractions
    "ive": "I've", "youve": "you've", "weve": "we've", "theyve": "they've",
    "im": "I'm", "youre": "you're", "theyre": "they're",
    "hes": "he's", "shes": "she's",
    "ill": "I'll", "youll": "you'll", "hell": "he'll", "shell": "she'll",
    "well": "we'll", "theyll": "they'll", "itll": "it'll",
    "id": "I'd", "youd": "you'd", "hed": "he'd", "shed": "she'd",
    "wed": "we'd", "theyd": "they'd",
    // Common contractions
    "its": "it's", "thats": "that's", "whats": "what's", "whos": "who's",
    "hows": "how's", "wheres": "where's", "whens": "when's", "whys": "why's",
    "lets": "let's", "theres": "there's", "heres": "here's",
    // Informal contractions (voice input common)
    "gonna": "going to", "gotta": "got to", "wanna": "want to",
    "kinda": "kind of", "sorta": "sort of", "lotta": "lot of",
    "coulda": "could have", "shoulda": "should have", "woulda": "would have",
    "musta": "must have", "mighta": "might have",
    "aint": "isn't", "dunno": "don't know", "lemme": "let me",
    "gimme": "give me", "cmon": "come on", "bout": "about",
    // Additional informal / voice-common
    "yall": "you all", "yknow": "you know", "idk": "I don't know",
    "imo": "in my opinion", "tbh": "to be honest", "ngl": "not going to lie",
    "prolly": "probably", "tryna": "trying to", "finna": "going to",
    "hafta": "have to", "oughta": "ought to", "supposta": "supposed to",
    "whatcha": "what are you", "gotcha": "got you", "betcha": "bet you",
    "howdy": "how do you do",
}

/**
 * Correct a single word using the misspelling dictionary and contractions.
 * Returns { corrected: string, wasCorrected: boolean }
 */
export function correctWord(word) {
    const lower = word.toLowerCase()
    if (commonMisspellings[lower]) return { corrected: commonMisspellings[lower], wasCorrected: true }
    if (contractions[lower]) return { corrected: contractions[lower], wasCorrected: true }
    return { corrected: word, wasCorrected: false }
}

/**
 * Correct all words in a sentence.
 * Returns { corrected: string, corrections: Array<{original, fixed}> }
 */
export function correctSentence(sentence) {
    const corrections = []
    const words = sentence.split(/(\s+)/)
    const corrected = words.map(w => {
        if (/^\s+$/.test(w)) return w
        const { corrected: fixed, wasCorrected } = correctWord(w)
        if (wasCorrected) corrections.push({ original: w, fixed })
        return wasCorrected ? fixed : w
    }).join('')
    return { corrected, corrections }
}

/**
 * Find the best fuzzy match for an input against a list of reference strings.
 * Returns the best match if similarity >= threshold, otherwise null.
 */
export function findBestMatch(input, references, threshold = 0.85) {
    let best = null
    let bestScore = 0
    for (const ref of references) {
        const score = similarity(input, ref)
        if (score > bestScore) {
            bestScore = score
            best = ref
        }
    }
    if (bestScore >= threshold) return { match: best, score: bestScore }

    // Fallback to word-bag matching
    let bestBag = null
    let bestBagScore = 0
    for (const ref of references) {
        const score = wordBagSimilarity(input, ref)
        if (score > bestBagScore) {
            bestBagScore = score
            bestBag = ref
        }
    }
    if (bestBagScore >= threshold) return { match: bestBag, score: bestBagScore, method: 'word-bag' }
    return null
}
