/**
 * ═══════════════════════════════════════════════════════════
 *  LUME INTENT RESOLVER — Main Entry Point
 *  Routes English Mode input through the full pipeline:
 *
 *  English Input
 *    → Auto-Correct Layer
 *    → Sentence Splitter
 *    → Tolerance Chain (7-step per atomic operation):
 *        Step 1: Exact Pattern Match (Layer A)
 *        Step 2: Fuzzy Pattern Match (85%+ similarity)
 *        Step 3: Grammar-Tolerant Word-Bag Match
 *        Step 4: AI Resolution — High Confidence (≥80%)
 *        Step 5: AI Resolution — Low Confidence (50-79%)
 *        Step 6: AI Resolution — Very Low (<50%)
 *        Step 7: Unresolvable
 *    → Security Layer (per-node guardian scan)
 *    → Lume AST nodes (fed to existing Transpiler)
 *
 *  Pipeline: English Source → Intent Resolver → AST → Transpiler → JavaScript
 *  The Lexer and Parser are NOT involved in English Mode.
 * ═══════════════════════════════════════════════════════════
 */

import { autoCorrect, formatCorrections } from './auto-correct.js'
import { matchPattern, patterns } from './pattern-library.js'
import { similarity, wordBagSimilarity, correctSentence } from './fuzzy-matcher.js'
import { splitSentence } from './sentence-splitter.js'
import { resolveTemporal } from './temporal-resolver.js'
import { checkSecurity, scanASTNode, formatThreat, generateCertificate, THREAT_CATEGORIES } from './security-layer.js'
import { resetFileScope, updateMemory, resolvePronoun, getAutocorrectContext } from './context-engine.js'
import { ResolutionManifest, verifyManifestCLI } from './resolution-manifest.js'
import { aiResolve, batchResolve } from './ai-resolver.js'
import { detectLanguage } from './lang-detect.js'
import { resolveMultilingualVerb, translateVerb, getLocalizedError } from './pattern-library-i18n.js'
import { ClarificationCache, enterClarificationMode, formatPlaygroundClarification } from './clarification.js'
import { detectCompoundStart, parseCompoundConditional } from './logic-blocks.js'
import { parseUsingDirective, buildModuleIndex, resolveReference, formatModuleError } from './module-resolver.js'
import { extractHints, summarizeHints } from './hint-parser.js'
import { parseVersionDeclaration, loadProjectConfig } from './pattern-versioning.js'
import { detectPackageReference, recognizePackage, generateImport, formatMissingPackageError } from './package-registry.js'
import { detectStructureStart, parseStructureBlock, compileStructure } from './structure-parser.js'
import { detectTryBlock, parseTryCatchBlock, detectThrowStatement, parseThrowStatement } from './error-handling.js'
import { detectTestBlock, detectDescribeBlock, parseTestBlockFull, parseDescribeBlockFull, detectVerify, parseVerify } from './test-framework.js'
import { detectEnvironmentBlock, parseEnvironmentBlock, detectEnvReference, detectFeatureFlag } from './environment.js'
import { detectConcurrencyBlock, parseConcurrencyBlock, detectSequentialChain, parseSequentialChain, detectTimerInstruction, parseTimerInstruction } from './concurrency.js'
import { detectComment, parseExplainBlock, stripInlineComment, toCommentAST } from './comments.js'
import { detectDeploy, compileDeploy } from './deploy-engine.js'
import { detectConfig, compileConfig } from './config-engine.js'
import { detectEducationCommand, compileEducationCommand } from './education-mode.js'

// ── v1.1.0: LDIR Integration (Deterministic Inference Rulebook) ──
import { DeterministicRulebook } from '../inference/rulebook.js'

// ── Domain Module Registry (v1.0) ──
import { registerDomain, activateDomain, resetActiveDomains, matchDomainPattern, detectUseDomainDirective, domainSummary } from './domain-registry.js'
import webDomain from './domains/web.js'
import dataDomain from './domains/data.js'
import apiDomain from './domains/api.js'
import emailDomain from './domains/email.js'
import scheduleDomain from './domains/schedule.js'
import vaultDomain from './domains/vault.js'

// Register built-in domain modules
registerDomain(webDomain)
registerDomain(dataDomain)
registerDomain(apiDomain)
registerDomain(emailDomain)
registerDomain(scheduleDomain)
registerDomain(vaultDomain)

/**
 * Check if a file should use English Mode
 */
export function detectMode(source) {
    const firstLine = source.split('\n')[0].trim()
    if (firstLine === 'mode: english') return 'english'
    if (firstLine === 'mode: natural') return 'natural'
    return 'standard' // Use existing Lexer → Parser pipeline
}

/**
 * Main resolve function — processes an entire English Mode file
 *
 * @param {string} source - The full .lume file content
 * @param {object} options - { noAutocorrect, strict, lockCache, projectRoot, model, lang }
 * @returns {object} { ast[], diagnostics[], certificate, stats, detectedLanguages }
 */
export async function resolveEnglishFile(source, options = {}) {
    const lines = source.split('\n')
    const mode = detectMode(source)

    // Skip the mode declaration line
    const startLine = lines[0].trim().startsWith('mode:') ? 1 : 0
    const versionLine = lines[startLine]?.trim().startsWith('lume-version:') ? startLine + 1 : startLine

    resetFileScope()
    resetActiveDomains()

    const ast = []
    const diagnostics = []
    const stats = { layerA: 0, layerB: 0, domainHits: 0, autoCorrections: 0, aiCalls: 0, skipped: 0, clarifications: 0, logicBlocks: 0, hints: 0, structures: 0, tryCatch: 0, tests: 0, envBlocks: 0, concurrency: 0, comments: 0, packages: 0, manifestHits: 0, disambiguations: 0 }

    // Resolution Manifest — deterministic compilation (Mandatory in v0.9)
    const manifest = new ResolutionManifest(options.projectRoot || '.')
    const unresolvedLines = [] // Queue for batch AI resolution
    const detectedLanguages = new Map() // Track language per line
    const isMultilingual = mode === 'natural' // mode: natural enables multilingual
    const langOverride = options.lang || null // --lang flag override

    // ── v1.1.0: Initialize LDIR for deterministic inference fallback ──
    const ldir = options.rulebook || new DeterministicRulebook({
        compilerVersion: '1.1.0',
        onGateRequest: options.onGateRequest || null,
    })

    // Gap 1: Clarification cache
    const clarificationCache = new ClarificationCache(options.projectRoot || '.')
    if (options.reclarify) clarificationCache.clear()

    // Gap 3: Parse using: directives and build module index
    const usingFiles = []
    const moduleIndex = options.projectRoot ? buildModuleIndex(options.projectRoot) : { definitions: {}, files: {} }

    // Gap 8: Parse patterns: version declaration
    const patternVersion = parseVersionDeclaration(source)
    if (patternVersion) diagnostics.push({ type: 'info', code: 'LUME-I010', line: 1, message: `Pattern library version: ${patternVersion}` })

    // Gap 9: Track active packages
    const activePackages = new Map()

    for (let i = versionLine; i < lines.length; i++) {
        const rawLine = lines[i]
        const trimmed = rawLine.trim()
        const lineNum = i + 1

        // Skip empty lines
        if (!trimmed) {
            stats.skipped++
            continue
        }

        // Gap 15: Comment detection (BEFORE tolerance chain)
        const comment = detectComment(trimmed)
        if (comment) {
            if (comment.type === 'explain') {
                const explainBlock = parseExplainBlock(lines, i)
                if (explainBlock) {
                    ast.push(toCommentAST({ type: 'explain', text: explainBlock.text }))
                    i = explainBlock.endIdx - 1
                }
            } else {
                ast.push(toCommentAST(comment))
            }
            stats.comments++
            stats.skipped++
            continue
        }

        // Strip inline # comments
        const { instruction: instrWithoutComment, comment: inlineComment } = stripInlineComment(trimmed)
        if (inlineComment) {
            ast.push(toCommentAST({ type: 'hash', text: inlineComment, jsPrefix: '//' }))
        }
        const effectiveTrimmed = instrWithoutComment || trimmed

        // Domain Module: detect `use web`, `use data`, etc.
        const domainDirective = detectUseDomainDirective(effectiveTrimmed)
        if (domainDirective) {
            activateDomain(domainDirective)
            diagnostics.push({ type: 'info', code: 'LUME-I013', line: lineNum, message: `Domain module activated: ${domainDirective}` })
            continue
        }

        // Gap 3: Parse using: directives
        const usingDirective = parseUsingDirective(effectiveTrimmed)
        if (usingDirective) {
            if (usingDirective.type === 'file') usingFiles.push(usingDirective.path)
            else if (usingDirective.candidates) usingFiles.push(...usingDirective.candidates)
            diagnostics.push({ type: 'info', code: 'LUME-I006', line: lineNum, message: `Module import: ${effectiveTrimmed}` })
            continue
        }

        // Gap 9: Package references ("use Express to create a web server")
        const pkgRef = detectPackageReference(effectiveTrimmed)
        if (pkgRef) {
            const pkg = recognizePackage(pkgRef.packageName)
            if (pkg) {
                activePackages.set(pkg.key, pkg)
                ast.push({ type: 'RawBlock', code: generateImport(pkg), line: lineNum })
                stats.packages++
                diagnostics.push({ type: 'info', code: 'LUME-I011', line: lineNum, message: `Package: ${pkg.key} (${pkg.npm})` })
            } else {
                diagnostics.push(formatMissingPackageError(pkgRef.packageName, pkgRef.packageName.toLowerCase(), lineNum))
            }
            // The rest of the instruction still gets processed below
        }

        // Gap 10: Structure definitions ("a user has:")
        const structStart = detectStructureStart(effectiveTrimmed)
        if (structStart) {
            const structBlock = parseStructureBlock(lines, i)
            if (structBlock) {
                guardianScan(structBlock, lineNum, diagnostics, options)
                ast.push(structBlock)
                stats.structures++
                i = structBlock.endIdx - 1
                continue
            }
        }

        // Gap 11: Try/catch blocks ("try to [action]")
        if (detectTryBlock(effectiveTrimmed)) {
            const tcBlock = parseTryCatchBlock(lines, i)
            if (tcBlock) {
                guardianScan(tcBlock, lineNum, diagnostics, options)
                ast.push(tcBlock)
                stats.tryCatch++
                i = tcBlock.endIdx - 1
                continue
            }
        }

        // Gap 11: Throw statements ("stop with error")
        if (detectThrowStatement(effectiveTrimmed)) {
            const throwNode = parseThrowStatement(effectiveTrimmed)
            if (throwNode) {
                ast.push({ ...throwNode, line: lineNum })
                continue
            }
        }

        // Gap 12: Test blocks
        const testBlock = detectTestBlock(effectiveTrimmed)
        const descBlock = detectDescribeBlock(effectiveTrimmed)
        if (descBlock) {
            const suite = parseDescribeBlockFull(lines, i)
            if (suite) { ast.push(suite); stats.tests++; i = suite.endIdx - 1; continue }
        }
        if (testBlock) {
            const tc = parseTestBlockFull(lines, i)
            if (tc) { ast.push(tc); stats.tests++; i = tc.endIdx - 1; continue }
        }

        // Gap 13: Environment blocks ("in production:")
        const envBlock = detectEnvironmentBlock(effectiveTrimmed)
        if (envBlock) {
            const eb = parseEnvironmentBlock(lines, i)
            if (eb) { ast.push(eb); stats.envBlocks++; i = eb.endIdx - 1; continue }
        }

        // Gap 13: Env variable references
        const envRef = detectEnvReference(effectiveTrimmed)
        if (envRef) { ast.push({ ...envRef, line: lineNum }); continue }

        // Gap 13: Feature flags
        const featureFlag = detectFeatureFlag(effectiveTrimmed)
        if (featureFlag) { ast.push({ ...featureFlag, line: lineNum }); continue }

        // Gap 14: Concurrency blocks
        const concBlock = detectConcurrencyBlock(effectiveTrimmed)
        if (concBlock) {
            const cb = parseConcurrencyBlock(lines, i)
            if (cb) { ast.push(cb); stats.concurrency++; i = cb.endIdx - 1; continue }
        }

        // Gap 14: Sequential chains
        if (detectSequentialChain(effectiveTrimmed)) {
            const chain = parseSequentialChain(lines, i)
            if (chain) { ast.push(chain); stats.concurrency++; i = chain.endIdx - 1; continue }
        }

        // Gap 14: Timer instructions
        const timerType = detectTimerInstruction(effectiveTrimmed)
        if (timerType) {
            const timer = parseTimerInstruction(effectiveTrimmed)
            if (timer) { ast.push({ ...timer, line: lineNum }); continue }
        }

        // Gap 2: Detect compound conditional blocks
        const compoundStart = detectCompoundStart(effectiveTrimmed)
        if (compoundStart) {
            const result = parseCompoundConditional(lines, i, lineNum)
            if (result) {
                guardianScan(result.node, lineNum, diagnostics, options)
                ast.push(result.node)
                stats.logicBlocks++
                i = result.endIdx
                continue
            }
        }

        // Handle raw: escape hatch blocks
        if (trimmed === 'raw:') {
            const rawBlock = collectRawBlock(lines, i + 1)
            // Security: scan raw blocks for dangerous patterns
            const rawThreats = scanRawBlock(rawBlock.code, lineNum)
            if (rawThreats.length > 0) {
                diagnostics.push(...rawThreats)
                const blocked = rawThreats.some(t => t.level === 'BLOCK')
                if (blocked) {
                    ast.push({ type: 'RawBlock', code: `/* BLOCKED: raw block failed security scan */`, line: lineNum })
                    i = rawBlock.endLine
                    continue
                }
            }
            ast.push({ type: 'RawBlock', code: rawBlock.code, line: lineNum })
            i = rawBlock.endLine
            diagnostics.push({ type: 'info', code: 'LUME-I004', line: lineNum, message: 'Raw block — bypassing Intent Resolver' })
            continue
        }

        // Step 0: Auto-Correct
        const acContext = getAutocorrectContext()
        const { corrected, corrections, wasModified } = autoCorrect(trimmed, acContext, options)
        if (wasModified) {
            stats.autoCorrections += corrections.length
            if (options.strict) {
                diagnostics.push(...corrections.map(c => ({ type: 'warning', code: 'LUME-I001', line: lineNum, message: `"${c.original}" → "${c.fixed}" (${c.type})` })))
            } else {
                diagnostics.push(...formatCorrections(corrections, lineNum).map(msg => ({ type: 'info', code: 'LUME-I001', line: lineNum, message: msg })))
            }
        }

        // Step 0.3: Multilingual verb translation (mode: natural only)
        let processedInput = corrected
        let lineLanguage = 'en'
        if (isMultilingual) {
            const langResult = langOverride
                ? { code: langOverride, language: langOverride, confidence: 1.0 }
                : detectLanguage(corrected)
            lineLanguage = langResult.code
            detectedLanguages.set(lineNum, { code: langResult.code, language: langResult.language, confidence: langResult.confidence })

            if (langResult.code !== 'en') {
                const verbResult = translateVerb(corrected, langResult.code)
                if (verbResult) {
                    processedInput = verbResult.translated
                    diagnostics.push({ type: 'info', code: 'LUME-I005', line: lineNum, message: `[${langResult.language}] "${verbResult.originalVerb}" → "${verbResult.verb}"` })
                }
            }
        }

        // Step 0.5: Security check on input
        const secCheck = checkSecurity(corrected, options.securityConfig || {})
        if (secCheck.blocked) {
            diagnostics.push(...secCheck.threats.map(t => ({ type: 'error', code: t.code, line: lineNum, message: formatThreat(t, lineNum) })))
            continue // Skip blocked lines
        }
        if (secCheck.needsConfirmation) {
            diagnostics.push(...secCheck.threats.map(t => ({ type: 'confirm', code: t.code, line: lineNum, message: formatThreat(t, lineNum) })))
        }

        // Step 0.7: Split compound sentences
        const operations = splitSentence(processedInput)

        for (const op of operations) {
            // Resolve pronouns (with RFT disambiguation — CHI §5.5)
            const pronounResolved = resolvePronouns(op.text, lineNum)
            if (pronounResolved.warnings) {
                diagnostics.push(...pronounResolved.warnings.map(w => ({ type: 'warning', code: 'LUME-W002', line: lineNum, message: w })))
            }
            if (pronounResolved.disambiguations) {
                diagnostics.push(...pronounResolved.disambiguations)
            }
            const resolveText = pronounResolved.text

            // Gap 5: Extract hint annotations before matching
            const { instruction: hintCleanText, hints, hasHints } = extractHints(resolveText)
            const matchText = hasHints ? hintCleanText : resolveText
            if (hasHints) {
                stats.hints++
                diagnostics.push({ type: 'info', code: 'LUME-I007', line: lineNum, message: `Hints detected: ${summarizeHints(hints)}` })
            }

            // Check for temporal expressions
            const temporal = resolveTemporal(matchText)

            // ═══ TOLERANCE CHAIN ═══

            // Step 0.9: Check Resolution Manifest first (CHI §8.2)
            if (manifest) {
                const cached = manifest.lookup(matchText)
                if (cached) {
                    const node = { ...cached.ast, line: lineNum, resolvedBy: cached.resolvedBy, originalResolvedBy: cached.originalResolvedBy, confidence: cached.confidence, ...(hasHints ? { hints } : {}), ...(isMultilingual ? { language: lineLanguage } : {}) }
                    guardianScan(node, lineNum, diagnostics, options)
                    ast.push(node)
                    updateMemory(lineNum, extractSubject(matchText), extractVerb(matchText), node)
                    stats.manifestHits++
                    diagnostics.push({ type: 'info', code: 'LUME-I012', line: lineNum, message: `Manifest cache hit: "${matchText}" (originally: ${cached.originalResolvedBy})` })
                    continue
                }
            }

            // Step 0.95: Domain Module Pattern Match (priority over general patterns)
            const domainMatch = matchDomainPattern(matchText)
            if (domainMatch.matched) {
                const node = { ...domainMatch.ast, line: lineNum, resolvedBy: `domain_${domainMatch.domain}`, ...(hasHints ? { hints } : {}), ...(isMultilingual ? { language: lineLanguage } : {}) }
                guardianScan(node, lineNum, diagnostics, options)
                ast.push(node)
                updateMemory(lineNum, extractSubject(matchText), extractVerb(matchText), node)
                if (manifest) manifest.record(matchText, node, `domain_${domainMatch.domain}`, 1.0)
                stats.domainHits++
                stats.layerA++
                if (domainMatch.ast._autoDetected) {
                    diagnostics.push({ type: 'info', code: 'LUME-I014', line: lineNum, message: `Auto-detected domain: ${domainMatch.domain} (add \"use ${domainMatch.domain}\" to make explicit)` })
                }
                continue
            }

            // Step 1: Exact Pattern Match (Layer A)
            const exactMatch = matchPattern(matchText)
            if (exactMatch.matched) {
                const node = { ...exactMatch.ast, line: lineNum, resolvedBy: 'layer_a_exact', ...(hasHints ? { hints } : {}), ...(isMultilingual ? { language: lineLanguage } : {}) }
                guardianScan(node, lineNum, diagnostics, options)
                ast.push(node)
                updateMemory(lineNum, extractSubject(matchText), extractVerb(matchText), node)
                if (manifest) manifest.record(matchText, node, 'layer_a_exact', 1.0)
                stats.layerA++
                continue
            }

            // Step 2: Fuzzy Pattern Match (85%+ similarity)
            const fuzzyResult = fuzzyMatch(matchText)
            if (fuzzyResult) {
                const node = { ...fuzzyResult.ast, line: lineNum, resolvedBy: 'layer_a_fuzzy', similarity: fuzzyResult.score, ...(hasHints ? { hints } : {}), ...(isMultilingual ? { language: lineLanguage } : {}) }
                guardianScan(node, lineNum, diagnostics, options)
                ast.push(node)
                updateMemory(lineNum, extractSubject(matchText), extractVerb(matchText), node)
                stats.layerA++
                if (manifest) manifest.record(matchText, node, 'layer_a_fuzzy', fuzzyResult.score)
                diagnostics.push({ type: 'info', code: 'LUME-I003', line: lineNum, message: `Fuzzy match (${(fuzzyResult.score * 100).toFixed(0)}%): "${matchText}" → pattern "${fuzzyResult.pattern}"` })
                continue
            }

            // Step 3: Word-Bag Match
            const bagResult = wordBagMatch(matchText)
            if (bagResult) {
                const node = { ...bagResult.ast, line: lineNum, resolvedBy: 'layer_a_wordbag', similarity: bagResult.score, ...(hasHints ? { hints } : {}), ...(isMultilingual ? { language: lineLanguage } : {}) }
                guardianScan(node, lineNum, diagnostics, options)
                ast.push(node)
                updateMemory(lineNum, extractSubject(matchText), extractVerb(matchText), node)
                stats.layerA++
                if (manifest) manifest.record(matchText, node, 'layer_a_wordbag', bagResult.score)
                diagnostics.push({ type: 'info', code: 'LUME-I003', line: lineNum, message: `Word-bag match (${(bagResult.score * 100).toFixed(0)}%): "${matchText}"` })
                continue
            }

            // Step 3.5: LDIR Deterministic Fallback (v1.1.0)
            // Before queuing for expensive AI resolution, consult the LDIR
            const ldirResult = ldir.resolve(matchText, {
                mode,
                lineNum,
                language: lineLanguage,
                verb: extractVerb(matchText),
                subject: extractSubject(matchText),
            }, 'intent_resolver')

            if (ldirResult.resolved && ldirResult.result) {
                const ldirAst = typeof ldirResult.result === 'object' && ldirResult.result.type
                    ? ldirResult.result
                    : { type: 'RawBlock', code: String(ldirResult.result), line: lineNum }
                const node = { ...ldirAst, line: lineNum, resolvedBy: `ldir_${ldirResult.ruleId}`, confidence: 1.0, tier: ldirResult.tier, ...(hasHints ? { hints } : {}), ...(isMultilingual ? { language: lineLanguage } : {}) }
                guardianScan(node, lineNum, diagnostics, options)
                ast.push(node)
                updateMemory(lineNum, extractSubject(matchText), extractVerb(matchText), node)
                if (manifest) manifest.record(matchText, node, `ldir_${ldirResult.ruleId}`, 1.0)
                stats.layerA++
                diagnostics.push({ type: 'info', code: 'LUME-I015', line: lineNum, message: `LDIR resolved (${ldirResult.tierName} T${ldirResult.tier}): ${ldirResult.ruleId} — "${matchText}"` })
                continue
            }

            // Steps 4-7: Queue for AI resolution (batched)
            unresolvedLines.push({ text: matchText, line: lineNum, temporal, hints: hasHints ? hints : null, originalText: resolveText })
        }
    }

    // Batch AI resolution for all unresolved lines
    if (unresolvedLines.length > 0) {
        stats.aiCalls++
        const texts = unresolvedLines.map(l => l.text)
        const results = await batchResolve(texts, { model: options.model, lockCache: options.lockCache })

        for (let i = 0; i < results.length; i++) {
            const { resolved, ast: aiAst, confidence, error } = results[i]
            const { line, text, hints: lineHints } = unresolvedLines[i]

            if (resolved && confidence >= 0.8) {
                // Step 4: High confidence — Validate schema and lock into manifest
                if (!isValidASTNode(aiAst)) {
                    diagnostics.push({ type: 'error', code: 'LUME-E002', line, message: `AI generated invalid AST schema for: "${text}"` })
                    continue
                }
                const node = { ...aiAst, line, resolvedBy: 'layer_b_ai', confidence, ...(lineHints ? { hints: lineHints } : {}) }
                guardianScan(node, line, diagnostics, options)
                ast.push(node)
                stats.layerB++
                manifest.record(text, node, 'layer_b_ai', confidence)
                diagnostics.push({ type: 'info', code: 'LUME-I003', line, message: `AI resolved (${(confidence * 100).toFixed(0)}% confidence): "${text}". Locked to manifest.` })
            } else if (resolved && confidence >= 0.5) {
                // Step 5: Low confidence — Gap 1: Interactive Clarification Mode
                const clarResult = await enterClarificationMode(text, line, confidence, {
                    nonInteractive: options.nonInteractive,
                    aiResults: [{ interpretation: aiAst?.value || text, ast: aiAst, confidence }],
                    cache: clarificationCache,
                })
                if (clarResult.resolved) {
                    const node = clarResult.ast || { ...aiAst, line, resolvedBy: clarResult.fromCache ? 'clarification_cache' : 'clarification_interactive', confidence: 1.0 }
                    if (!isValidASTNode(node)) {
                        diagnostics.push({ type: 'error', code: 'LUME-E002', line, message: `Invalid AST schema chosen during clarification for: "${text}"` })
                        continue
                    }
                    ast.push(node)
                    stats.clarifications++
                    manifest.record(text, node, clarResult.fromCache ? 'clarification_cache' : 'clarification_interactive', 1.0)
                    diagnostics.push({ type: 'info', code: 'LUME-I008', line, message: `Clarified${clarResult.fromCache ? ' (cached)' : ''}: "${text}" → ${clarResult.resolvedAs || 'developer choice'}` })
                } else if (clarResult.rephrased) {
                    unresolvedLines.push({ text: clarResult.newText, line, temporal: null, hints: lineHints })
                } else if (clarResult.error) {
                    diagnostics.push(clarResult.error)
                }
            } else if (resolved && confidence > 0) {
                // Step 6: Very low confidence — Gap 1: Clarification with more options
                const clarResult = await enterClarificationMode(text, line, confidence, {
                    nonInteractive: options.nonInteractive,
                    cache: clarificationCache,
                })
                if (clarResult.resolved && clarResult.ast) {
                    ast.push(clarResult.ast)
                    stats.clarifications++
                } else if (clarResult.error) {
                    diagnostics.push(clarResult.error)
                } else {
                    diagnostics.push({ type: 'ambiguous', code: 'LUME-W001', line, message: `Very low confidence (${(confidence * 100).toFixed(0)}%): "${text}". Multiple interpretations possible.` })
                }
            } else {
                // Step 7: Unresolvable
                diagnostics.push({ type: 'error', code: 'LUME-E001', line, message: `Unresolvable: "${text}". ${error || 'Try rephrasing.'}` })
            }
        }
    }

    // Sort AST by line number
    ast.sort((a, b) => a.line - b.line)

    // Save Resolution Manifest (CHI §8.2)
    if (manifest) manifest.save()

    // Generate security certificate
    const rawBlockCount = ast.filter(n => n.type === 'RawBlock').length
    const hash = generateHash(ast)
    const certificate = generateCertificate(options.filename || 'unknown.lume', ast.length, rawBlockCount, options.securityConfig?.level || 'standard', hash)

    return {
        mode,
        ast,
        diagnostics,
        certificate,
        manifest: manifest ? manifest.getStats() : null,
        detectedLanguages: Object.fromEntries(detectedLanguages),
        stats: {
            ...stats,
            totalLines: lines.length,
            resolvedLines: ast.length,
            patternMatches: stats.layerA,
            domainMatches: stats.domainHits,
            aiResolutions: stats.layerB,
            autoCorrections: stats.autoCorrections,
            aiCallsMade: stats.aiCalls,
            ldir: ldir.stats(),
        },
    }
}

/* ── Helpers ──────────────────────────────────────────── */

function collectRawBlock(lines, startIdx) {
    const codeLines = []
    let i = startIdx
    const baseIndent = getIndent(lines[i] || '')

    while (i < lines.length) {
        const line = lines[i]
        if (line.trim() === '' && i > startIdx) { i++; continue }
        if (getIndent(line) < baseIndent && line.trim() !== '') break
        codeLines.push(line)
        i++
    }

    return { code: codeLines.join('\n'), endLine: i - 1 }
}

function getIndent(line) {
    const match = line.match(/^(\s*)/)
    return match ? match[1].length : 0
}

function resolvePronouns(text, lineNum = 0) {
    const pronouns = ['\\bit\\b', '\\bthey\\b', '\\bthem\\b', '\\btheir\\b', '\\bthis\\b', '\\bthat\\b', '\\bthose\\b']
    const warnings = []
    const disambiguations = []
    let resolved = text

    // Extract verb for type-aware resolution
    const verb = extractVerb(text)

    for (const p of pronouns) {
        const regex = new RegExp(p, 'gi')
        if (regex.test(text)) {
            const word = text.match(regex)[0]
            const result = resolvePronoun(word, lineNum, verb)

            if (result.disambiguationRequired) {
                // ── CHI §5.5: DisambiguationRequired ──
                // Don't guess — surface the ambiguity to the developer
                disambiguations.push({
                    type: 'disambiguation',
                    code: 'LUME-W004',
                    line: lineNum,
                    message: result.message,
                    candidates: result.candidates,
                    pronoun: result.pronoun,
                })
                warnings.push(result.warning)
            } else if (result.resolved) {
                resolved = resolved.replace(regex, result.value)
                if (result.warning) warnings.push(result.warning)
            } else if (result.warning) {
                warnings.push(result.warning)
            }
        }
    }

    return {
        text: resolved,
        warnings: warnings.length > 0 ? warnings : null,
        disambiguations: disambiguations.length > 0 ? disambiguations : null,
    }
}

function fuzzyMatch(input) {
    let bestScore = 0
    let bestPattern = null

    // Build test strings from patterns (extract the regex source as a readable sentence)
    for (const p of patterns) {
        // Test each pattern by running the regex — if fuzzy enough, might match
        // For now, just try the pattern and see
        // Real fuzzy matching uses representative examples per pattern
    }

    // Simple approach: try softened input against patterns
    const softened = input.toLowerCase()
        .replace(/[''`]/g, "'")
        .replace(/\s+/g, ' ')
        .trim()

    const result = matchPattern(softened)
    if (result.matched) return { ast: result.ast, score: 0.9, pattern: 'softened-exact' }

    return null
}

function wordBagMatch(input) {
    // Extract key words and try to match against known verb+noun patterns
    const words = input.toLowerCase().replace(/[^\w\s]/g, '').split(/\s+/)
    const verbs = ['get', 'show', 'save', 'delete', 'create', 'update', 'send', 'sort', 'filter', 'connect', 'monitor', 'heal', 'optimize', 'evolve']
    const foundVerb = words.find(w => verbs.includes(w))

    if (foundVerb) {
        // Reconstruct a clean sentence: "verb the [remaining nouns]"
        const nouns = words.filter(w => w !== foundVerb && w.length > 2 && !['the', 'from', 'into', 'with', 'and'].includes(w))
        const clean = `${foundVerb} the ${nouns.join(' ')}`
        const result = matchPattern(clean)
        if (result.matched) return { ast: result.ast, score: 0.85, pattern: 'word-bag-reconstruction' }
    }

    return null
}

function extractSubject(text) {
    // Extract the main noun (remove articles and verbs)
    const words = text.toLowerCase().split(/\s+/)
    const skip = new Set(['get', 'show', 'save', 'delete', 'create', 'update', 'send', 'the', 'a', 'an', 'from', 'to', 'in', 'on', 'with', 'all', 'and', 'or'])
    return words.find(w => !skip.has(w) && w.length > 2) || text.split(/\s+/).pop()
}

function extractVerb(text) {
    const words = text.toLowerCase().split(/\s+/)
    const verbs = new Set(['get', 'show', 'save', 'delete', 'create', 'update', 'send', 'sort', 'filter', 'connect', 'wait', 'repeat', 'return', 'set', 'check', 'ask', 'monitor', 'heal', 'optimize', 'evolve', 'fetch', 'display', 'store', 'remove', 'make', 'build', 'deploy', 'verify', 'config', 'draw'])
    return words.find(w => verbs.has(w)) || words[0]
}

function generateHash(ast) {
    // Simple hash for security certificate (production would use crypto.createHash)
    const str = JSON.stringify(ast)
    let hash = 0
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i)
        hash = ((hash << 5) - hash) + char
        hash = hash & hash
    }
    return Math.abs(hash).toString(16).padStart(16, '0')
}

function guardianScan(node, lineNum, diagnostics, options) {
    const scan = scanASTNode(node, options.securityConfig || {})
    if (!scan.safe) {
        diagnostics.push(...scan.threats.map(t => ({ type: t.level === 'BLOCK' ? 'error' : 'warning', code: t.code, line: lineNum, message: formatThreat(t, lineNum) })))
    }
}

function isValidASTNode(node) {
    if (!node || typeof node !== 'object') return false;
    if (!node.type || typeof node.type !== 'string') return false;
    // Enforce basic schema check to prevent prompt-injection of malicious raw node types
    const validTypes = new Set([
        'VariableAccess', 'StoreOperation', 'DeleteOperation', 'CreateOperation', 
        'UpdateOperation', 'SendOperation', 'FilterOperation', 'SortOperation', 
        'ConnectionSetup', 'EventListener', 'NavigateOperation', 'DelayStatement', 
        'LetDeclaration', 'DefineDeclaration', 'ShowStatement', 'LogStatement', 
        'SetStatement', 'ReturnStatement', 'IfStatement', 'WhenStatement', 
        'FunctionDeclaration', 'ForEachStatement', 'ForEachIndexStatement', 
        'ForRangeStatement', 'WhileStatement', 'BreakStatement', 'ContinueStatement', 
        'TypeDeclaration', 'TestBlock', 'VerifyStatement', 'ExpectStatement', 
        'ExportStatement', 'UseStatement', 'AssignmentExpression', 'ReadExpression', 
        'WriteExpression', 'CompoundIfStatement', 'StructureDefinition', 
        'TryCatchStatement', 'ThrowStatement', 'TestSuite', 'TestCase', 
        'EnvironmentBlock', 'EnvVariable', 'FeatureCheck', 'ParallelBlock', 
        'RaceBlock', 'AllSettledBlock', 'SequentialChain', 'TimerStatement',
        // Pattern library types
        'BinaryExpression', 'CallExpression', 'MemberExpression', 'PropertyAccess',
        'RepeatLoop', 'ForEachLoop', 'WhileLoop', 'VariableDeclaration',
        'MonitorBlock', 'HealBlock', 'OptimizeBlock', 'EvolveBlock', 'HealableDecorator',
        'AskExpression', 'ThinkExpression', 'GenerateExpression', 'ExposeStatement',
        'FetchExpression', 'ConvertExpression', 'FormatExpression', 'ScheduleExpression',
        'IntervalExpression', 'GroupOperation', 'MapOperation', 'AggregateExpression',
        'UniqueOperation', 'SliceOperation', 'CloneOperation', 'MergeOperation',
        'StyleOperation', 'SpatialOperation', 'ValidationCheck', 'TryBlock',
        'ConditionalAssignment', 'DefaultAssignment', 'ExistsCheck', 'TypeCheck',
        'SwapOperation', 'ToggleOperation', 'ResetOperation', 'IncrementOperation',
        'DecrementOperation', 'FocusOperation', 'PipeExpression', 'RangeExpression',
        'ElseBlock', 'DateExpression', 'DateMathExpression', 'VerifyExpression',
        'ConfigDeclaration', 'DeployCommand', 'EducationDraw', 'EducationElement',
        'EducationStyle',
        // LDIR D-CMPL-05..10 types
        'CancelOperation',
    ])
    if (!validTypes.has(node.type)) return false;
    
    // Ensure no recursive strings contain eval injection targets (which GuardianScan would normally catch, but good for defense-in-depth)
    return true;
}

/* ── Raw Block Security Scanner ──────────────────────── */
const RAW_BLOCK_THREATS = [
    { pattern: /\beval\s*\(/, category: 'SYSTEM_COMMANDS', message: 'eval() is blocked in raw blocks — use a function instead' },
    { pattern: /\bnew\s+Function\s*\(/, category: 'SYSTEM_COMMANDS', message: 'new Function() is blocked — use a named function instead' },
    { pattern: /\bchild_process\b/, category: 'SYSTEM_COMMANDS', message: 'child_process access blocked in raw blocks' },
    { pattern: /\brequire\s*\(\s*['"]child_process/, category: 'SYSTEM_COMMANDS', message: 'child_process import blocked' },
    { pattern: /\bprocess\.exit\b/, category: 'SYSTEM_COMMANDS', message: 'process.exit() blocked — use return instead' },
    { pattern: /\bfs\s*\.\s*(?:unlink|rmdir|rm)Sync\b/, category: 'FILE_DESTRUCTION', message: 'File deletion blocked in raw blocks' },
    { pattern: /\bfs\s*\.\s*(?:writeFile|appendFile)Sync?\s*\(.*(?:\/etc|\/usr|\/bin|C:\\\\Windows)/i, category: 'FILE_DESTRUCTION', message: 'System file write blocked' },
    { pattern: /\bexecSync\b|\bspawnSync\b/, category: 'SYSTEM_COMMANDS', message: 'Synchronous process execution blocked' },
    { pattern: /\bprocess\.env\b.*(?:=|delete)/, category: 'CREDENTIAL_EXPOSURE', message: 'Modifying environment variables blocked' },
    { pattern: /\bglobal\s*\.\s*(?:process|require|__dirname)/, category: 'PRIVILEGE_ESCALATION', message: 'Global scope manipulation blocked' },
]

function scanRawBlock(code, lineNum) {
    const threats = []
    for (const { pattern, category, message } of RAW_BLOCK_THREATS) {
        if (pattern.test(code)) {
            const cat = THREAT_CATEGORIES[category] || { level: 'BLOCK', code: 'LUME-E003', label: category }
            threats.push({ type: 'error', code: cat.code, level: cat.level, line: lineNum, message: `[guardian:raw] ${message}` })
        }
    }
    return threats
}

/* ── Exports ─────────────────────────────────────────── */
export { matchPattern } from './pattern-library.js'
export { autoCorrect } from './auto-correct.js'
export { splitSentence } from './sentence-splitter.js'
export { checkSecurity, scanASTNode } from './security-layer.js'
export { resolveTemporal } from './temporal-resolver.js'
export { detectLanguage, supportedLanguages } from './lang-detect.js'
export { resolveMultilingualVerb, translateVerb, getLocalizedError } from './pattern-library-i18n.js'

// ── M9: Voice-to-Code ──
export { processTranscription, transcriptionToLume } from './voice-input.js'

// ── M10: Visual Context Awareness ──
export { UIRegistry, getComponentTemplate, SPATIAL_MAP, STYLE_MAP } from './ui-registry.js'
export { parseAppDescription, generateProjectStructure } from './app-generator.js'

// ── M11: Reverse Mode ──
export { explainNode, explainAST, summarizeAST, explainFile as explainFileAST } from './explainer.js'

// ── M12: Collaborative Intent ──
export { diffAST, detectConflicts, renderInLanguage, formatDiff, nodeIdentity } from './ast-differ.js'

// ── M13: Zero-Dependency Runtime ──
export { createBundle, getCompileCommand, detectRuntimeFeatures, detectPlatform, supportedTargets } from './bundler.js'

// ── Gap 1: Interactive Clarification ──
export { ClarificationCache, enterClarificationMode, formatPlaygroundClarification, formatVoiceClarification, generateOptions } from './clarification.js'

// ── Gap 2: Natural Language Logic Blocks ──
export { detectCompoundStart, parseCompoundConditional, compileConditionExpression } from './logic-blocks.js'

// ── Gap 3: Implicit Module Resolution ──
export { parseUsingDirective, buildModuleIndex, resolveReference, formatModuleError, detectCircularDeps } from './module-resolver.js'

// ── Gap 4: Canonical Formatter ──
export { canonicalize, canonicalizeFile, isCanonical, loadStyleConfig, VERB_SYNONYMS } from './canonicalizer.js'

// ── Gap 5: Hint Annotations ──
export { extractHints, summarizeHints, generateCacheWrapper, generateRetryWrapper, generateTimeoutWrapper } from './hint-parser.js'

// ── Gap 6: Error Translation ──
export { translateError, formatEnglishError, createStepDebugger } from './error-translator.js'

// ── CHI §8.2: Resolution Manifest ──
export { ResolutionManifest, verifyManifestCLI } from './resolution-manifest.js'

// ── CHI §8.3: Review Mode ──
export { formatReviewEntry, generateReviewReport, cliReviewMode, playgroundReviewData, auditoryReviewText } from './review-mode.js'

// ── CHI §7.2: Auditory Mode ──
export { BrowserAuditoryEngine, CLIAuditoryEngine, AuditoryMode } from './auditory-mode.js'

// ── Vertical Applications ──
export { detectDeploy, compileDeploy, DEPLOY_TARGETS, deployPatterns } from './deploy-engine.js'
export { detectConfig, compileConfig, CONFIG_TYPES, configPatterns } from './config-engine.js'
export { detectEducationCommand, compileEducationCommand, educationError, educationPatterns, COLORS, SHAPES, SIZES } from './education-mode.js'
export { detectVerify, parseVerify, verifyPatterns } from './test-framework.js'

// ── v1.0: Domain Module Registry ──
export { registerDomain, activateDomain, deactivateDomain, resetActiveDomains, matchDomainPattern, detectUseDomainDirective, getRegisteredDomains, getActiveDomains, getDomain, domainSummary } from './domain-registry.js'
