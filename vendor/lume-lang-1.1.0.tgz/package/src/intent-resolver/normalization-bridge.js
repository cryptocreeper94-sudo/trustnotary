/**
 * ═══════════════════════════════════════════════════════════
 *  LUME NORMALIZATION BRIDGE
 *  §2 Layer 1 — Deterministic ASR Variance Resolution
 *
 *  AX-04: VOICE IS A FIRST-CLASS INPUT MODALITY
 *  Voice-to-intent pipelines carry the same deterministic
 *  guarantees as text input. ASR variance is resolved BEFORE
 *  intent-resolution, not after.
 *
 *  D-VOX-01: ASR candidate selection (confidence ≥ 0.85, SHA-256 tiebreak)
 *  D-VOX-02: Normalization must be idempotent
 *  D-VOX-03: Silence ≥ 3.0s = UTTERANCE_END
 *
 *  By DarkWave Studios LLC — DarkWaveStudios.io
 *  Copyright 2026. Protected by TrustShield.tech
 * ═══════════════════════════════════════════════════════════
 */

import crypto from 'crypto'

const CONFIDENCE_THRESHOLD = 0.85
const SILENCE_THRESHOLD = 3.0  // seconds
const FILLER_WORDS = new Set([
    'um', 'uh', 'er', 'ah', 'like', 'you know', 'i mean',
    'basically', 'actually', 'literally', 'right', 'so',
    'well', 'hmm', 'uhh', 'umm', 'ehh',
])

// Homophone pairs — ASR commonly confuses these
const HOMOPHONES = new Map([
    ['their', 'there'],   ['there', 'there'],   ['theyre', 'there'],
    ['your', 'your'],     ['youre', 'your'],
    ['its', 'its'],       ['itz', 'its'],
    ['to', 'to'],         ['too', 'to'],         ['two', 'two'],
    ['for', 'for'],       ['four', 'four'],
    ['new', 'new'],       ['knew', 'new'],
    ['write', 'write'],   ['right', 'right'],
    ['no', 'no'],         ['know', 'no'],
    ['buy', 'buy'],       ['by', 'by'],
    ['sea', 'see'],       ['see', 'see'],
])

// Spoken punctuation → actual punctuation
const SPOKEN_PUNCTUATION = new Map([
    ['period', '.'], ['dot', '.'], ['full stop', '.'],
    ['comma', ','],
    ['question mark', '?'],
    ['exclamation mark', '!'], ['exclamation point', '!'],
    ['semicolon', ';'], ['semi colon', ';'],
    ['colon', ':'],
    ['open parenthesis', '('], ['close parenthesis', ')'],
    ['open bracket', '['], ['close bracket', ']'],
    ['open brace', '{'], ['close brace', '}'],
    ['quote', '"'], ['end quote', '"'],
    ['single quote', "'"],
    ['equals', '='], ['equal sign', '='],
    ['plus', '+'], ['minus', '-'],
    ['asterisk', '*'], ['star', '*'],
    ['slash', '/'], ['forward slash', '/'],
    ['backslash', '\\'],
    ['ampersand', '&'], ['and sign', '&'],
    ['pipe', '|'],
    ['at sign', '@'], ['at', '@'],
    ['hash', '#'], ['hashtag', '#'],
    ['dollar sign', '$'],
    ['percent', '%'],
    ['caret', '^'],
    ['tilde', '~'],
    ['underscore', '_'],
    ['new line', '\n'], ['newline', '\n'],
    ['tab', '\t'],
])

/**
 * Normalize a single text string deterministically.
 * D-VOX-02: This function MUST be idempotent: normalize(normalize(x)) === normalize(x)
 *
 * @param {string} text - Raw text from ASR or typed input
 * @returns {string} Normalized text
 */
export function normalize(text) {
    if (!text || typeof text !== 'string') return ''

    let result = text

    // Step 1: Lowercase
    result = result.toLowerCase()

    // Step 2: Unicode NFC normalization
    result = result.normalize('NFC')

    // Step 3: Collapse stutters (repeated words)
    result = collapseStutters(result)

    // Step 4: Strip filler words
    result = stripFillers(result)

    // Step 5: Resolve spoken punctuation
    result = resolveSpokenPunctuation(result)

    // Step 6: Collapse whitespace
    result = result.replace(/\s+/g, ' ').trim()

    return result
}

/**
 * Collapse stuttered/repeated words.
 * "create create a a variable" → "create a variable"
 */
export function collapseStutters(text) {
    const words = text.split(/\s+/)
    const result = []

    for (let i = 0; i < words.length; i++) {
        if (i === 0 || words[i] !== words[i - 1]) {
            result.push(words[i])
        }
    }

    return result.join(' ')
}

/**
 * Strip filler words.
 * "um create like a variable" → "create a variable"
 */
export function stripFillers(text) {
    const words = text.split(/\s+/)
    return words.filter(w => !FILLER_WORDS.has(w)).join(' ')
}

/**
 * Resolve spoken punctuation into actual characters.
 * "create a variable period" → "create a variable."
 */
export function resolveSpokenPunctuation(text) {
    let result = text

    // Sort by length descending to match longer phrases first
    const sorted = [...SPOKEN_PUNCTUATION.entries()]
        .sort((a, b) => b[0].length - a[0].length)

    for (const [spoken, punct] of sorted) {
        // Only replace when surrounded by word boundaries
        const regex = new RegExp(`\\b${spoken.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'gi')
        result = result.replace(regex, punct)
    }

    return result
}

/**
 * Select the best ASR candidate deterministically.
 * D-VOX-01: Discard below 0.85 confidence. Among remaining, lowest SHA-256 wins.
 *
 * @param {Array} candidates - [{ text, confidence, ... }]
 * @returns {{ selected: Object|null, rejected: Array, method: string }}
 */
export function selectCandidate(candidates) {
    if (!candidates || candidates.length === 0) {
        return { selected: null, rejected: [], method: 'no_candidates' }
    }

    // Filter by confidence threshold
    const qualifying = candidates.filter(c => c.confidence >= CONFIDENCE_THRESHOLD)
    const rejected = candidates.filter(c => c.confidence < CONFIDENCE_THRESHOLD)

    if (qualifying.length === 0) {
        return {
            selected: null,
            rejected: candidates,
            method: 'none_above_threshold',
            threshold: CONFIDENCE_THRESHOLD,
            bestConfidence: Math.max(...candidates.map(c => c.confidence)),
        }
    }

    if (qualifying.length === 1) {
        return {
            selected: { ...qualifying[0], normalized: normalize(qualifying[0].text) },
            rejected,
            method: 'single_qualifying',
        }
    }

    // Multiple qualifying — normalize each and pick by lowest SHA-256 hash
    const hashed = qualifying.map(c => {
        const normalized = normalize(c.text)
        const hash = crypto.createHash('sha256').update(normalized).digest('hex')
        return { ...c, normalized, hash }
    })

    hashed.sort((a, b) => a.hash.localeCompare(b.hash))

    return {
        selected: hashed[0],
        rejected,
        method: 'sha256_tiebreaker',
        qualifyingCount: qualifying.length,
    }
}

/**
 * Process silence segments.
 * D-VOX-03: ≥ 3.0s = UTTERANCE_END. < 3.0s = stripped.
 *
 * @param {Array} segments - [{ type: 'speech'|'silence', duration, text? }]
 * @returns {Array} Processed segments with silence handled
 */
export function processSilence(segments) {
    const result = []

    for (const segment of segments) {
        if (segment.type === 'silence') {
            if (segment.duration >= SILENCE_THRESHOLD) {
                result.push({
                    type: 'utterance_end',
                    duration: segment.duration,
                    threshold: SILENCE_THRESHOLD,
                })
            }
            // Silence < threshold is stripped (not added to result)
        } else {
            result.push(segment)
        }
    }

    return result
}

/**
 * Full normalization pipeline for voice input.
 * Takes raw ASR output and produces deterministic normalized tokens.
 *
 * @param {Object} asrOutput
 * @param {Array} asrOutput.candidates - ASR transcription candidates
 * @param {Array} [asrOutput.segments] - Audio segments with silence info
 * @returns {Object} Normalized result
 */
export function normalizeVoiceInput(asrOutput) {
    const { candidates = [], segments = [] } = asrOutput

    // Step 1: Select best candidate (D-VOX-01)
    const selection = selectCandidate(candidates)

    if (!selection.selected) {
        return {
            success: false,
            text: null,
            normalized: null,
            reason: selection.method,
            selection,
        }
    }

    // Step 2: Normalize the selected text
    const normalized = normalize(selection.selected.text)

    // Step 3: Process silence segments (D-VOX-03)
    const processedSegments = processSilence(segments)
    const hasUtteranceEnd = processedSegments.some(s => s.type === 'utterance_end')

    // Step 4: Tokenize for intent resolution
    const tokens = normalized.split(/\s+/).filter(t => t.length > 0)

    return {
        success: true,
        text: selection.selected.text,
        normalized,
        tokens,
        tokenCount: tokens.length,
        confidence: selection.selected.confidence,
        method: selection.method,
        utteranceComplete: hasUtteranceEnd,
        selection,
        segments: processedSegments,
    }
}

/**
 * Verify that the normalization function is idempotent.
 * D-VOX-02: normalize(normalize(x)) === normalize(x) for all inputs.
 *
 * @param {string[]} testInputs - Array of test strings
 * @returns {{ idempotent: boolean, failures: string[] }}
 */
export function verifyIdempotency(testInputs) {
    const failures = []

    for (const input of testInputs) {
        const once = normalize(input)
        const twice = normalize(once)
        if (once !== twice) {
            failures.push({ input, firstPass: once, secondPass: twice })
        }
    }

    return { idempotent: failures.length === 0, failures, tested: testInputs.length }
}

export default {
    normalize,
    collapseStutters,
    stripFillers,
    resolveSpokenPunctuation,
    selectCandidate,
    processSilence,
    normalizeVoiceInput,
    verifyIdempotency,
    CONFIDENCE_THRESHOLD,
    SILENCE_THRESHOLD,
}
