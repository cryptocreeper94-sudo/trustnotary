/**
 * ═══════════════════════════════════════════════════════════
 *  LUME INTENT RESOLVER — Voice Input Processor
 *  Post-processes speech-to-text transcriptions before they
 *  enter the Intent Resolver pipeline.
 *
 *  Handles:
 *    - Structural cue parsing ("when", "if", "then" → block structure)
 *    - Verbal corrections ("scratch that", "no I mean")
 *    - Pause detection (gaps → block boundaries)
 *    - Variable naming from speech ("call it user count" → userCount)
 *    - Filler word stripping
 *    - Number word conversion
 * ═══════════════════════════════════════════════════════════
 */

/* ═══════════════════════════════════════════════════════════════
 *  FILLER WORDS — 80+ speech patterns
 *  Stripped from voice input before compilation.
 *  Includes single-word fillers, multi-word discourse markers,
 *  and common verbal tics from real speech.
 * ═══════════════════════════════════════════════════════════════ */

const FILLER_WORDS = new Set([
    // Classic fillers
    'um', 'uh', 'erm', 'er', 'ah', 'hmm', 'hm', 'mm', 'mmm', 'uhh', 'umm',
    'mhm', 'aha', 'ehm', 'ahem', 'huh',
    // Discourse markers (single word)
    'like', 'basically', 'so', 'well', 'right', 'okay', 'ok', 'honestly',
    'literally', 'obviously', 'clearly', 'anyway', 'anyways', 'essentially',
    'apparently', 'presumably', 'supposedly', 'technically', 'actually',
    'whatever', 'anyhow', 'furthermore',
    // Multi-word fillers
    'you know', 'i mean', 'i guess', 'you see', 'i think',
    'sort of', 'kind of', 'let me think', 'how should i say',
    'in other words', 'if you will', 'as i was saying',
    'for what its worth', 'for what it is worth', 'at the end of the day',
    'to be honest', 'to be fair', 'i suppose',
    'in a way', 'in a sense', 'as it were', 'so to speak',
    'if you know what i mean', 'you know what i mean',
    'at any rate', 'in any case', 'in any event',
    'as a matter of fact', 'the thing is', 'the point is',
    'i would say', 'let me see', 'how do i put this',
    // Hedge words (reduce certainty — strip for code)
    'maybe', 'perhaps', 'probably', 'possibly', 'presumably',
    'roughly', 'approximately', 'more or less',
    // Verbal tics
    'look', 'see', 'listen', 'hear me out', 'the thing is',
])

/* ═══════════════════════════════════════════════════════════════
 *  HOMOPHONE RESOLVER — 50+ context-aware pairs
 *  Each rule has: words (the homophone set), context rules
 *  (regex patterns that determine which word fits), and a
 *  default choice for programming contexts.
 * ═══════════════════════════════════════════════════════════════ */

const HOMOPHONE_RULES = [
    // ── Core Programming Homophones ──────────────────────────
    {
        words: ['write', 'right'], rules: [
            { context: /\b(file|data|database|disk|storage|output|save|log|record|store|code|text|content|string|buffer|stream|csv|json|xml|html|script)\b/i, pick: 'write' },
            { context: /\b(correct|direction|side|left|turn|way|answer|proper|accurate)\b/i, pick: 'right' },
        ], default: 'write'
    },
    {
        words: ['new', 'knew'], rules: [
            { context: /\b(create|make|build|generate|add|variable|function|project|file|item|instance|object|array|class|component|module|record)\b/i, pick: 'new' },
            { context: /\b(already|before|past|yesterday|remember|thought|realized|understood)\b/i, pick: 'knew' },
        ], default: 'new'
    },
    {
        words: ['for', 'four'], rules: [
            { context: /\b(each|every|loop|iterate|repeat|while|range|item|element|all|index|count)\b/i, pick: 'for' },
            { context: /\b(number|count|times|buttons|items|columns|rows|users|pages|\d)\b/i, pick: 'four' },
        ], default: 'for'
    },
    {
        words: ['their', 'there', 'they\'re'], rules: [
            { context: /\b(name|email|data|profile|account|password|setting|age|role|score|input|value|status|address|phone)\b/i, pick: 'their' },
            { context: /\b(is|are|exists?|goes|put|place|location|already|should)\b/i, pick: 'there' },
        ], default: 'their'
    },
    {
        words: ['two', 'to', 'too'], rules: [
            { context: /\b(number|count|times|buttons|items|pair|both|columns|rows|\d)\b/i, pick: 'two' },
            { context: /\b(much|many|large|big|small|also|excessive|slow|fast|long|short)\b/i, pick: 'too' },
        ], default: 'to'
    },
    {
        words: ['no', 'know'], rules: [
            { context: /\b(not|don't|never|none|stop|cancel|deny|reject|false|zero|empty|null)\b/i, pick: 'no' },
            { context: /\b(if|whether|check|about|understand|tell|find|determine|learn|discover)\b/i, pick: 'know' },
        ], default: 'no'
    },
    {
        words: ['by', 'buy'], rules: [
            { context: /\b(multiply|divide|sort|filter|group|name|date|id|order|ascending|descending|key)\b/i, pick: 'by' },
            { context: /\b(purchase|shop|cart|order|price|pay|payment|store|product|checkout)\b/i, pick: 'buy' },
        ], default: 'by'
    },
    {
        words: ['sea', 'see'], rules: [
            { context: /\b(ocean|water|beach|wave|fish|ship|marine|boat|swim)\b/i, pick: 'sea' },
            { context: /\b(show|display|view|look|check|screen|visible|if|whether|can|page)\b/i, pick: 'see' },
        ], default: 'see'
    },
    {
        words: ['mail', 'male'], rules: [
            { context: /\b(email|send|inbox|message|notification|letter|smtp|forward|reply|cc|bcc)\b/i, pick: 'mail' },
            { context: /\b(gender|sex|female|person|user|profile|demographic|identity)\b/i, pick: 'male' },
        ], default: 'mail'
    },
    {
        words: ['wait', 'weight'], rules: [
            { context: /\b(second|minute|pause|delay|timeout|sleep|hold|until|loading|async)\b/i, pick: 'wait' },
            { context: /\b(heavy|light|measure|kg|lb|mass|load|scale|body|font|bold)\b/i, pick: 'weight' },
        ], default: 'wait'
    },
    // ── Tech-Specific Homophones ─────────────────────────────
    {
        words: ['cache', 'cash'], rules: [
            { context: /\b(store|memory|redis|cdn|browser|local|clear|invalidate|hit|miss|expire|ttl|server|http|data|fast|speed)\b/i, pick: 'cache' },
            { context: /\b(money|payment|dollar|price|amount|bank|withdrawal|register|till|change)\b/i, pick: 'cash' },
        ], default: 'cache'
    },
    {
        words: ['queue', 'cue'], rules: [
            { context: /\b(message|task|job|worker|process|enqueue|dequeue|fifo|rabbitmq|sqs|redis|buffer|pending|priority)\b/i, pick: 'queue' },
            { context: /\b(visual|animation|video|audio|music|start|signal|prompt|hint)\b/i, pick: 'cue' },
        ], default: 'queue'
    },
    {
        words: ['byte', 'bite'], rules: [
            { context: /\b(data|size|memory|kilobyte|megabyte|gigabyte|buffer|stream|binary|file|storage|disk|kb|mb|gb)\b/i, pick: 'byte' },
            { context: /\b(food|eat|mouth|tooth|snake|dog|animal)\b/i, pick: 'bite' },
        ], default: 'byte'
    },
    {
        words: ['site', 'sight', 'cite'], rules: [
            { context: /\b(web|website|page|url|domain|host|deploy|online|http|link|landing)\b/i, pick: 'site' },
            { context: /\b(see|view|vision|eye|look|visible|blind|line|range)\b/i, pick: 'sight' },
            { context: /\b(reference|source|quote|paper|academic|bibliography)\b/i, pick: 'cite' },
        ], default: 'site'
    },
    {
        words: ['passed', 'past'], rules: [
            { context: /\b(test|check|validation|exam|passed|function|argument|parameter|returned)\b/i, pick: 'passed' },
            { context: /\b(previous|history|ago|before|last|old|former|earlier|yesterday)\b/i, pick: 'past' },
        ], default: 'passed'
    },
    {
        words: ['root', 'route'], rules: [
            { context: /\b(admin|superuser|permission|directory|tree|node|parent|child|folder|path|sudo|home)\b/i, pick: 'root' },
            { context: /\b(url|path|page|navigate|api|endpoint|get|post|handler|express|router|navigation|redirect)\b/i, pick: 'route' },
        ], default: 'route'
    },
    {
        words: ['source', 'sauce'], rules: [
            { context: /\b(code|open|file|data|origin|version|control|git|repository)\b/i, pick: 'source' },
            { context: /\b(food|cook|recipe|tomato|hot|bbq|dipping)\b/i, pick: 'sauce' },
        ], default: 'source'
    },
    {
        words: ['pair', 'pear'], rules: [
            { context: /\b(key|value|programming|match|couple|two|set|mapping)\b/i, pick: 'pair' },
            { context: /\b(fruit|food|tree|eat|green|ripe)\b/i, pick: 'pear' },
        ], default: 'pair'
    },
    {
        words: ['sine', 'sign'], rules: [
            { context: /\b(math|angle|wave|cosine|tangent|trigonometry|function|curve)\b/i, pick: 'sine' },
            { context: /\b(up|in|out|display|show|name|signal|plus|minus|equal|positive|negative)\b/i, pick: 'sign' },
        ], default: 'sign'
    },
    {
        words: ['log', 'logged'], rules: [
            { context: /\b(console|print|debug|error|warning|info|output|file|message|system|event|entry|server)\b/i, pick: 'log' },
        ], default: 'log'
    },
    {
        words: ['role', 'roll'], rules: [
            { context: /\b(user|admin|permission|access|based|assignment|authorization|privilege)\b/i, pick: 'role' },
            { context: /\b(dice|back|over|forward|scroll|number|random|animation)\b/i, pick: 'roll' },
        ], default: 'role'
    },
    {
        words: ['brake', 'break'], rules: [
            { context: /\b(car|vehicle|stop|slow|pedal|disc|drum|pad)\b/i, pick: 'brake' },
            { context: /\b(loop|switch|case|out|line|page|point|statement|code|flow)\b/i, pick: 'break' },
        ], default: 'break'
    },
    {
        words: ['plain', 'plane'], rules: [
            { context: /\b(text|simple|ordinary|basic|clear|ascii|format|string|html)\b/i, pick: 'plain' },
            { context: /\b(geometry|3d|x|y|z|flat|surface|math|coordinate|fly|air)\b/i, pick: 'plane' },
        ], default: 'plain'
    },
    {
        words: ['base', 'bass'], rules: [
            { context: /\b(data|class|number|url|path|64|encode|decode|binary|hex|octal|component|template|layer)\b/i, pick: 'base' },
            { context: /\b(music|sound|audio|frequency|guitar|speaker|low|deep)\b/i, pick: 'bass' },
        ], default: 'base'
    },
    {
        words: ['bin', 'been'], rules: [
            { context: /\b(directory|folder|binary|executable|path|node|recycle|trash|delete)\b/i, pick: 'bin' },
            { context: /\b(has|have|had|i've|it|already|never)\b/i, pick: 'been' },
        ], default: 'been'
    },
    {
        words: ['allowed', 'aloud'], rules: [
            { context: /\b(permission|access|user|role|admin|cors|origin|method|action|rule)\b/i, pick: 'allowed' },
            { context: /\b(speak|read|say|voice|loud|hear|sound|listen)\b/i, pick: 'aloud' },
        ], default: 'allowed'
    },
    {
        words: ['check', 'czech'], rules: [
            { context: /\b(if|whether|validation|verify|test|inspect|review|box|mark|condition)\b/i, pick: 'check' },
        ], default: 'check'
    },
    {
        words: ['sum', 'some'], rules: [
            { context: /\b(total|add|calculate|math|aggregate|number|values|array|reduce)\b/i, pick: 'sum' },
            { context: /\b(of|the|few|any|items|users|people|data|results)\b/i, pick: 'some' },
        ], default: 'some'
    },
    {
        words: ['mode', 'mowed'], rules: [
            { context: /\b(dark|light|edit|view|debug|production|development|test|strict|safe|english|voice)\b/i, pick: 'mode' },
        ], default: 'mode'
    },
    {
        words: ['node', 'nowed'], rules: [
            { context: /\b(js|javascript|server|tree|dom|element|child|parent|graph|ast|leaf)\b/i, pick: 'node' },
        ], default: 'node'
    },
    {
        words: ['key', 'quay'], rules: [
            { context: /\b(value|pair|object|map|api|access|primary|foreign|index|press|keyboard|encrypt|ssh|secret)\b/i, pick: 'key' },
        ], default: 'key'
    },
    {
        words: ['pole', 'poll'], rules: [
            { context: /\b(north|south|magnetic|flag|vertical|position)\b/i, pick: 'pole' },
            { context: /\b(survey|vote|question|interval|check|data|status|long|short|event)\b/i, pick: 'poll' },
        ], default: 'poll'
    },
    {
        words: ['idle', 'idol'], rules: [
            { context: /\b(state|timeout|process|thread|worker|connection|inactive|sleep|waiting|callback)\b/i, pick: 'idle' },
        ], default: 'idle'
    },
    {
        words: ['ad', 'add'], rules: [
            { context: /\b(new|item|element|row|column|user|record|entry|field|value|data|another|more|extra|button|class)\b/i, pick: 'add' },
            { context: /\b(advertisement|banner|campaign|marketing|click|impression|display)\b/i, pick: 'ad' },
        ], default: 'add'
    },
    {
        words: ['one', 'won'], rules: [
            { context: /\b(number|single|item|element|first|only|each|another|more|at|just)\b/i, pick: 'one' },
            { context: /\b(game|match|race|competition|prize|award|victory|battle)\b/i, pick: 'won' },
        ], default: 'one'
    },
    // ── Additional Homophones (50+ total) ────────────────────
    {
        words: ['scene', 'seen'], rules: [
            { context: /\b(render|3d|animation|game|view|camera|background|stage|set|movie|act|transition)\b/i, pick: 'scene' },
            { context: /\b(have|has|had|already|never|ever|been|before|just|recently)\b/i, pick: 'seen' },
        ], default: 'seen'
    },
    {
        words: ['steel', 'steal'], rules: [
            { context: /\b(metal|material|strong|bridge|beam|gray|structure|alloy|iron)\b/i, pick: 'steel' },
            { context: /\b(data|credentials|password|token|session|cookie|identity|secret|take)\b/i, pick: 'steal' },
        ], default: 'steal'
    },
    {
        words: ['hear', 'here'], rules: [
            { context: /\b(sound|audio|voice|listen|ear|music|speech|noise|microphone)\b/i, pick: 'hear' },
            { context: /\b(click|put|place|insert|add|this|current|local|below|above|file|page)\b/i, pick: 'here' },
        ], default: 'here'
    },
    {
        words: ['wear', 'where'], rules: [
            { context: /\b(clothes|shirt|hat|shoes|outfit|fashion|dress|uniform)\b/i, pick: 'wear' },
            { context: /\b(location|find|is|are|place|clause|condition|query|search|directory)\b/i, pick: 'where' },
        ], default: 'where'
    },
    {
        words: ['whole', 'hole'], rules: [
            { context: /\b(entire|complete|full|total|all|everything|number|set|array|object)\b/i, pick: 'whole' },
            { context: /\b(dig|gap|empty|fill|punch|security|opening|vulnerability|exploit)\b/i, pick: 'hole' },
        ], default: 'whole'
    },
    {
        words: ['tail', 'tale'], rules: [
            { context: /\b(call|recursion|end|last|log|file|queue|list|array|pointer|linked)\b/i, pick: 'tail' },
            { context: /\b(story|narrative|fairy|folk|tell|telling)\b/i, pick: 'tale' },
        ], default: 'tail'
    },
    {
        words: ['weak', 'week'], rules: [
            { context: /\b(reference|type|map|set|password|security|signal|coupling|link)\b/i, pick: 'weak' },
            { context: /\b(day|monday|tuesday|wednesday|thursday|friday|calendar|schedule|last|next|this|per|every)\b/i, pick: 'week' },
        ], default: 'week'
    },
    {
        words: ['waist', 'waste'], rules: [
            { context: /\b(body|size|measure|belt|hip)\b/i, pick: 'waist' },
            { context: /\b(memory|resource|time|space|cpu|bandwidth|cycle|garbage|leak)\b/i, pick: 'waste' },
        ], default: 'waste'
    },
    {
        words: ['peer', 'pier'], rules: [
            { context: /\b(network|node|p2p|review|connection|to|dependency|certificate)\b/i, pick: 'peer' },
            { context: /\b(dock|harbor|ocean|water|boat|fishing|port)\b/i, pick: 'pier' },
        ], default: 'peer'
    },
    {
        words: ['board', 'bored'], rules: [
            { context: /\b(dashboard|kanban|trello|task|project|white|message|bulletin|circuit|keyboard)\b/i, pick: 'board' },
        ], default: 'board'
    },
    {
        words: ['ceiling', 'sealing'], rules: [
            { context: /\b(rate|limit|max|maximum|cap|upper|bound|price|glass)\b/i, pick: 'ceiling' },
        ], default: 'ceiling'
    },
    {
        words: ['principal', 'principle'], rules: [
            { context: /\b(amount|loan|debt|investment|balance|interest|account)\b/i, pick: 'principal' },
            { context: /\b(design|solid|single|responsibility|pattern|rule|law|dry|kiss)\b/i, pick: 'principle' },
        ], default: 'principle'
    },
    {
        words: ['instance', 'instants'], rules: [
            { context: /\b(new|create|class|object|aws|ec2|server|variable|single|method|type)\b/i, pick: 'instance' },
        ], default: 'instance'
    },
    {
        words: ['complement', 'compliment'], rules: [
            { context: /\b(color|two|bit|ones|system|binary|number|set|math)\b/i, pick: 'complement' },
        ], default: 'complement'
    },
    {
        words: ['discrete', 'discreet'], rules: [
            { context: /\b(math|value|step|event|signal|variable|sample|data|set)\b/i, pick: 'discrete' },
        ], default: 'discrete'
    },
    {
        words: ['flour', 'flower'], rules: [
            { context: /\b(bake|cook|recipe|bread|cake|food|kitchen|dough)\b/i, pick: 'flour' },
            { context: /\b(plant|garden|bloom|petal|rose|bouquet|image|icon)\b/i, pick: 'flower' },
        ], default: 'flower'
    },
    {
        words: ['leak', 'leek'], rules: [
            { context: /\b(memory|resource|data|connection|socket|handle|file|buffer|fd|goroutine|thread)\b/i, pick: 'leak' },
            { context: /\b(food|vegetable|soup|cook|recipe|onion)\b/i, pick: 'leek' },
        ], default: 'leak'
    },
    {
        words: ['course', 'coarse'], rules: [
            { context: /\b(of|tutorial|online|learning|training|class|module|lesson|complete|udemy)\b/i, pick: 'course' },
            { context: /\b(grain|texture|rough|resolution|detail|grained)\b/i, pick: 'coarse' },
        ], default: 'course'
    },
]

/**
 * Resolve homophones using surrounding context.
 * Runs BEFORE auto-correct.
 */
export function resolveHomophones(text) {
    let result = text
    for (const rule of HOMOPHONE_RULES) {
        for (const word of rule.words) {
            const regex = new RegExp(`\\b${word}\\b`, 'gi')
            if (!regex.test(result)) continue
            // Determine which word fits context
            let picked = rule.default
            for (const r of rule.rules) {
                if (r.context.test(result)) { picked = r.pick; break }
            }
            // Replace all instances of any variant with the picked word
            for (const w of rule.words) {
                if (w !== picked) {
                    result = result.replace(new RegExp(`\\b${w}\\b`, 'gi'), picked)
                }
            }
        }
    }
    return result
}

/* ── Stutter / Repeat Collapse ──────────────────────── */

/**
 * Collapse repeated/stuttered words: "get get the name" → "get the name"
 */
export function collapseRepeats(text) {
    return text.replace(/\b(\w+)(\s+\1)+\b/gi, '$1')
}

/* ── Spoken Punctuation Handler ─────────────────────── */

const SPOKEN_PUNCTUATION = [
    { pattern: /\b(?:period|full stop|dot)\b/gi, replacement: '.' },
    { pattern: /\bnew line\b/gi, replacement: '\n' },
    { pattern: /\bcomma\b/gi, replacement: ',' },
    { pattern: /\bquestion mark\b/gi, replacement: '?' },
    { pattern: /\bexclamation (?:mark|point)\b/gi, replacement: '!' },
    { pattern: /\bcolon\b/gi, replacement: ':' },
    { pattern: /\bsemicolon\b/gi, replacement: ';' },
    { pattern: /\bopen (?:paren|parenthesis|bracket)\b/gi, replacement: '(' },
    { pattern: /\bclose (?:paren|parenthesis|bracket)\b/gi, replacement: ')' },
    { pattern: /\bopen quote\b/gi, replacement: '"' },
    { pattern: /\bclose quote\b/gi, replacement: '"' },
    { pattern: /\bquote\b/gi, replacement: '"' },
]

/**
 * Convert spoken punctuation to actual characters.
 * "save the data period" → "save the data."
 */
export function convertSpokenPunctuation(text) {
    let result = text
    for (const { pattern, replacement } of SPOKEN_PUNCTUATION) {
        result = result.replace(pattern, replacement)
    }
    // Clean up space before punctuation
    result = result.replace(/\s+([.,;:!?)])/g, '$1')
    return result.trim()
}

/* ═══════════════════════════════════════════════════════════════
 *  ACTION VERBS — 100+ programming action verbs
 *  Used for run-on sentence splitting: when a second action verb
 *  appears in a sentence, it indicates a new instruction boundary.
 * ═══════════════════════════════════════════════════════════════ */

const ACTION_VERBS = /\b(get|fetch|show|display|create|make|build|save|store|delete|remove|send|update|set|add|sort|filter|find|load|read|write|push|pull|check|validate|toggle|reset|swap|return|throw|navigate|redirect|log|print|render|insert|append|modify|patch|increment|decrement|repeat|monitor|track|alert|notify|try|open|close|start|stop|enable|disable|hide|reveal|expand|collapse|merge|split|copy|clone|move|rename|search|query|connect|disconnect|subscribe|unsubscribe|publish|emit|broadcast|schedule|cancel|pause|resume|upload|download|import|submit|refresh|sync|clear|format|parse|convert|transform|encrypt|decrypt|hash|sign|verify|authorize|authenticate|register|login|logout|lock|unlock|archive|restore|backup|deploy|compile|execute|run|test|debug|configure|install|uninstall|mount|unmount|bind|unbind|attach|detach|assign|allocate|release|initialize|destroy|listen|watch|observe|trigger|dispatch|invoke|call|apply|map|reduce|iterate|enumerate|generate|calculate|compute|compare|count|measure|select|deselect|highlight|focus|blur|scroll|drag|drop|resize|rotate|scale|animate|render|paint|draw|erase|fill|stroke|crop|trim|validate|sanitize|escape|encode|decode|serialize|deserialize|compress|decompress|aggregate|group|join|concatenate|interpolate|replace|substitute|extract|inject|embed|wrap|unwrap|flatten|nest|paginate|limit|offset|cache|index|reindex|optimize|normalize|denormalize|batch|queue|dequeue|enqueue|pop|shift|unshift|splice|slice|chunk)(?:s|es|ed|ing)?\b/i

const CONJUNCTION_SPLITTERS = [
    /\band then\b/i,
    /\band also\b/i,
    /\bafter that\b/i,
    /\bthen\b/i,
    /\bnext\b/i,
    /\balso\b/i,
]

/**
 * Split run-on sentences into separate instructions.
 * "get the users name and then show it on the screen" → ["get the users name", "show it on the screen"]
 */
export function splitRunOnSentences(text) {
    let segments = [text]

    // Split on conjunction phrases first
    for (const conj of CONJUNCTION_SPLITTERS) {
        const newSegments = []
        for (const seg of segments) {
            const parts = seg.split(conj).map(s => s.trim()).filter(Boolean)
            newSegments.push(...parts)
        }
        segments = newSegments
    }

    // Within remaining segments, detect action verb boundaries
    // "get the name show it on screen" → ["get the name", "show it on screen"]
    const finalSegments = []
    for (const seg of segments) {
        const words = seg.split(/\s+/)
        let current = []
        let foundFirstVerb = false

        for (let i = 0; i < words.length; i++) {
            const isVerb = ACTION_VERBS.test(words[i])
            if (isVerb && foundFirstVerb && current.length >= 2) {
                // New action verb after we already have content → split
                finalSegments.push(current.join(' '))
                current = [words[i]]
            } else {
                if (isVerb) foundFirstVerb = true
                current.push(words[i])
            }
        }
        if (current.length > 0) finalSegments.push(current.join(' '))
    }

    return finalSegments.length > 0 ? finalSegments : [text]
}

/**
 * Strip filler words from transcribed text.
 */
export function stripFillers(text) {
    let result = text

    // Multi-word fillers first (greedy)
    for (const filler of FILLER_WORDS) {
        if (filler.includes(' ')) {
            const regex = new RegExp(`\\b${filler}\\b[,.]?\\s*`, 'gi')
            result = result.replace(regex, '')
        }
    }

    // Single-word fillers
    const words = result.split(/\s+/)
    const filtered = words.filter(w => !FILLER_WORDS.has(w.toLowerCase().replace(/[,.]$/, '')))
    result = filtered.join(' ').trim()

    // Clean up double spaces
    return result.replace(/\s{2,}/g, ' ').trim()
}

/* ── Correction Phrases ──────────────────────────────── */

const CORRECTION_TRIGGERS = [
    { pattern: /\bno,?\s+I\s+mean\b/i, type: 'replace_last' },
    { pattern: /\bactually,?\s+make\s+that\b/i, type: 'replace_last' },
    { pattern: /\bwait,?\s*/i, type: 'replace_last' },
    { pattern: /\bsorry,?\s*/i, type: 'replace_last' },
    { pattern: /\bI\s+meant?\b/i, type: 'replace_last' },
    { pattern: /\bscratch\s+that\b/i, type: 'undo_last' },
    { pattern: /\bnot\s+that,?\s*/i, type: 'replace_last' },
    { pattern: /\bcorrection:?\s*/i, type: 'replace_last' },
    { pattern: /\bno,?\s+wait\b/i, type: 'replace_last' },
]

/**
 * Process correction phrases in a transcription stream.
 * Returns the corrected array of lines (some may be removed or replaced).
 *
 * @param {string[]} lines - Array of transcribed lines (accumulated)
 * @param {string} newLine - The new line being added
 * @returns {{ lines: string[], correction: { type: string, original: string, fixed: string } | null }}
 */
export function processCorrection(lines, newLine) {
    for (const trigger of CORRECTION_TRIGGERS) {
        const match = newLine.match(trigger.pattern)
        if (match) {
            if (trigger.type === 'undo_last') {
                // Remove the last line entirely
                const removed = lines.length > 0 ? lines[lines.length - 1] : ''
                return {
                    lines: lines.slice(0, -1),
                    correction: { type: 'undo', original: removed, fixed: '(removed)' },
                }
            }

            if (trigger.type === 'replace_last') {
                // Replace the last line with the text after the correction trigger
                const replacement = newLine.slice(match.index + match[0].length).trim()
                if (replacement && lines.length > 0) {
                    const original = lines[lines.length - 1]
                    const newLines = [...lines.slice(0, -1), replacement]
                    return {
                        lines: newLines,
                        correction: { type: 'replace', original, fixed: replacement },
                    }
                }
            }
        }
    }

    // No correction — add the line normally
    return { lines: [...lines, newLine], correction: null }
}

/* ── Structural Cue Parsing ──────────────────────────── */

const BLOCK_START_CUES = [
    { pattern: /^when\b/i, type: 'when_block' },
    { pattern: /^if\b/i, type: 'if_block' },
    { pattern: /^for\s+each\b/i, type: 'foreach_block' },
    { pattern: /^for\s+every\b/i, type: 'foreach_block' },
    { pattern: /^repeat\b/i, type: 'repeat_block' },
    { pattern: /^while\b/i, type: 'while_block' },
    { pattern: /^inside\s+that\b/i, type: 'nested_block' },
    { pattern: /^in\s+that\s+case\b/i, type: 'nested_block' },
]

const BLOCK_END_CUES = [
    /^end\b/i,
    /^that'?s\s+it\b/i,
    /^done\b/i,
    /^finished\b/i,
    /^stop\b/i,
    /^close\b/i,
]

const SEQUENTIAL_CUES = [
    /^then\b/i,
    /^next\b/i,
    /^after\s+that\b/i,
    /^once\s+that'?s?\s+done\b/i,
    /^and\s+then\b/i,
]

/**
 * Parse structural cues from a line.
 *
 * @param {string} line - A transcribed line
 * @returns {{ type: string, text: string, indent: number } | null}
 */
export function parseStructuralCue(line) {
    const trimmed = line.trim()

    // Check for block-ending cues
    for (const cue of BLOCK_END_CUES) {
        if (cue.test(trimmed)) {
            return { type: 'block_end', text: '', indent: -1 }
        }
    }

    // Check for block-starting cues
    for (const cue of BLOCK_START_CUES) {
        if (cue.pattern.test(trimmed)) {
            return { type: cue.type, text: trimmed, indent: 1 }
        }
    }

    // Check for sequential cues (remove the cue word, keep the instruction)
    for (const cue of SEQUENTIAL_CUES) {
        const match = trimmed.match(cue)
        if (match) {
            const instruction = trimmed.slice(match[0].length).trim()
            return { type: 'sequential', text: instruction || trimmed, indent: 0 }
        }
    }

    return null
}

/* ── Variable Naming ─────────────────────────────────── */

const NAMING_PATTERNS = [
    /call\s+it\s+(.+)/i,
    /name\s+it\s+(.+)/i,
    /and\s+call\s+it\s+(.+)/i,
    /store\s+(?:it\s+)?(?:as|in)\s+(.+)/i,
    /save\s+(?:it\s+)?(?:as|in)\s+(.+)/i,
    /put\s+(?:it\s+)?(?:in(?:to)?)\s+(.+)/i,
]

/**
 * Extract a variable name from spoken naming instructions.
 * "call it user count" → "userCount"
 * "name it total price" → "totalPrice"
 *
 * @param {string} text - Transcribed text
 * @returns {{ name: string, camelCase: string, remained: string } | null}
 */
export function extractVariableName(text) {
    for (const pattern of NAMING_PATTERNS) {
        const match = text.match(pattern)
        if (match) {
            const rawName = match[1].trim()
                .replace(/[^a-zA-Z0-9\s]/g, '') // Remove special chars
                .trim()

            // Convert to camelCase
            const words = rawName.split(/\s+/)
            const camelCase = words[0].toLowerCase() +
                words.slice(1).map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join('')

            return {
                name: rawName,
                camelCase,
                remained: text.slice(0, match.index).trim(),
            }
        }
    }
    return null
}

/* ── Number Word Conversion ──────────────────────────── */

const NUMBER_WORDS = {
    'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4,
    'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9,
    'ten': 10, 'eleven': 11, 'twelve': 12, 'thirteen': 13,
    'fourteen': 14, 'fifteen': 15, 'sixteen': 16, 'seventeen': 17,
    'eighteen': 18, 'nineteen': 19, 'twenty': 20,
    'thirty': 30, 'forty': 40, 'fifty': 50, 'sixty': 60,
    'seventy': 70, 'eighty': 80, 'ninety': 90,
    'a hundred': 100, 'hundred': 100,
    'a thousand': 1000, 'thousand': 1000,
    'a million': 1000000, 'million': 1000000,
    'a couple': 2, 'a few': 3, 'several': 5,
    'a dozen': 12, 'half a dozen': 6,
}

/**
 * Convert number words to digits.
 * "five" → "5", "a hundred" → "100", "twenty three" → "23"
 *
 * @param {string} text - Input text
 * @returns {string} Text with number words replaced by digits
 */
export function convertNumberWords(text) {
    let result = text

    // Multi-word numbers first ("twenty three" → "23")
    // Handle compound numbers like "twenty three", "fifty five"
    const tens = ['twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety']
    const ones = ['one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine']

    for (const t of tens) {
        for (const o of ones) {
            const compound = `${t} ${o}`
            const value = NUMBER_WORDS[t] + NUMBER_WORDS[o]
            result = result.replace(new RegExp(`\\b${compound}\\b`, 'gi'), String(value))
        }
    }

    // Multi-word number phrases
    for (const [phrase, value] of Object.entries(NUMBER_WORDS)) {
        if (phrase.includes(' ')) {
            result = result.replace(new RegExp(`\\b${phrase}\\b`, 'gi'), String(value))
        }
    }

    // Single number words
    for (const [word, value] of Object.entries(NUMBER_WORDS)) {
        if (!word.includes(' ')) {
            result = result.replace(new RegExp(`\\b${word}\\b`, 'gi'), String(value))
        }
    }

    return result
}

/* ── Pause Detection ─────────────────────────────────── */

/**
 * Detect if a pause boundary should create a new logical block.
 * In speech, a long pause (>2 seconds) typically indicates a new thought.
 *
 * @param {number} pauseDurationMs - Duration of silence in milliseconds
 * @param {number} [threshold=2000] - Minimum pause to trigger a block break
 * @returns {boolean}
 */
export function isPauseBlockBreak(pauseDurationMs, threshold = 2000) {
    return pauseDurationMs >= threshold
}

/* ── Full Transcription Pipeline ─────────────────────── */

/**
 * Process a raw transcription line through the voice cleanup pipeline.
 * Order: strip fillers → convert numbers → extract variable names → structural cues
 *
 * @param {string} rawLine - Raw transcribed text from speech engine
 * @returns {{ text: string, structuralCue: object|null, variableName: object|null, corrections: string[] }}
 */
export function processTranscription(rawLine) {
    const corrections = []

    // Step 1: Collapse repeated/stuttered words
    let processed = collapseRepeats(rawLine.trim())
    if (processed !== rawLine.trim()) {
        corrections.push(`Stutter collapse: "${rawLine.trim()}" → "${processed}"`)
    }

    // Step 2: Convert spoken punctuation
    const withPunct = convertSpokenPunctuation(processed)
    if (withPunct !== processed) {
        corrections.push(`Spoken punctuation: "${processed}" → "${withPunct}"`)
        processed = withPunct
    }

    // Step 3: Strip filler words
    const withoutFillers = stripFillers(processed)
    if (withoutFillers !== processed) {
        corrections.push(`Stripped fillers: "${processed}" → "${withoutFillers}"`)
        processed = withoutFillers
    }

    // Step 4: Resolve homophones
    const withHomophones = resolveHomophones(processed)
    if (withHomophones !== processed) {
        corrections.push(`Homophone fix: "${processed}" → "${withHomophones}"`)
        processed = withHomophones
    }

    // Step 5: Convert number words to digits
    const withNumbers = convertNumberWords(processed)
    if (withNumbers !== processed) {
        corrections.push(`Number conversion: "${processed}" → "${withNumbers}"`)
        processed = withNumbers
    }

    // Step 6: Check for variable naming
    const varName = extractVariableName(processed)

    // Step 7: Parse structural cues
    const structuralCue = parseStructuralCue(processed)

    return {
        text: processed,
        structuralCue,
        variableName: varName,
        corrections,
    }
}

/**
 * Convert a stream of voice transcription lines into a .lume file.
 *
 * @param {string[]} rawLines - Array of transcribed lines from speech engine
 * @param {object} [options] - { mode: 'english'|'natural', pauseThreshold: number }
 * @returns {{ source: string, corrections: Array<{ line: number, message: string }> }}
 */
export function transcriptionToLume(rawLines, options = {}) {
    const mode = options.mode || 'natural'
    const corrections = []

    // ── Pass 0: Split run-on sentences into separate lines ──
    const expandedLines = []
    for (const raw of rawLines) {
        const trimmed = raw.trim()
        if (!trimmed) continue
        const split = splitRunOnSentences(trimmed)
        if (split.length > 1) {
            corrections.push({ line: expandedLines.length + 1, message: `[voice-split] Run-on split into ${split.length} instructions` })
        }
        expandedLines.push(...split)
    }

    // ── Pass 1: Accumulate lines with corrections applied ──
    let accumulatedLines = []

    for (let i = 0; i < expandedLines.length; i++) {
        const rawLine = expandedLines[i].trim()
        if (!rawLine) continue

        // Check for corrections FIRST
        const correctionResult = processCorrection(accumulatedLines, rawLine)
        if (correctionResult.correction) {
            corrections.push({ line: i + 1, message: `[voice-correct] ${correctionResult.correction.type}: "${correctionResult.correction.original}" → "${correctionResult.correction.fixed}"` })
            accumulatedLines = correctionResult.lines
            continue
        }
        accumulatedLines = correctionResult.lines
    }

    // ── Pass 2: Process accumulated lines through pipeline and build output ──
    const outputLines = [`mode: ${mode}`]
    let indentLevel = 0

    for (let i = 0; i < accumulatedLines.length; i++) {
        const line = accumulatedLines[i]

        // Process through pipeline (strip fillers, convert numbers, etc.)
        const processed = processTranscription(line)

        if (processed.corrections.length > 0) {
            corrections.push(...processed.corrections.map(c => ({ line: i + 1, message: `[voice-clean] ${c}` })))
        }

        // Handle structural cues
        if (processed.structuralCue) {
            if (processed.structuralCue.type === 'block_end') {
                indentLevel = Math.max(0, indentLevel - 1)
                continue
            }
            if (processed.structuralCue.indent > 0) {
                outputLines.push('  '.repeat(indentLevel) + processed.text)
                indentLevel++
                continue
            }
        }

        outputLines.push('  '.repeat(indentLevel) + processed.text)
    }

    return {
        source: outputLines.join('\n') + '\n',
        corrections,
    }
}
