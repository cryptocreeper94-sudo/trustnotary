/**
 * PROXY REDIRECT
 * This module has been securely extracted to D:\Lume-V to protect provisional patent IP.
 * This proxy ensures that all dependent apps (HappyEats, WLOP, etc.) continue to import
 * the Lume-V governor seamlessly without breaking.
 */
module.exports = require('D:\\Lume-V\\src\\index.js');
