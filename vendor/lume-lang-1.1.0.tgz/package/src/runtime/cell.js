/**
 * ═══════════════════════════════════════════════════════════
 *  SYNTHETIC ORGANISM RUNTIME — CELL ABSTRACTION
 *  §2 Layer 3, §4 SOR-001, SOR-002
 *
 *  A Cell is the fundamental unit of execution in the SOR.
 *  Every process is a cell with a biological lifecycle:
 *
 *  State Machine:
 *    NASCENT → ACTIVE → QUIESCENT → APOPTOSIS → DEAD
 *              ↕                       ↑
 *           STRESSED → HEALING ────────┘
 *
 *  Each cell has:
 *    - Unique ID (UUID v7)
 *    - Memory isolation (private state)
 *    - Fault containment (errors don't propagate)
 *    - Signal interface (send/receive via Signal Bus)
 *    - Resource bounds (enforced by Homeostasis Engine)
 *
 *  By DarkWave Studios LLC — DarkWaveStudios.io
 *  Copyright 2026. Protected by TrustShield.tech
 * ═══════════════════════════════════════════════════════════
 */

import crypto from 'crypto'

export const CELL_STATES = {
    NASCENT: 'NASCENT',           // Created but not yet activated
    ACTIVE: 'ACTIVE',             // Running normally
    QUIESCENT: 'QUIESCENT',       // Idle, waiting for signals
    STRESSED: 'STRESSED',         // Under resource pressure
    HEALING: 'HEALING',           // Recovering from error
    APOPTOSIS: 'APOPTOSIS',       // Controlled shutdown
    DEAD: 'DEAD',                 // Terminated
}

// Valid state transitions
const TRANSITIONS = {
    [CELL_STATES.NASCENT]: [CELL_STATES.ACTIVE, CELL_STATES.DEAD],
    [CELL_STATES.ACTIVE]: [CELL_STATES.QUIESCENT, CELL_STATES.STRESSED, CELL_STATES.APOPTOSIS],
    [CELL_STATES.QUIESCENT]: [CELL_STATES.ACTIVE, CELL_STATES.APOPTOSIS],
    [CELL_STATES.STRESSED]: [CELL_STATES.HEALING, CELL_STATES.APOPTOSIS],
    [CELL_STATES.HEALING]: [CELL_STATES.ACTIVE, CELL_STATES.APOPTOSIS],
    [CELL_STATES.APOPTOSIS]: [CELL_STATES.DEAD],
    [CELL_STATES.DEAD]: [],
}

/**
 * A single Cell in the Synthetic Organism Runtime.
 */
export class Cell {
    constructor(config = {}) {
        this.id = config.id || crypto.randomUUID()
        this.name = config.name || `cell-${this.id.slice(0, 8)}`
        this.state = CELL_STATES.NASCENT
        this.priority = config.priority || 0
        this.createdAt = Date.now()
        this.lastStateChange = Date.now()

        // Private isolated state
        this._state = new Map()
        this._stateSnapshots = []
        this._maxSnapshots = config.maxSnapshots || 10

        // Resource tracking
        this.resources = {
            memory: 0,
            cpu: 0,
            signalsSent: 0,
            signalsReceived: 0,
            errors: 0,
        }

        // Resource bounds (enforced by Homeostasis Engine)
        this.bounds = config.bounds || {
            maxMemory: 256 * 1024 * 1024,   // 256MB
            maxCpu: 1.0,
            maxSignals: 10000,
            maxErrors: 100,
        }

        // Signal handler
        this._signalHandler = config.onSignal || null

        // Execution function
        this._executeFn = config.execute || null

        // Lifecycle hooks
        this._hooks = {
            onActivate: config.onActivate || null,
            onDeactivate: config.onDeactivate || null,
            onError: config.onError || null,
            onDeath: config.onDeath || null,
        }

        // State history for audit
        this.stateHistory = [{ state: CELL_STATES.NASCENT, timestamp: Date.now() }]
    }

    /**
     * Transition to a new state.
     * Validates against the state machine — only valid transitions are allowed.
     */
    transition(newState) {
        const valid = TRANSITIONS[this.state]
        if (!valid || !valid.includes(newState)) {
            throw new Error(
                `Invalid state transition: ${this.state} → ${newState}. ` +
                `Valid transitions from ${this.state}: [${valid?.join(', ') || 'none'}]`
            )
        }

        const oldState = this.state
        this.state = newState
        this.lastStateChange = Date.now()
        this.stateHistory.push({
            from: oldState,
            to: newState,
            timestamp: Date.now(),
        })

        // Lifecycle hooks
        if (newState === CELL_STATES.ACTIVE && this._hooks.onActivate) {
            try { this._hooks.onActivate(this) } catch { }
        }
        if (newState === CELL_STATES.QUIESCENT && this._hooks.onDeactivate) {
            try { this._hooks.onDeactivate(this) } catch { }
        }
        if (newState === CELL_STATES.DEAD && this._hooks.onDeath) {
            try { this._hooks.onDeath(this) } catch { }
        }

        return { from: oldState, to: newState }
    }

    /**
     * Activate the cell (NASCENT → ACTIVE or QUIESCENT → ACTIVE).
     */
    activate() {
        if (this.state === CELL_STATES.NASCENT || this.state === CELL_STATES.QUIESCENT) {
            return this.transition(CELL_STATES.ACTIVE)
        }
        throw new Error(`Cannot activate cell in state: ${this.state}`)
    }

    /**
     * Execute the cell's function.
     */
    async execute(...args) {
        if (this.state !== CELL_STATES.ACTIVE) {
            throw new Error(`Cannot execute cell in state: ${this.state} (must be ACTIVE)`)
        }

        if (!this._executeFn) {
            throw new Error('No execution function defined for this cell')
        }

        try {
            const result = await this._executeFn(this, ...args)
            return result
        } catch (err) {
            this.resources.errors++
            this.transition(CELL_STATES.STRESSED)

            if (this._hooks.onError) {
                try { this._hooks.onError(this, err) } catch { }
            }

            throw err
        }
    }

    /**
     * Receive a signal from the Signal Bus.
     */
    receiveSignal(signal) {
        this.resources.signalsReceived++

        if (this._signalHandler) {
            try {
                return this._signalHandler(this, signal)
            } catch (err) {
                this.resources.errors++
                if (this.state === CELL_STATES.ACTIVE) {
                    this.transition(CELL_STATES.STRESSED)
                }
                throw err
            }
        }
    }

    // ── State Management (Memory Isolation) ──

    /**
     * Set a value in the cell's isolated state.
     */
    set(key, value) {
        this._state.set(key, value)
    }

    /**
     * Get a value from the cell's isolated state.
     */
    get(key) {
        return this._state.get(key)
    }

    /**
     * Get all state as a plain object.
     */
    getState() {
        return Object.fromEntries(this._state)
    }

    /**
     * Take a state snapshot (for rollback).
     */
    snapshot() {
        const snap = {
            id: crypto.randomUUID(),
            timestamp: Date.now(),
            state: new Map(this._state),
            cellState: this.state,
            resources: { ...this.resources },
        }

        this._stateSnapshots.push(snap)

        // Trim old snapshots
        while (this._stateSnapshots.length > this._maxSnapshots) {
            this._stateSnapshots.shift()
        }

        return snap.id
    }

    /**
     * Rollback to a specific snapshot.
     */
    rollback(snapshotId = null) {
        const snap = snapshotId
            ? this._stateSnapshots.find(s => s.id === snapshotId)
            : this._stateSnapshots[this._stateSnapshots.length - 1]

        if (!snap) {
            throw new Error(`Snapshot ${snapshotId || 'latest'} not found`)
        }

        this._state = new Map(snap.state)
        this.resources = { ...snap.resources }

        // If we were stressed/healing, go back to active
        if (this.state === CELL_STATES.STRESSED || this.state === CELL_STATES.HEALING) {
            this.transition(CELL_STATES.HEALING)
            this.transition(CELL_STATES.ACTIVE)
        }

        return snap
    }

    /**
     * Initiate controlled shutdown (apoptosis).
     */
    shutdown(reason = 'normal') {
        if (this.state === CELL_STATES.DEAD) return

        // Snapshot before death
        this.snapshot()

        // Transition through apoptosis to death
        if (this.state !== CELL_STATES.APOPTOSIS) {
            // Find path to APOPTOSIS
            if (TRANSITIONS[this.state]?.includes(CELL_STATES.APOPTOSIS)) {
                this.transition(CELL_STATES.APOPTOSIS)
            } else {
                // Force — mark as dead directly (emergency shutdown)
                this.state = CELL_STATES.DEAD
                this.stateHistory.push({
                    from: this.state,
                    to: CELL_STATES.DEAD,
                    timestamp: Date.now(),
                    reason: `Emergency shutdown: ${reason}`,
                })
                return
            }
        }

        this.transition(CELL_STATES.DEAD)
    }

    /**
     * Check if the cell is alive.
     */
    isAlive() {
        return this.state !== CELL_STATES.DEAD
    }

    /**
     * Get cell info for monitoring.
     */
    info() {
        return {
            id: this.id,
            name: this.name,
            state: this.state,
            priority: this.priority,
            createdAt: this.createdAt,
            uptime: Date.now() - this.createdAt,
            lastStateChange: this.lastStateChange,
            resources: { ...this.resources },
            bounds: { ...this.bounds },
            stateSize: this._state.size,
            snapshots: this._stateSnapshots.length,
            transitions: this.stateHistory.length,
        }
    }
}

/**
 * Cell Manager — manages the lifecycle of all cells in the SOR.
 */
export class CellManager {
    constructor(config = {}) {
        this.cells = new Map()  // cell_id → Cell
        this.maxCells = config.maxCells || 10000
        this._onCellDeath = config.onCellDeath || null
    }

    /**
     * Create and register a new cell.
     */
    create(config = {}) {
        if (this.cells.size >= this.maxCells) {
            throw new Error(`Cell limit reached (${this.maxCells})`)
        }

        const cell = new Cell({
            ...config,
            onDeath: (c) => {
                if (this._onCellDeath) this._onCellDeath(c)
                if (config.onDeath) config.onDeath(c)
            },
        })

        this.cells.set(cell.id, cell)
        return cell
    }

    /**
     * Get a cell by ID.
     */
    get(cellId) {
        return this.cells.get(cellId)
    }

    /**
     * Activate a cell.
     */
    activate(cellId) {
        const cell = this.cells.get(cellId)
        if (!cell) throw new Error(`Cell ${cellId} not found`)
        return cell.activate()
    }

    /**
     * Shutdown a cell.
     */
    shutdown(cellId, reason = 'manager_shutdown') {
        const cell = this.cells.get(cellId)
        if (!cell) throw new Error(`Cell ${cellId} not found`)
        cell.shutdown(reason)
        return cell.info()
    }

    /**
     * Get all cells matching a state.
     */
    getByState(state) {
        return Array.from(this.cells.values()).filter(c => c.state === state)
    }

    /**
     * Get all active cells sorted by priority then UUID for deterministic scheduling.
     * Implements D-SOR-01: CELL SCHEDULING DETERMINISM
     */
    getScheduleOrder() {
        return Array.from(this.cells.values())
            .filter(c => c.state === CELL_STATES.ACTIVE)
            .sort((a, b) => {
                if (a.priority !== b.priority) return a.priority - b.priority
                return a.id.localeCompare(b.id)
            })
    }

    /**
     * Shutdown all cells.
     */
    shutdownAll(reason = 'manager_shutdown_all') {
        for (const cell of this.cells.values()) {
            if (cell.isAlive()) {
                try { cell.shutdown(reason) } catch { }
            }
        }
    }

    /**
     * Remove dead cells.
     */
    gc() {
        const removed = []
        for (const [id, cell] of this.cells) {
            if (cell.state === CELL_STATES.DEAD) {
                this.cells.delete(id)
                removed.push(id)
            }
        }
        return removed
    }

    /**
     * Get manager statistics.
     */
    stats() {
        const byState = {}
        for (const cell of this.cells.values()) {
            byState[cell.state] = (byState[cell.state] || 0) + 1
        }
        return {
            totalCells: this.cells.size,
            maxCells: this.maxCells,
            byState,
            aliveCells: Array.from(this.cells.values()).filter(c => c.isAlive()).length,
        }
    }
}

export const cellManager = new CellManager()
export default cellManager
