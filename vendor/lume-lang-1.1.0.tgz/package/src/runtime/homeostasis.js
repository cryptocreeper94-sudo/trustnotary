/**
 * ═══════════════════════════════════════════════════════════
 *  SYNTHETIC ORGANISM RUNTIME — HOMEOSTASIS ENGINE
 *  §2 Layer 3, §4 SOR-005, SOR-006, SOR-007
 *
 *  The Homeostasis Engine maintains system stability by:
 *    - Enforcing resource bounds on cells
 *    - Detecting and responding to resource pressure
 *    - Triggering rollbacks when limits are exceeded
 *    - Thermal regulation (dynamic load balancing)
 *    - Adaptation limits — bounded, observable, reversible
 *
 *  D-SOR-03: threshold = deployment_default × 0.8 (fixed)
 *  D-SOR-04: Rollback scope = minimum affected cells
 *
 *  By DarkWave Studios LLC — DarkWaveStudios.io
 *  Copyright 2026. Protected by TrustShield.tech
 * ═══════════════════════════════════════════════════════════
 */

export const RESOURCE_TYPES = {
    MEMORY: 'memory',
    CPU: 'cpu',
    SIGNALS: 'signals',
    ERRORS: 'errors',
    CONNECTIONS: 'connections',
    DURATION: 'duration',
}

export const THERMAL_STATES = {
    COLD: 'COLD',           // Under-utilized
    NOMINAL: 'NOMINAL',     // Normal operating range
    WARM: 'WARM',           // Approaching limits
    HOT: 'HOT',             // At limits, shedding load
    CRITICAL: 'CRITICAL',   // Over limits, triggering rollback
}

const SAFETY_FACTOR = 0.8   // D-SOR-03: Fixed, not adaptive

/**
 * Resource threshold configuration.
 */
export class ResourceThreshold {
    constructor(resourceType, config = {}) {
        this.type = resourceType
        this.deploymentDefault = config.deploymentDefault || this._defaultForType(resourceType)
        this.configuredThreshold = config.threshold || null
        this.safetyFactor = SAFETY_FACTOR

        // Effective threshold: configured or computed
        this.effectiveThreshold = this.configuredThreshold
            || (this.deploymentDefault * this.safetyFactor)

        // Warning threshold (80% of effective)
        this.warningThreshold = this.effectiveThreshold * 0.8
    }

    /**
     * Check a value against this threshold.
     * @returns {{ state: string, ratio: number, exceeded: boolean }}
     */
    check(currentValue) {
        const ratio = currentValue / this.effectiveThreshold

        let state
        if (ratio < 0.2) state = THERMAL_STATES.COLD
        else if (ratio < 0.6) state = THERMAL_STATES.NOMINAL
        else if (ratio < 0.8) state = THERMAL_STATES.WARM
        else if (ratio < 1.0) state = THERMAL_STATES.HOT
        else state = THERMAL_STATES.CRITICAL

        return {
            type: this.type,
            currentValue,
            threshold: this.effectiveThreshold,
            warningThreshold: this.warningThreshold,
            ratio: Math.round(ratio * 1000) / 1000,
            state,
            exceeded: ratio >= 1.0,
            warning: ratio >= 0.8,
        }
    }

    _defaultForType(type) {
        switch (type) {
            case RESOURCE_TYPES.MEMORY: return 256 * 1024 * 1024    // 256MB
            case RESOURCE_TYPES.CPU: return 1.0                       // 1 core
            case RESOURCE_TYPES.SIGNALS: return 10000                 // 10K signals
            case RESOURCE_TYPES.ERRORS: return 100                    // 100 errors
            case RESOURCE_TYPES.CONNECTIONS: return 100                // 100 connections
            case RESOURCE_TYPES.DURATION: return 300000                // 5 minutes
            default: return 1000
        }
    }
}

/**
 * Homeostasis Engine — maintains SOR stability.
 */
export class HomeostasisEngine {
    constructor(config = {}) {
        this.thresholds = new Map()
        this.cellMetrics = new Map()      // cell_id → { resource_type → current_value }
        this.systemThermalState = THERMAL_STATES.COLD
        this.rollbackLog = []
        this.adaptationLog = []
        this.checkInterval = config.checkInterval || 5000  // ms
        this._interval = null

        // Callbacks
        this.onWarning = config.onWarning || null
        this.onCritical = config.onCritical || null
        this.onRollbackTriggered = config.onRollbackTriggered || null

        // Initialize default thresholds
        for (const type of Object.values(RESOURCE_TYPES)) {
            this.thresholds.set(type, new ResourceThreshold(type, config.thresholds?.[type]))
        }
    }

    /**
     * Register a cell for monitoring.
     */
    registerCell(cellId) {
        this.cellMetrics.set(cellId, {
            [RESOURCE_TYPES.MEMORY]: 0,
            [RESOURCE_TYPES.CPU]: 0,
            [RESOURCE_TYPES.SIGNALS]: 0,
            [RESOURCE_TYPES.ERRORS]: 0,
            [RESOURCE_TYPES.CONNECTIONS]: 0,
            [RESOURCE_TYPES.DURATION]: 0,
        })
    }

    /**
     * Unregister a cell.
     */
    unregisterCell(cellId) {
        this.cellMetrics.delete(cellId)
    }

    /**
     * Update a cell's resource metric.
     */
    updateMetric(cellId, resourceType, value) {
        const metrics = this.cellMetrics.get(cellId)
        if (!metrics) return

        metrics[resourceType] = value
    }

    /**
     * Increment a cell's resource metric.
     */
    incrementMetric(cellId, resourceType, delta = 1) {
        const metrics = this.cellMetrics.get(cellId)
        if (!metrics) return

        metrics[resourceType] = (metrics[resourceType] || 0) + delta
    }

    /**
     * Check a specific cell against all thresholds.
     * @returns {{ cellId: string, checks: Object[], thermalState: string, actions: string[] }}
     */
    checkCell(cellId) {
        const metrics = this.cellMetrics.get(cellId)
        if (!metrics) return { cellId, checks: [], thermalState: THERMAL_STATES.COLD, actions: [] }

        const checks = []
        const actions = []
        let worstState = THERMAL_STATES.COLD
        const stateOrder = [THERMAL_STATES.COLD, THERMAL_STATES.NOMINAL, THERMAL_STATES.WARM, THERMAL_STATES.HOT, THERMAL_STATES.CRITICAL]

        for (const [type, threshold] of this.thresholds) {
            const value = metrics[type] || 0
            const check = threshold.check(value)
            checks.push(check)

            if (stateOrder.indexOf(check.state) > stateOrder.indexOf(worstState)) {
                worstState = check.state
            }

            // Determine actions
            if (check.exceeded) {
                actions.push(`ROLLBACK: ${type} exceeded (${check.ratio}x threshold)`)
            } else if (check.warning) {
                actions.push(`WARNING: ${type} at ${(check.ratio * 100).toFixed(0)}% of threshold`)
            }
        }

        return { cellId, checks, thermalState: worstState, actions }
    }

    /**
     * Run a full system health check across all cells.
     * @returns {{ thermalState: string, cellReports: Object[], rollbacks: string[], warnings: string[] }}
     */
    systemCheck() {
        const cellReports = []
        const rollbacks = []
        const warnings = []
        let worstSystemState = THERMAL_STATES.COLD
        const stateOrder = [THERMAL_STATES.COLD, THERMAL_STATES.NOMINAL, THERMAL_STATES.WARM, THERMAL_STATES.HOT, THERMAL_STATES.CRITICAL]

        for (const cellId of this.cellMetrics.keys()) {
            const report = this.checkCell(cellId)
            cellReports.push(report)

            if (stateOrder.indexOf(report.thermalState) > stateOrder.indexOf(worstSystemState)) {
                worstSystemState = report.thermalState
            }

            // Collect actions
            for (const action of report.actions) {
                if (action.startsWith('ROLLBACK')) {
                    rollbacks.push(`${cellId}: ${action}`)
                } else if (action.startsWith('WARNING')) {
                    warnings.push(`${cellId}: ${action}`)
                }
            }
        }

        this.systemThermalState = worstSystemState

        // Fire callbacks
        if (warnings.length > 0 && this.onWarning) {
            this.onWarning(warnings)
        }
        if (rollbacks.length > 0 && this.onCritical) {
            this.onCritical(rollbacks)
        }

        return {
            thermalState: worstSystemState,
            cellCount: this.cellMetrics.size,
            cellReports,
            rollbacks,
            warnings,
            timestamp: new Date().toISOString(),
        }
    }

    /**
     * Trigger a rollback for a cell.
     * D-SOR-04: Minimum set of affected cells.
     *
     * @param {string} cellId - The triggering cell
     * @param {Object} propagationGraph - From Signal Bus
     * @param {Function} rollbackFn - Function to call for each affected cell
     * @returns {{ triggeredBy: string, affectedCells: string[], timestamp: string }}
     */
    triggerRollback(cellId, propagationGraph, rollbackFn) {
        // BFS to find minimum affected set (D-SOR-04)
        const affected = new Set()
        const queue = [cellId]
        affected.add(cellId)

        while (queue.length > 0) {
            const current = queue.shift()
            const neighbors = propagationGraph[current] || []
            for (const neighbor of neighbors) {
                if (!affected.has(neighbor)) {
                    affected.add(neighbor)
                    queue.push(neighbor)
                }
            }
        }

        // Execute rollback for each affected cell
        const results = []
        for (const id of affected) {
            try {
                if (rollbackFn) rollbackFn(id)
                results.push({ cellId: id, status: 'rolled_back' })
            } catch (err) {
                results.push({ cellId: id, status: 'rollback_failed', error: err.message })
            }
        }

        const entry = {
            triggeredBy: cellId,
            affectedCells: [...affected],
            totalAffected: affected.size,
            results,
            timestamp: new Date().toISOString(),
        }

        this.rollbackLog.push(entry)

        if (this.onRollbackTriggered) {
            this.onRollbackTriggered(entry)
        }

        return entry
    }

    /**
     * Start automatic monitoring daemon.
     */
    startDaemon() {
        if (this._interval) return

        this._interval = setInterval(() => {
            this.systemCheck()
        }, this.checkInterval)

        if (this._interval.unref) this._interval.unref()
    }

    /**
     * Stop the daemon.
     */
    stopDaemon() {
        if (this._interval) {
            clearInterval(this._interval)
            this._interval = null
        }
    }

    /**
     * Get engine statistics.
     */
    stats() {
        return {
            systemThermalState: this.systemThermalState,
            monitoredCells: this.cellMetrics.size,
            thresholds: Object.fromEntries(
                Array.from(this.thresholds.entries()).map(([type, t]) => [
                    type,
                    { effective: t.effectiveThreshold, warning: t.warningThreshold, safetyFactor: t.safetyFactor },
                ])
            ),
            totalRollbacks: this.rollbackLog.length,
            totalAdaptations: this.adaptationLog.length,
            daemonRunning: !!this._interval,
        }
    }
}

export const homeostasis = new HomeostasisEngine()
export default homeostasis
