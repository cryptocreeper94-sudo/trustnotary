/**
 * ═══════════════════════════════════════════════════════════
 *  SYNTHETIC ORGANISM RUNTIME — SIGNAL BUS
 *  §2 Layer 3, §4 SOR-003, SOR-004
 *
 *  The Signal Bus handles all inter-cell communication:
 *    - Point-to-point messaging
 *    - Broadcast signaling
 *    - Event propagation
 *    - Priority scheduling
 *    - Timestamp-ordered delivery (D-SOR-02)
 *
 *  Determinism Guarantees:
 *    - Signals delivered in timestamp order
 *    - Ties broken by sender cell_id (lexicographic)
 *    - Signals never reordered for performance
 *
 *  By DarkWave Studios LLC — DarkWaveStudios.io
 *  Copyright 2026. Protected by TrustShield.tech
 * ═══════════════════════════════════════════════════════════
 */

import crypto from 'crypto'

export const SIGNAL_TYPES = {
    STATE_UPDATE: 'STATE_UPDATE',
    REQUEST: 'REQUEST',
    RESPONSE: 'RESPONSE',
    EVENT: 'EVENT',
    BROADCAST: 'BROADCAST',
    HEARTBEAT: 'HEARTBEAT',
    ERROR: 'ERROR',
    SHUTDOWN: 'SHUTDOWN',
}

/**
 * A single Signal on the bus.
 */
export class Signal {
    constructor(config) {
        this.id = config.id || crypto.randomUUID()
        this.type = config.type || SIGNAL_TYPES.EVENT
        this.senderId = config.senderId
        this.recipientId = config.recipientId || null  // null = broadcast
        this.payload = config.payload || {}
        this.priority = config.priority || 0
        this.timestamp = config.timestamp || new Date().toISOString()
        this.correlationId = config.correlationId || null  // For request-response pairing
        this.ttl = config.ttl || 60000  // 60 seconds default TTL
        this.delivered = false
        this.deliveredAt = null
    }

    /**
     * Check if the signal has expired.
     */
    isExpired() {
        return Date.now() - new Date(this.timestamp).getTime() > this.ttl
    }

    /**
     * Mark as delivered.
     */
    markDelivered() {
        this.delivered = true
        this.deliveredAt = new Date().toISOString()
    }

    /**
     * Serialize to JSON.
     */
    toJSON() {
        return {
            id: this.id,
            type: this.type,
            senderId: this.senderId,
            recipientId: this.recipientId,
            payload: this.payload,
            priority: this.priority,
            timestamp: this.timestamp,
            correlationId: this.correlationId,
            delivered: this.delivered,
            deliveredAt: this.deliveredAt,
        }
    }
}

/**
 * Signal Bus — deterministic inter-cell messaging system.
 */
export class SignalBus {
    constructor(config = {}) {
        this.queue = []              // Pending signals
        this.delivered = []          // Delivered signal log
        this.subscribers = new Map() // cell_id → callback
        this.topicSubscribers = new Map() // topic → Set<cell_id>
        this.maxQueueSize = config.maxQueueSize || 100000
        this.maxDeliveredLog = config.maxDeliveredLog || 10000
        this.propagationGraph = {}   // cell_id → [cell_ids it signals to]

        // Stats
        this._totalSent = 0
        this._totalDelivered = 0
        this._totalDropped = 0
        this._totalBroadcasts = 0
    }

    /**
     * Subscribe a cell to receive signals.
     * @param {string} cellId - The cell's ID
     * @param {Function} handler - Signal handler: (signal) => void
     */
    subscribe(cellId, handler) {
        this.subscribers.set(cellId, handler)
    }

    /**
     * Unsubscribe a cell.
     */
    unsubscribe(cellId) {
        this.subscribers.delete(cellId)
        // Remove from all topics
        for (const [, subs] of this.topicSubscribers) {
            subs.delete(cellId)
        }
    }

    /**
     * Subscribe a cell to a specific topic.
     */
    subscribeTopic(cellId, topic) {
        if (!this.topicSubscribers.has(topic)) {
            this.topicSubscribers.set(topic, new Set())
        }
        this.topicSubscribers.get(topic).add(cellId)
    }

    /**
     * Send a signal.
     * @param {Object} config - Signal configuration
     * @returns {Signal} The created signal
     */
    send(config) {
        const signal = config instanceof Signal ? config : new Signal(config)

        if (this.queue.length >= this.maxQueueSize) {
            this._totalDropped++
            throw new Error(`Signal Bus queue full (${this.maxQueueSize}) — signal dropped`)
        }

        this.queue.push(signal)
        this._totalSent++

        // Track propagation graph
        if (signal.senderId && signal.recipientId) {
            if (!this.propagationGraph[signal.senderId]) {
                this.propagationGraph[signal.senderId] = []
            }
            if (!this.propagationGraph[signal.senderId].includes(signal.recipientId)) {
                this.propagationGraph[signal.senderId].push(signal.recipientId)
            }
        }

        return signal
    }

    /**
     * Send a broadcast signal to all subscribers.
     */
    broadcast(senderId, type, payload, priority = 0) {
        this._totalBroadcasts++
        return this.send({
            senderId,
            recipientId: null,
            type: type || SIGNAL_TYPES.BROADCAST,
            payload,
            priority,
        })
    }

    /**
     * Send a signal to a topic's subscribers.
     */
    publish(senderId, topic, payload) {
        const subs = this.topicSubscribers.get(topic)
        if (!subs || subs.size === 0) return []

        const signals = []
        for (const cellId of subs) {
            if (cellId !== senderId) {
                signals.push(this.send({
                    senderId,
                    recipientId: cellId,
                    type: SIGNAL_TYPES.EVENT,
                    payload: { topic, ...payload },
                }))
            }
        }
        return signals
    }

    /**
     * Process the signal queue — deliver signals in deterministic order.
     *
     * D-SOR-02: SIGNAL DELIVERY ORDER
     * Signals delivered in timestamp order.
     * Ties broken by sender cell_id (lexicographic).
     * Signals are NEVER reordered for performance.
     *
     * @returns {number} Number of signals delivered
     */
    process() {
        if (this.queue.length === 0) return 0

        // Sort by timestamp, then by sender_id for deterministic ordering
        this.queue.sort((a, b) => {
            const timeA = new Date(a.timestamp).getTime()
            const timeB = new Date(b.timestamp).getTime()
            if (timeA !== timeB) return timeA - timeB
            return (a.senderId || '').localeCompare(b.senderId || '')
        })

        let deliveredCount = 0
        const remaining = []

        for (const signal of this.queue) {
            // Skip expired signals
            if (signal.isExpired()) {
                this._totalDropped++
                continue
            }

            if (signal.recipientId) {
                // Point-to-point delivery
                const handler = this.subscribers.get(signal.recipientId)
                if (handler) {
                    try {
                        handler(signal)
                        signal.markDelivered()
                        this._logDelivery(signal)
                        deliveredCount++
                        this._totalDelivered++
                    } catch {
                        // Delivery failed — re-queue
                        remaining.push(signal)
                    }
                } else {
                    // No subscriber — drop
                    this._totalDropped++
                }
            } else {
                // Broadcast — deliver to all subscribers except sender
                let broadcastDelivered = false
                for (const [cellId, handler] of this.subscribers) {
                    if (cellId !== signal.senderId) {
                        try {
                            handler(signal)
                            broadcastDelivered = true
                        } catch {
                            // Individual delivery failed — continue to others
                        }
                    }
                }
                if (broadcastDelivered) {
                    signal.markDelivered()
                    this._logDelivery(signal)
                    deliveredCount++
                    this._totalDelivered++
                }
            }
        }

        this.queue = remaining
        return deliveredCount
    }

    /**
     * Get the propagation graph for rollback scope computation (D-SOR-04).
     */
    getPropagationGraph() {
        return { ...this.propagationGraph }
    }

    /**
     * Get pending signal count.
     */
    pending() {
        return this.queue.length
    }

    /**
     * Clear the queue.
     */
    clear() {
        const dropped = this.queue.length
        this.queue = []
        this._totalDropped += dropped
        return dropped
    }

    /**
     * Get bus statistics.
     */
    stats() {
        return {
            totalSent: this._totalSent,
            totalDelivered: this._totalDelivered,
            totalDropped: this._totalDropped,
            totalBroadcasts: this._totalBroadcasts,
            pendingInQueue: this.queue.length,
            subscribers: this.subscribers.size,
            topics: this.topicSubscribers.size,
            propagationNodes: Object.keys(this.propagationGraph).length,
            deliveryRate: this._totalSent > 0
                ? ((this._totalDelivered / this._totalSent) * 100).toFixed(1) + '%'
                : 'N/A',
        }
    }

    // ── Private ──

    _logDelivery(signal) {
        this.delivered.push(signal.toJSON())
        while (this.delivered.length > this.maxDeliveredLog) {
            this.delivered.shift()
        }
    }
}

export const signalBus = new SignalBus()
export default signalBus
