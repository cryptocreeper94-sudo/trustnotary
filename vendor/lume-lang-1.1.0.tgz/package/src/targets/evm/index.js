/**
 * ═══════════════════════════════════════════════════════════
 *  LUME → EVM — Public API
 *
 *  Entry point for compiling Lume source code to Solidity.
 *
 *  Usage:
 *    import { compileToSolidity } from '@lume/compiler/targets/evm'
 *    const result = compileToSolidity(lumeSource, 'token.lume')
 *
 *  Pipeline:
 *    Lume Source → Lexer → Parser → AST
 *                                    ↓
 *                          EVM Safety Checker
 *                                    ↓
 *                           Type Resolver
 *                                    ↓
 *                         Solidity Emitter
 *                                    ↓
 *                        .sol output + ABI + warnings
 *
 * ═══════════════════════════════════════════════════════════
 */

import { tokenize } from '../../lexer.js'
import { Parser } from '../../parser.js'
import { checkEVMSafety, formatSafetyReport } from './safety-checker.js'
import { TypeResolver } from './type-resolver.js'
import { SolidityEmitter } from './solidity-emitter.js'

/**
 * Compile Lume source code to Solidity.
 *
 * @param {string} source - Lume source code
 * @param {string} [filename='<stdin>'] - Filename for error messages and contract naming
 * @param {object} [options] - Compilation options
 * @param {string} [options.contractName] - Override the contract name
 * @param {boolean} [options.strict=true] - Fail on safety warnings (not just errors)
 * @param {boolean} [options.quiet=false] - Suppress non-error output
 * @returns {{
 *   solidity: string,            // The generated Solidity source
 *   safe: boolean,               // Whether the contract passed safety checks
 *   safetyReport: string,        // Human-readable safety report
 *   warnings: string[],          // Type resolution warnings
 *   errors: string[],            // Type resolution errors
 *   violations: object[],        // Detailed safety violations
 *   contractName: string,        // Generated or explicit contract name
 *   ast: object,                 // The parsed AST (for inspection)
 * }}
 */
export function compileToSolidity(source, filename = '<stdin>', options = {}) {
    const strict = options.strict !== false
    const quiet = options.quiet || false

    // ── Step 1: Lex & Parse (reuse existing pipeline) ──
    const tokens = tokenize(source, filename)
    const parser = new Parser(tokens, filename)
    const ast = parser.parse()

    // ── Step 2: EVM Safety Check ──
    const safetyResult = checkEVMSafety(ast)
    const safetyReport = formatSafetyReport(safetyResult)

    if (!quiet && !safetyResult.safe) {
        console.error(safetyReport)
    }

    // In strict mode, also fail on warnings
    if (strict && !safetyResult.safe) {
        return {
            solidity: null,
            safe: false,
            safetyReport,
            warnings: [],
            errors: safetyResult.violations
                .filter(v => v.severity === 'error')
                .map(v => `[${v.rule}] ${v.message}`),
            violations: safetyResult.violations,
            contractName: null,
            ast,
        }
    }

    // ── Step 3: Resolve Types ──
    const resolver = new TypeResolver()
    const typeInfo = resolver.resolve(ast)

    // ── Step 4: Emit Solidity ──
    const emitter = new SolidityEmitter(ast, typeInfo, {
        filename,
        contractName: options.contractName,
    })

    const solidity = emitter.emit()

    // ── Step 5: Derive contract name ──
    const contractNameMatch = solidity.match(/contract\s+(\w+)/)
    const contractName = contractNameMatch ? contractNameMatch[1] : 'LumeContract'

    return {
        solidity,
        safe: safetyResult.safe,
        safetyReport,
        warnings: typeInfo.warnings,
        errors: typeInfo.errors.map(e => e.message || e),
        violations: safetyResult.violations,
        contractName,
        ast,
    }
}

/**
 * Get the supported EVM target versions.
 */
export function supportedEVMVersions() {
    return ['paris', 'shanghai', 'cancun']
}

/**
 * Get the Solidity pragma version used.
 */
export function solidityVersion() {
    return '^0.8.20'
}

// Re-export sub-modules for advanced usage
export { TypeResolver, SolType } from './type-resolver.js'
export { checkEVMSafety, formatSafetyReport, Severity } from './safety-checker.js'
export { SolidityEmitter } from './solidity-emitter.js'
