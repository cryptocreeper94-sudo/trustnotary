/**
 * ═══════════════════════════════════════════════════════════
 *  LUME → EVM — Safety Checker
 *
 *  Pre-emission analysis that enforces EVM-specific safety
 *  constraints. Maps directly to Lume's LDIR safety rules:
 *
 *  S-01 (Halt on unbounded)    →  Reject unbounded loops
 *  S-02 (Deny escalation)     →  Reentrancy checks
 *  S-03 (Preserve fidelity)   →  Integer overflow (Solidity 0.8+)
 *  S-04 (Never infer absence) →  Require explicit defaults
 *  S-05 (Crypto integrity)    →  Hash verification patterns
 *
 *  This checker REJECTS programs that cannot safely run on-chain.
 *  It does not silently degrade — it fails with clear errors.
 *
 * ═══════════════════════════════════════════════════════════
 */

import { NodeType } from '../../parser.js'

// ═══ Safety Violations ═══

export const Severity = {
    ERROR:   'error',    // Cannot compile — must fix
    WARNING: 'warning',  // Compiles but risky
    INFO:    'info',     // Best practice suggestion
}

/**
 * Run all safety checks on the AST.
 *
 * @param {object} ast - Parsed Lume AST
 * @returns {{ safe: boolean, violations: Array<{severity, rule, message, line, suggestion}> }}
 */
export function checkEVMSafety(ast) {
    const violations = []
    const ctx = {
        functionDepth: 0,
        loopDepth: 0,
        currentFunction: null,
        callGraph: new Map(),        // function → Set of called functions
        stateModifiers: new Map(),   // function → boolean (does it modify state?)
        externalCalls: new Map(),    // function → [{line, after_state_change}]
    }

    // Walk entire AST
    for (const node of ast.body) {
        _checkNode(node, ctx, violations)
    }

    // Post-walk analysis
    _checkRecursion(ctx, violations)
    _checkReentrancy(ctx, violations)

    const safe = violations.every(v => v.severity !== Severity.ERROR)

    return { safe, violations }
}

// ═══ Node-level Checks ═══

function _checkNode(node, ctx, violations) {
    if (!node || typeof node !== 'object') return

    switch (node.type) {
        case NodeType.WhileStatement:
            _checkWhileLoop(node, ctx, violations)
            break

        case NodeType.ForRangeStatement:
            _checkForRange(node, ctx, violations)
            break

        case NodeType.ForEachStatement:
        case NodeType.ForEachIndexStatement:
            _checkForEach(node, ctx, violations)
            break

        case NodeType.FunctionDeclaration:
            _checkFunction(node, ctx, violations)
            return // Body checked inside

        case NodeType.AskExpression:
        case NodeType.ThinkExpression:
        case NodeType.GenerateExpression:
            violations.push({
                severity: Severity.ERROR,
                rule: 'EVM-NO-AI',
                message: `AI operations (${node.type}) cannot run on-chain — the EVM has no network access`,
                line: node.line,
                suggestion: 'Move AI logic to an off-chain oracle and use a callback pattern',
            })
            break

        case NodeType.FetchExpression:
            violations.push({
                severity: Severity.ERROR,
                rule: 'EVM-NO-HTTP',
                message: 'HTTP fetch cannot be performed on-chain — the EVM is a closed execution environment',
                line: node.line,
                suggestion: 'Use Chainlink oracles or similar for external data',
            })
            break

        case NodeType.ReadExpression:
        case NodeType.WriteExpression:
            violations.push({
                severity: Severity.ERROR,
                rule: 'EVM-NO-FS',
                message: 'File I/O is not available on-chain',
                line: node.line,
                suggestion: 'Store data in contract storage (let/set) or emit events for off-chain indexing',
            })
            break

        case NodeType.ShowStatement:
        case NodeType.LogStatement:
            violations.push({
                severity: Severity.INFO,
                rule: 'EVM-LOG-AS-EVENT',
                message: `'show'/'log' will be compiled to a Solidity event emission`,
                line: node.line,
                suggestion: 'This is correct behavior — events are the EVM equivalent of logging',
            })
            break

        case NodeType.CallExpression:
            _checkCallExpression(node, ctx, violations)
            break

        case NodeType.SetStatement:
            // Track state modifications
            if (ctx.currentFunction) {
                ctx.stateModifiers.set(ctx.currentFunction, true)
            }
            break
    }

    // Recurse into child nodes
    _walkChildren(node, ctx, violations)
}

function _walkChildren(node, ctx, violations) {
    for (const key of Object.keys(node)) {
        if (key === 'type' || key === 'line' || key === 'column') continue
        const val = node[key]
        if (Array.isArray(val)) {
            for (const child of val) {
                if (child && typeof child === 'object' && child.type) {
                    _checkNode(child, ctx, violations)
                }
            }
        } else if (val && typeof val === 'object' && val.type) {
            _checkNode(val, ctx, violations)
        }
    }
}

// ═══ Loop Safety (LDIR S-01: Halt on unbounded) ═══

function _checkWhileLoop(node, ctx, violations) {
    // While loops are dangerous on-chain — they can consume all gas
    // We allow them ONLY if the condition references a counter that is bounded
    const condStr = _nodeToString(node.condition)
    const hasBoundCheck = /\b\w+\s*[<>]=?\s*\d+\b/.test(condStr) ||
                          /\b\d+\s*[<>]=?\s*\w+\b/.test(condStr)

    if (!hasBoundCheck) {
        violations.push({
            severity: Severity.ERROR,
            rule: 'LDIR-S01-UNBOUNDED-LOOP',
            message: `Unbounded 'while' loop detected — this will consume unlimited gas and likely revert`,
            line: node.line,
            suggestion: 'Use a bounded "for" loop instead: "for i in 0 to maxIterations:"',
        })
    } else {
        violations.push({
            severity: Severity.WARNING,
            rule: 'LDIR-S01-WHILE-CAUTION',
            message: `'while' loop has a bound check, but consider using 'for' for clearer gas guarantees`,
            line: node.line,
            suggestion: 'While loops are compiled but may still exceed block gas limit with large bounds',
        })
    }

    ctx.loopDepth++
    _walkChildren(node, ctx, violations)
    ctx.loopDepth--
}

function _checkForRange(node, ctx, violations) {
    // Check if the upper bound is a literal (known at compile time)
    if (node.end.type === NodeType.NumberLiteral) {
        const bound = node.end.value
        if (bound > 1000) {
            violations.push({
                severity: Severity.WARNING,
                rule: 'EVM-GAS-LOOP',
                message: `Loop with ${bound} iterations may exceed block gas limit (30M gas)`,
                line: node.line,
                suggestion: `Consider processing in batches or using a pattern that handles fewer items per transaction`,
            })
        }
    } else {
        violations.push({
            severity: Severity.WARNING,
            rule: 'EVM-DYNAMIC-BOUND',
            message: `Loop bound is not a compile-time constant — gas usage cannot be predicted`,
            line: node.line,
            suggestion: 'Add a maximum iteration cap: "for i in 0 to min(count, 100):"',
        })
    }

    ctx.loopDepth++
    _walkChildren(node, ctx, violations)
    ctx.loopDepth--
}

function _checkForEach(node, ctx, violations) {
    violations.push({
        severity: Severity.WARNING,
        rule: 'EVM-FOREACH-GAS',
        message: `'for each' iterates over a collection whose size may grow — gas cost is unbounded`,
        line: node.line,
        suggestion: 'Consider adding a maximum length check before the loop, or paginate with start/end indexes',
    })

    ctx.loopDepth++
    _walkChildren(node, ctx, violations)
    ctx.loopDepth--
}

// ═══ Function Analysis ═══

function _checkFunction(node, ctx, violations) {
    const prevFunc = ctx.currentFunction
    ctx.currentFunction = node.name
    ctx.callGraph.set(node.name, ctx.callGraph.get(node.name) || new Set())
    ctx.stateModifiers.set(node.name, ctx.stateModifiers.get(node.name) || false)
    ctx.externalCalls.set(node.name, [])

    ctx.functionDepth++
    for (const stmt of node.body) {
        _checkNode(stmt, ctx, violations)
    }
    ctx.functionDepth--

    ctx.currentFunction = prevFunc
}

function _checkCallExpression(node, ctx, violations) {
    if (!ctx.currentFunction) return

    // Track calls for recursion detection
    if (node.callee && node.callee.type === NodeType.Identifier) {
        const callee = node.callee.name
        const callers = ctx.callGraph.get(ctx.currentFunction) || new Set()
        callers.add(callee)
        ctx.callGraph.set(ctx.currentFunction, callers)
    }
}

// ═══ Post-walk Analysis ═══

/**
 * Detect recursive function calls.
 * Recursion on the EVM is extremely dangerous — stack depth is limited
 * to ~1024 and each call uses gas.
 */
function _checkRecursion(ctx, violations) {
    for (const [func, calls] of ctx.callGraph) {
        // Direct recursion
        if (calls.has(func)) {
            violations.push({
                severity: Severity.ERROR,
                rule: 'EVM-NO-RECURSION',
                message: `Function '${func}' calls itself recursively — this will likely exceed EVM stack depth (1024)`,
                line: 0,
                suggestion: `Rewrite using an iterative pattern with a loop instead of recursion`,
            })
        }

        // Check for indirect recursion (A→B→A)
        for (const called of calls) {
            const calledCalls = ctx.callGraph.get(called)
            if (calledCalls && calledCalls.has(func)) {
                violations.push({
                    severity: Severity.ERROR,
                    rule: 'EVM-NO-MUTUAL-RECURSION',
                    message: `Mutual recursion detected: '${func}' ↔ '${called}' — this will exceed EVM stack depth`,
                    line: 0,
                    suggestion: `Break the circular call chain by combining logic into a single function with a loop`,
                })
            }
        }
    }
}

/**
 * Basic reentrancy pattern detection.
 * Checks if any function makes external calls after modifying state.
 * (Full checks-effects-interactions pattern enforcement)
 */
function _checkReentrancy(ctx, violations) {
    // For now, emit a general warning if any function both modifies state
    // and has external-looking calls. The emitter will add reentrancy guards.
    for (const [func, modifies] of ctx.stateModifiers) {
        if (modifies) {
            const calls = ctx.callGraph.get(func) || new Set()
            // Any call to an unknown function (not in our call graph) is "external"
            for (const called of calls) {
                if (!ctx.callGraph.has(called)) {
                    violations.push({
                        severity: Severity.WARNING,
                        rule: 'EVM-REENTRANCY-RISK',
                        message: `Function '${func}' modifies state and calls external function '${called}' — potential reentrancy`,
                        line: 0,
                        suggestion: 'A nonReentrant modifier will be automatically applied for safety',
                    })
                }
            }
        }
    }
}

// ═══ Utilities ═══

/**
 * Convert an AST node to a rough string representation for pattern matching.
 */
function _nodeToString(node) {
    if (!node) return ''
    switch (node.type) {
        case NodeType.Identifier: return node.name
        case NodeType.NumberLiteral: return String(node.value)
        case NodeType.BinaryExpression:
            return `${_nodeToString(node.left)} ${node.operator} ${_nodeToString(node.right)}`
        default: return `<${node.type}>`
    }
}

/**
 * Generate a human-readable safety report.
 */
export function formatSafetyReport(result) {
    const lines = ['═══ Lume EVM Safety Check ═══', '']

    const errors = result.violations.filter(v => v.severity === Severity.ERROR)
    const warnings = result.violations.filter(v => v.severity === Severity.WARNING)
    const info = result.violations.filter(v => v.severity === Severity.INFO)

    if (result.safe) {
        lines.push('✅ Contract is safe to deploy')
    } else {
        lines.push(`❌ Contract has ${errors.length} error(s) that must be fixed`)
    }
    lines.push('')

    for (const v of errors) {
        lines.push(`  ✗ [${v.rule}] Line ${v.line}: ${v.message}`)
        if (v.suggestion) lines.push(`    → ${v.suggestion}`)
    }
    for (const v of warnings) {
        lines.push(`  ⚠ [${v.rule}] Line ${v.line}: ${v.message}`)
        if (v.suggestion) lines.push(`    → ${v.suggestion}`)
    }
    for (const v of info) {
        lines.push(`  ℹ [${v.rule}] Line ${v.line}: ${v.message}`)
    }

    lines.push('')
    lines.push(`Summary: ${errors.length} errors, ${warnings.length} warnings, ${info.length} info`)

    return lines.join('\n')
}
