/**
 * ═══════════════════════════════════════════════════════════
 *  LUME → EVM — Type Resolver
 *
 *  Resolves Lume's dynamically-typed AST nodes into Solidity's
 *  static type system. Builds a scope-aware type environment
 *  that tracks every variable, parameter, and return type.
 *
 *  Lume Type  →  Solidity Type
 *  ─────────────────────────────
 *  number     →  uint256 (default) / int256 (if negative)
 *  text       →  string
 *  boolean    →  bool
 *  address    →  address
 *  list       →  T[] (typed array)
 *  map        →  mapping(K => V)
 *  nothing    →  (no return)
 *  any        →  bytes (opaque)
 *
 *  Design: We do TWO passes over the AST:
 *    Pass 1 — Collect all declarations, infer types from literals
 *    Pass 2 — Propagate types through assignments and expressions
 *
 * ═══════════════════════════════════════════════════════════
 */

import { NodeType } from '../../parser.js'

// ═══ Solidity Type Constants ═══

export const SolType = {
    UINT256:  'uint256',
    INT256:   'int256',
    STRING:   'string',
    BOOL:     'bool',
    ADDRESS:  'address',
    BYTES:    'bytes',
    BYTES32:  'bytes32',
    UINT8:    'uint8',
    // Container types are represented as objects:
    // { kind: 'array', elementType: SolType }
    // { kind: 'mapping', keyType: SolType, valueType: SolType }
    // { kind: 'struct', name: string, fields: [{name, type}] }
}

/**
 * Map Lume type annotation keywords to Solidity types.
 */
const LUME_TYPE_MAP = {
    'number':  SolType.UINT256,
    'integer': SolType.UINT256,
    'int':     SolType.INT256,
    'text':    SolType.STRING,
    'string':  SolType.STRING,
    'boolean': SolType.BOOL,
    'bool':    SolType.BOOL,
    'address': SolType.ADDRESS,
    'bytes':   SolType.BYTES,
    'bytes32': SolType.BYTES32,
    'any':     SolType.BYTES,
    'nothing': null,
    'maybe':   null, // Optional — emitter will handle
}

/**
 * Infer a Solidity type from a literal AST node.
 */
function inferTypeFromLiteral(node) {
    if (!node) return SolType.UINT256

    switch (node.type) {
        case NodeType.NumberLiteral:
            return node.value < 0 ? SolType.INT256 : SolType.UINT256

        case NodeType.StringLiteral:
            // Detect Ethereum addresses: 0x followed by 40 hex chars
            if (/^0x[0-9a-fA-F]{40}$/.test(node.value)) {
                return SolType.ADDRESS
            }
            // Detect bytes32 hashes: 0x followed by 64 hex chars
            if (/^0x[0-9a-fA-F]{64}$/.test(node.value)) {
                return SolType.BYTES32
            }
            return SolType.STRING

        case NodeType.BooleanLiteral:
            return SolType.BOOL

        case NodeType.NullLiteral:
            return SolType.UINT256 // Default to uint256 for null/zero

        case NodeType.ListLiteral:
            if (node.elements && node.elements.length > 0) {
                const elemType = inferTypeFromLiteral(node.elements[0])
                return { kind: 'array', elementType: elemType }
            }
            return { kind: 'array', elementType: SolType.UINT256 }

        case NodeType.MapLiteral:
            if (node.entries && node.entries.length > 0) {
                const first = node.entries[0]
                const keyType = SolType.STRING // Map keys default to string
                const valueType = inferTypeFromLiteral(first.value)
                return { kind: 'mapping', keyType, valueType }
            }
            return { kind: 'mapping', keyType: SolType.STRING, valueType: SolType.UINT256 }

        case NodeType.BinaryExpression:
            return inferTypeFromBinaryExpr(node)

        case NodeType.CallExpression:
            // Unknown function return type — default to uint256
            return SolType.UINT256

        case NodeType.Identifier:
            // Will be resolved in pass 2
            return null

        default:
            return SolType.UINT256
    }
}

/**
 * Infer type from a binary expression.
 * Arithmetic → uint256/int256, comparison → bool, string concat → string
 */
function inferTypeFromBinaryExpr(node) {
    const op = node.operator
    // Comparison operators always return bool
    if (['==', '!=', '>', '<', '>=', '<=', '&&', '||'].includes(op)) {
        return SolType.BOOL
    }
    // Arithmetic — check operand types
    const leftType = inferTypeFromLiteral(node.left)
    const rightType = inferTypeFromLiteral(node.right)

    // String concatenation
    if (leftType === SolType.STRING || rightType === SolType.STRING) {
        return SolType.STRING
    }
    // If either operand is signed, result is signed
    if (leftType === SolType.INT256 || rightType === SolType.INT256) {
        return SolType.INT256
    }
    return SolType.UINT256
}

// ═══ Scope & Type Environment ═══

/**
 * A scope holds variable→type bindings and links to parent scope.
 */
class Scope {
    constructor(parent = null, name = 'global') {
        this.parent = parent
        this.name = name
        this.bindings = new Map()  // name → { type, mutable, storage }
    }

    define(name, type, options = {}) {
        this.bindings.set(name, {
            type,
            mutable: options.mutable !== false,
            storage: options.storage || 'storage',  // 'storage' | 'memory' | 'calldata'
            isConstant: options.isConstant || false,
            isParam: options.isParam || false,
        })
    }

    lookup(name) {
        if (this.bindings.has(name)) return this.bindings.get(name)
        if (this.parent) return this.parent.lookup(name)
        return null
    }

    child(name) {
        return new Scope(this, name)
    }
}

// ═══ Type Resolver ═══

export class TypeResolver {
    constructor() {
        this.globalScope = new Scope(null, 'contract')
        this.currentScope = this.globalScope
        this.structs = new Map()      // struct name → { fields: [{name, type}] }
        this.functions = new Map()    // func name → { params: [{name, type}], returnType, mutates }
        this.warnings = []
        this.errors = []
    }

    /**
     * Resolve all types in the AST.
     * Returns { scope, structs, functions, warnings, errors }
     */
    resolve(ast) {
        // Pass 1: Collect declarations
        for (const node of ast.body) {
            this._resolveNode(node)
        }

        // Pass 2: Propagate unknown types
        this._propagateTypes()

        return {
            scope: this.globalScope,
            structs: this.structs,
            functions: this.functions,
            warnings: this.warnings,
            errors: this.errors,
        }
    }

    // ── Pass 1: Declaration Collection ──

    _resolveNode(node) {
        switch (node.type) {
            case NodeType.LetDeclaration:
                return this._resolveLet(node)
            case NodeType.DefineDeclaration:
                return this._resolveDefine(node)
            case NodeType.FunctionDeclaration:
                return this._resolveFunction(node)
            case NodeType.TypeDeclaration:
                return this._resolveType(node)
            case NodeType.SetStatement:
                return this._resolveSet(node)
            default:
                // Other nodes don't introduce bindings
                return null
        }
    }

    _resolveLet(node) {
        let type = null

        // Explicit type annotation
        if (node.typeAnnotation) {
            type = this._resolveTypeAnnotation(node.typeAnnotation)
        }

        // Infer from value
        if (!type && node.value) {
            type = inferTypeFromLiteral(node.value)
        }

        // Fallback
        if (!type) type = SolType.UINT256

        const isGlobal = this.currentScope === this.globalScope
        this.currentScope.define(node.name, type, {
            mutable: true,
            storage: isGlobal ? 'storage' : 'memory',
        })

        return type
    }

    _resolveDefine(node) {
        let type = null

        if (node.value) {
            type = inferTypeFromLiteral(node.value)
        }
        if (!type) type = SolType.UINT256

        this.currentScope.define(node.name, type, {
            mutable: false,
            isConstant: true,
            storage: 'storage',
        })

        return type
    }

    _resolveFunction(node) {
        const funcScope = this.currentScope.child(node.name)
        const prevScope = this.currentScope
        this.currentScope = funcScope

        // Resolve parameters
        const params = []
        let mutatesState = false

        for (const param of node.params) {
            let pType = SolType.UINT256

            if (param.typeAnnotation) {
                pType = this._resolveTypeAnnotation(param.typeAnnotation)
            } else {
                // Infer from parameter name conventions
                pType = this._inferFromName(param.name)
            }

            funcScope.define(param.name, pType, {
                isParam: true,
                storage: (pType === SolType.STRING || typeof pType === 'object')
                    ? 'memory' : 'stack',
            })
            params.push({ name: param.name, type: pType })
        }

        // Resolve body to find return type and state mutations
        let returnType = null
        if (node.returnType) {
            returnType = this._resolveTypeAnnotation(node.returnType)
        }

        for (const stmt of node.body) {
            this._resolveNode(stmt)

            // Check for state mutations
            if (stmt.type === NodeType.SetStatement) {
                const binding = this.globalScope.bindings.get(stmt.name)
                if (binding) mutatesState = true
            }

            // Infer return type from return statements
            if (stmt.type === NodeType.ReturnStatement && stmt.value && !returnType) {
                returnType = inferTypeFromLiteral(stmt.value)
            }
        }

        this.currentScope = prevScope

        // Determine visibility/mutability
        const visibility = node.decorator === '@private' ? 'internal' : 'public'
        const stateMutability = node.decorator === '@payable'
            ? 'payable'
            : mutatesState ? '' : (returnType ? 'view' : 'pure')

        this.functions.set(node.name, {
            params,
            returnType,
            mutatesState,
            visibility,
            stateMutability,
            scope: funcScope,
        })

        return returnType
    }

    _resolveType(node) {
        if (node.isAlias) {
            // Type alias — register the underlying type
            const aliasType = this._resolveTypeAnnotation(node.aliasType)
            this.structs.set(node.name, { isAlias: true, type: aliasType })
            return
        }

        // Struct definition
        const fields = []
        for (const field of node.fields) {
            let fType = SolType.UINT256
            if (field.typeAnnotation) {
                fType = this._resolveTypeAnnotation(field.typeAnnotation)
            } else if (field.defaultValue) {
                fType = inferTypeFromLiteral(field.defaultValue)
            }
            fields.push({ name: field.name, type: fType })
        }

        this.structs.set(node.name, {
            isAlias: false,
            fields,
            type: { kind: 'struct', name: node.name, fields },
        })
    }

    _resolveSet(node) {
        // Check if this modifies a global variable
        const binding = this.globalScope.bindings.get(node.name)
        if (binding && binding.isConstant) {
            this.errors.push({
                message: `Cannot modify constant '${node.name}' — use 'let' instead of 'define'`,
                line: node.line,
            })
        }
    }

    // ── Type Annotation Resolution ──

    _resolveTypeAnnotation(annotation) {
        if (!annotation) return SolType.UINT256

        const name = typeof annotation === 'string'
            ? annotation
            : annotation.name || annotation.value || 'number'

        const mapped = LUME_TYPE_MAP[name.toLowerCase()]
        if (mapped !== undefined) return mapped

        // Check if it's a known struct
        if (this.structs.has(name)) {
            return { kind: 'struct', name, fields: this.structs.get(name).fields }
        }

        this.warnings.push(`Unknown type annotation '${name}' — defaulting to uint256`)
        return SolType.UINT256
    }

    // ── Name-based Type Inference ──

    /**
     * Infer type from conventional parameter names.
     * This makes Lume contracts more intuitive — users don't need to
     * annotate types for common patterns.
     */
    _inferFromName(name) {
        const lower = name.toLowerCase()

        // Address patterns
        if (['to', 'from', 'sender', 'receiver', 'owner', 'spender',
             'recipient', 'account', 'addr', 'address'].includes(lower)) {
            return SolType.ADDRESS
        }

        // Amount/quantity patterns → uint256
        if (['amount', 'value', 'balance', 'total', 'price', 'cost',
             'fee', 'reward', 'supply', 'count', 'qty', 'quantity',
             'limit', 'threshold', 'allowance', 'id', 'index', 'nonce'].includes(lower)) {
            return SolType.UINT256
        }

        // Boolean patterns
        if (lower.startsWith('is') || lower.startsWith('has') ||
            lower.startsWith('can') || lower.startsWith('should') ||
            ['approved', 'active', 'enabled', 'paused', 'locked', 'valid'].includes(lower)) {
            return SolType.BOOL
        }

        // String patterns
        if (['name', 'symbol', 'message', 'reason', 'description',
             'label', 'title', 'uri', 'url', 'data', 'metadata'].includes(lower)) {
            return SolType.STRING
        }

        // Hash patterns
        if (['hash', 'root', 'proof', 'signature', 'sig'].includes(lower)) {
            return SolType.BYTES32
        }

        // Default to uint256
        return SolType.UINT256
    }

    // ── Pass 2: Type Propagation ──

    _propagateTypes() {
        // For each function, resolve any remaining null types
        for (const [name, func] of this.functions) {
            for (const param of func.params) {
                if (!param.type) {
                    param.type = SolType.UINT256
                    this.warnings.push(
                        `Could not infer type for parameter '${param.name}' in function '${name}' — defaulting to uint256`
                    )
                }
            }
        }
    }

    // ── Utilities ──

    /**
     * Convert a resolved type to its Solidity string representation.
     */
    static typeToString(type) {
        if (typeof type === 'string') return type

        if (!type) return 'uint256'

        if (type.kind === 'array') {
            return `${TypeResolver.typeToString(type.elementType)}[]`
        }

        if (type.kind === 'mapping') {
            return `mapping(${TypeResolver.typeToString(type.keyType)} => ${TypeResolver.typeToString(type.valueType)})`
        }

        if (type.kind === 'struct') {
            return type.name
        }

        return 'uint256'
    }

    /**
     * Determine storage location qualifier for complex types.
     * Solidity requires explicit memory/storage/calldata for
     * strings, arrays, structs, and bytes.
     */
    static needsLocation(type) {
        if (typeof type === 'string') {
            return ['string', 'bytes'].includes(type)
        }
        if (type && typeof type === 'object') {
            return ['array', 'struct'].includes(type.kind)
        }
        return false
    }
}
