/**
 * ═══════════════════════════════════════════════════════════
 *  LUME TRUST CERTIFICATE CHAIN MANAGER
 *  Manages certificate chains from COMPILE_ROOT through
 *  runtime cells and agent sessions.
 *
 *  §8.3 Lifecycle: EMITTED → ACTIVE → EXPIRED/REVOKED/RENEWED
 *
 *  By DarkWave Studios LLC — DarkWaveStudios.io
 *  Copyright 2026. Protected by TrustShield.tech
 * ═══════════════════════════════════════════════════════════
 */

import { LumeTrustCertificate, CERT_TYPES } from './certificate.js'
import { TrustCertificateValidator } from './validator.js'

export class CertificateChain {
    constructor(config = {}) {
        this.certificates = new Map()  // cert_id → cert
        this.chains = new Map()        // root_hash → [cert_ids in order]
        this.validator = config.validator || new TrustCertificateValidator()
        this.revocationList = new Set()
    }

    /**
     * Add a certificate to the chain.
     * Automatically links it to its parent and root.
     */
    add(cert) {
        const json = cert instanceof LumeTrustCertificate ? cert.toJSON() : cert
        const certId = json.cert_id

        this.certificates.set(certId, json)
        this.validator.storeCertificate(json)

        // Track the chain
        const rootHash = json.chain?.root_hash || certId
        if (!this.chains.has(rootHash)) {
            this.chains.set(rootHash, [])
        }
        this.chains.get(rootHash).push(certId)

        return certId
    }

    /**
     * Get a certificate by ID.
     */
    get(certId) {
        return this.certificates.get(certId)
    }

    /**
     * Get the full chain for a certificate, walking from leaf to root.
     */
    getChain(certId) {
        const chain = []
        let current = this.certificates.get(certId)

        const visited = new Set()
        while (current) {
            if (visited.has(current.cert_id)) break  // Cycle protection
            visited.add(current.cert_id)
            chain.push(current)

            if (current.chain?.parent_cert === 'ROOT' || !current.chain?.parent_cert) {
                break
            }
            current = this.certificates.get(current.chain.parent_cert)
        }

        return chain
    }

    /**
     * Get all certificates in a chain by root hash.
     */
    getChainByRoot(rootHash) {
        const certIds = this.chains.get(rootHash) || []
        return certIds.map(id => this.certificates.get(id)).filter(Boolean)
    }

    /**
     * Validate a certificate and its full chain.
     */
    validateChain(certId, publicKey) {
        const chain = this.getChain(certId)

        if (chain.length === 0) {
            return { valid: false, reason: 'Certificate not found', chain: [] }
        }

        const results = []
        let allValid = true

        for (const cert of chain) {
            const result = this.validator.validate(cert, publicKey)
            results.push({
                cert_id: cert.cert_id,
                cert_type: cert.cert_type,
                valid: result.valid,
                failedStep: result.failedStep,
            })
            if (!result.valid) allValid = false
        }

        return {
            valid: allValid,
            chainLength: chain.length,
            root: chain[chain.length - 1]?.cert_id || null,
            leaf: chain[0]?.cert_id || null,
            results,
        }
    }

    /**
     * Revoke a certificate and all its descendants.
     */
    revoke(certId, reason = 'revoked') {
        const revoked = []

        // Revoke the target
        this.revocationList.add(certId)
        this.validator.revoke(certId)
        revoked.push(certId)

        // Find and revoke all children
        for (const [id, cert] of this.certificates) {
            if (cert.chain?.parent_cert === certId) {
                const childRevoked = this.revoke(id, `parent ${certId.slice(0, 12)} revoked`)
                revoked.push(...childRevoked)
            }
        }

        return revoked
    }

    /**
     * Check if a certificate is revoked.
     */
    isRevoked(certId) {
        return this.revocationList.has(certId)
    }

    /**
     * Get chain statistics.
     */
    stats() {
        const byType = {}
        for (const [, cert] of this.certificates) {
            byType[cert.cert_type] = (byType[cert.cert_type] || 0) + 1
        }

        return {
            totalCertificates: this.certificates.size,
            totalChains: this.chains.size,
            revoked: this.revocationList.size,
            byType,
            maxDepth: Math.max(0, ...Array.from(this.certificates.values()).map(c => c.chain?.depth || 0)),
        }
    }

    /**
     * Export all certificates.
     */
    export() {
        return {
            certificates: Array.from(this.certificates.values()),
            chains: Object.fromEntries(this.chains),
            revocations: [...this.revocationList],
            stats: this.stats(),
            exportedAt: new Date().toISOString(),
        }
    }
}

export const chain = new CertificateChain()
export default chain
