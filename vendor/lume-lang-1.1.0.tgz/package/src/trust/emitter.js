/**
 * ═══════════════════════════════════════════════════════════
 *  LUME TRUST CERTIFICATE EMITTER
 *  Emits LTC certificates at the compile boundary.
 *
 *  AX-03: TRUST IS COMPILED, NOT BOLTED ON
 *  Security certificates are emitted at compile time.
 *  Runtime checks validate what the compiler already proved.
 *
 *  By DarkWave Studios LLC — DarkWaveStudios.io
 *  Copyright 2026. Protected by TrustShield.tech
 * ═══════════════════════════════════════════════════════════
 */

import crypto from 'crypto'
import { LumeTrustCertificate, CERT_TYPES, PROOF_TYPES, PROOF_STATUS, generateKeyPair } from './certificate.js'

export class TrustCertificateEmitter {
    constructor(config = {}) {
        // Generate or load keypair
        if (config.privateKey && config.publicKey) {
            this.privateKey = config.privateKey
            this.publicKey = config.publicKey
        } else {
            const kp = generateKeyPair()
            this.privateKey = kp.privateKey
            this.publicKey = kp.publicKey
        }

        this.compilerVersion = config.compilerVersion || '1.1.0'
        this.instanceId = config.instanceId || crypto.randomUUID()
        this.emittedCerts = []
        this.revocationList = new Set()
    }

    /**
     * Emit a COMPILE_ROOT certificate for a compiled program.
     * This is the primary compile-time trust artifact.
     *
     * @param {Object} compilationResult
     * @param {string} compilationResult.source - Original source code
     * @param {string} compilationResult.output - Compiled output
     * @param {Object} compilationResult.ast - The resolved AST
     * @param {string} compilationResult.ir - The Intent IR (if generated)
     * @param {string} compilationResult.language - Source language (ISO 639-1)
     * @param {string} compilationResult.targetPlatform - 'wasm' | 'x86-64' | 'arm64'
     * @param {Object} [securityResults] - Guardian Scanner results
     * @returns {LumeTrustCertificate}
     */
    emitCompileRoot(compilationResult, securityResults = null) {
        const {
            source = '',
            output = '',
            ast = null,
            ir = null,
            language = 'en',
            targetPlatform = 'wasm',
            programName = 'unknown.lume',
        } = compilationResult

        // Compute hashes for intent binding
        const intentHash = this._hash(source)
        const astHash = ast ? this._hash(JSON.stringify(ast)) : null
        const irHash = ir ? this._hash(ir) : null

        // Create the certificate
        const cert = new LumeTrustCertificate({
            cert_type: CERT_TYPES.COMPILE_ROOT,
            expires_at: 'NEVER',
            issuer: {
                authority: 'lume-compiler',
                version: this.compilerVersion,
                instance_id: this.instanceId,
            },
            subject: {
                subject_type: 'compiled_program',
                subject_id: crypto.randomUUID(),
                subject_name: programName,
            },
            intent_binding: {
                intent_hash: intentHash,
                intent_lang: language,
                ast_hash: astHash,
                ir_hash: irHash,
            },
            permissions: this._inferPermissions(ast, securityResults),
            chain: { parent_cert: 'ROOT', depth: 0, root_hash: null },
            metadata: {
                compiler_version: this.compilerVersion,
                compilation_id: crypto.randomUUID(),
                target_platform: targetPlatform,
                source_size: source.length,
                output_size: output.length,
                output_hash: this._hash(output),
            },
        })

        // Add determinism proof
        cert.addProof(PROOF_TYPES.DETERMINISM, {
            type: 'compilation_determinism',
            input_hash: intentHash,
            output_hash: this._hash(output),
            compiler_version: this.compilerVersion,
            timestamp: new Date().toISOString(),
        })

        // Add isolation proof
        cert.addProof(PROOF_TYPES.ISOLATION, {
            type: 'compilation_isolation',
            sandbox: true,
            no_side_effects: true,
            deterministic_env: true,
        })

        // Add security proofs from Guardian Scanner
        if (securityResults) {
            const threatScore = securityResults.threatScore ?? 0
            cert.addProof(PROOF_TYPES.PERMISSION, {
                type: 'guardian_scan',
                threat_score: threatScore,
                passed: threatScore < 50,
                categories_scanned: Object.keys(securityResults.results || {}),
                scan_version: securityResults.version || '1.0',
            })
        }

        // Sign the certificate
        cert.sign(this.privateKey)

        // Track it
        this.emittedCerts.push(cert)

        return cert
    }

    /**
     * Emit a COMPILE_PROOF certificate for a specific security proof.
     */
    emitCompileProof(proofType, proofData, parentCert) {
        const cert = new LumeTrustCertificate({
            cert_type: CERT_TYPES.COMPILE_PROOF,
            expires_at: 'NEVER',
            issuer: {
                authority: 'lume-compiler',
                version: this.compilerVersion,
                instance_id: this.instanceId,
            },
            subject: {
                subject_type: 'security_proof',
                subject_id: crypto.randomUUID(),
                subject_name: `${proofType}-proof`,
            },
            chain: {
                parent_cert: parentCert.cert_id,
                depth: parentCert.chain.depth + 1,
                root_hash: parentCert.chain.root_hash,
            },
        })

        cert.addProof(proofType, proofData)
        cert.sign(this.privateKey)
        this.emittedCerts.push(cert)

        return cert
    }

    /**
     * Emit a RUNTIME_CELL certificate for a runtime cell.
     */
    emitRuntimeCell(cellId, cellName, parentCert, ttlMs = 300000) {
        const cert = new LumeTrustCertificate({
            cert_type: CERT_TYPES.RUNTIME_CELL,
            expires_at: new Date(Date.now() + ttlMs).toISOString(),
            issuer: {
                authority: 'sor-cell-manager',
                version: this.compilerVersion,
                instance_id: this.instanceId,
            },
            subject: {
                subject_type: 'runtime_cell',
                subject_id: cellId,
                subject_name: cellName,
            },
            permissions: {
                allowed: ['signal:send', 'signal:receive', 'state:read', 'state:write'],
                denied: ['sys:exec', 'net:raw', 'fs:write:*'],
                inherited: parentCert.cert_id,
            },
            chain: {
                parent_cert: parentCert.cert_id,
                depth: parentCert.chain.depth + 1,
                root_hash: parentCert.chain.root_hash,
            },
        })

        cert.sign(this.privateKey)
        this.emittedCerts.push(cert)

        return cert
    }

    /**
     * Emit an AGENT_SESSION certificate.
     */
    emitAgentSession(agentId, agentClass, trustLevel, parentCert, ttlMs = 3600000) {
        const cert = new LumeTrustCertificate({
            cert_type: CERT_TYPES.AGENT_SESSION,
            expires_at: new Date(Date.now() + ttlMs).toISOString(),
            issuer: {
                authority: 'agent-gateway',
                version: this.compilerVersion,
                instance_id: this.instanceId,
            },
            subject: {
                subject_type: 'agent_session',
                subject_id: agentId,
                subject_name: `${agentClass}-session`,
            },
            permissions: this._agentPermissions(trustLevel),
            chain: {
                parent_cert: parentCert.cert_id,
                depth: parentCert.chain.depth + 1,
                root_hash: parentCert.chain.root_hash,
            },
            metadata: {
                agent_class: agentClass,
                trust_level: trustLevel,
            },
        })

        cert.sign(this.privateKey)
        this.emittedCerts.push(cert)

        return cert
    }

    /**
     * Emit a REVOCATION certificate.
     */
    emitRevocation(revokedCertId, reason) {
        const cert = new LumeTrustCertificate({
            cert_type: CERT_TYPES.REVOCATION,
            expires_at: 'NEVER',
            issuer: {
                authority: 'trust-layer-ca',
                version: this.compilerVersion,
                instance_id: this.instanceId,
            },
            subject: {
                subject_type: 'revoked_certificate',
                subject_id: revokedCertId,
                subject_name: `revocation-${revokedCertId.slice(0, 12)}`,
            },
            metadata: {
                revoked_cert_id: revokedCertId,
                revocation_reason: reason,
                revoked_at: new Date().toISOString(),
            },
        })

        cert.sign(this.privateKey)
        this.emittedCerts.push(cert)
        this.revocationList.add(revokedCertId)

        return cert
    }

    /**
     * Check if a certificate has been revoked.
     */
    isRevoked(certId) {
        return this.revocationList.has(certId)
    }

    /**
     * Get the public key for signature verification.
     */
    getPublicKey() {
        return this.publicKey
    }

    /**
     * Get all emitted certificates.
     */
    getCertificates() {
        return this.emittedCerts.map(c => c.toJSON())
    }

    /**
     * Get emitter statistics.
     */
    stats() {
        const byType = {}
        for (const cert of this.emittedCerts) {
            byType[cert.cert_type] = (byType[cert.cert_type] || 0) + 1
        }
        return {
            totalEmitted: this.emittedCerts.length,
            byType,
            revocations: this.revocationList.size,
            compilerVersion: this.compilerVersion,
            instanceId: this.instanceId,
        }
    }

    // ── Private ──

    _hash(data) {
        return crypto
            .createHash('sha256')
            .update(typeof data === 'string' ? data : JSON.stringify(data))
            .digest('hex')
    }

    _inferPermissions(ast, securityResults) {
        const allowed = []
        const denied = ['sys:exec:*', 'net:raw:*']

        // Default: conservative permissions
        if (securityResults && securityResults.threatScore < 20) {
            allowed.push('fs:read:*', 'net:http:GET:*')
        }

        // If AST contains file operations
        if (ast && JSON.stringify(ast).includes('file')) {
            allowed.push('fs:read:/data/*')
        }

        // If AST contains network operations
        if (ast && JSON.stringify(ast).includes('fetch')) {
            allowed.push('net:http:GET:*', 'net:http:POST:*')
        }

        return { allowed, denied, inherited: null }
    }

    _agentPermissions(trustLevel) {
        switch (trustLevel) {
            case 'certified':
                return {
                    allowed: ['task:execute', 'task:delegate', 'consensus:propose', 'consensus:vote', 'signal:send', 'signal:receive'],
                    denied: ['trust:escalate', 'agent:register'],
                    inherited: null,
                }
            case 'provisional':
                return {
                    allowed: ['task:execute', 'consensus:vote', 'signal:send', 'signal:receive'],
                    denied: ['task:delegate', 'consensus:propose', 'trust:escalate', 'agent:register'],
                    inherited: null,
                }
            case 'sandboxed':
                return {
                    allowed: ['task:execute', 'signal:receive'],
                    denied: ['task:delegate', 'consensus:propose', 'consensus:vote', 'trust:escalate', 'signal:send:broadcast'],
                    inherited: null,
                }
            case 'untrusted':
            default:
                return {
                    allowed: ['signal:receive'],
                    denied: ['task:execute', 'task:delegate', 'consensus:propose', 'consensus:vote', 'trust:escalate', 'signal:send'],
                    inherited: null,
                }
        }
    }
}

export const emitter = new TrustCertificateEmitter()
export default emitter
