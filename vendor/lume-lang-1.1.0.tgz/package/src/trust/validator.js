/**
 * ═══════════════════════════════════════════════════════════
 *  LUME TRUST CERTIFICATE VALIDATOR
 *  Implements the 7-step validation algorithm from §8.3.
 *
 *  Steps:
 *    1. Verify signature against issuer's public key
 *    2. Check cert_id = SHA-256(canonical_body)
 *    3. Check expires_at > current_time
 *    4. Check cert_id not in revocation list
 *    5. Walk chain.parent_cert to ROOT
 *    6. Verify each security_proof hash
 *    7. Compare intent_binding hashes against known source
 *
 *  By DarkWave Studios LLC — DarkWaveStudios.io
 *  Copyright 2026. Protected by TrustShield.tech
 * ═══════════════════════════════════════════════════════════
 */

import { LumeTrustCertificate } from './certificate.js'
import crypto from 'crypto'

export class TrustCertificateValidator {
    constructor(config = {}) {
        this.trustedKeys = new Map()       // issuer_id → publicKey
        this.revocationList = new Set()     // cert_ids that have been revoked
        this.certStore = new Map()          // cert_id → certificate (for chain walking)
        this.validationLog = []
    }

    /**
     * Register a trusted public key for an issuer.
     */
    registerTrustedKey(issuerId, publicKey) {
        this.trustedKeys.set(issuerId, publicKey)
    }

    /**
     * Add a certificate to the store (for chain walking).
     */
    storeCertificate(cert) {
        const id = cert.cert_id || cert.cert_id
        this.certStore.set(id, cert)
    }

    /**
     * Revoke a certificate.
     */
    revoke(certId) {
        this.revocationList.add(certId)
    }

    /**
     * Validate a certificate through all 7 steps.
     *
     * @param {LumeTrustCertificate|Object} cert - Certificate to validate
     * @param {Buffer} [publicKey] - Public key override for signature verification
     * @param {Object} [knownSource] - Known source for intent binding verification
     * @returns {{ valid: boolean, steps: Object[], failedStep: number|null }}
     */
    validate(cert, publicKey = null, knownSource = null) {
        const steps = []
        let allPassed = true

        // Ensure cert is a LumeTrustCertificate instance
        if (!(cert instanceof LumeTrustCertificate)) {
            cert = LumeTrustCertificate.fromJSON(cert)
        }

        // Step 1: Verify signature against issuer's public key
        const step1 = this._step1_verifySignature(cert, publicKey)
        steps.push(step1)
        if (!step1.passed) allPassed = false

        // Step 2: Check cert_id = SHA-256(canonical_body)
        const step2 = this._step2_verifyIntegrity(cert)
        steps.push(step2)
        if (!step2.passed) allPassed = false

        // Step 3: Check not expired
        const step3 = this._step3_checkExpiration(cert)
        steps.push(step3)
        if (!step3.passed) allPassed = false

        // Step 4: Check not revoked
        const step4 = this._step4_checkRevocation(cert)
        steps.push(step4)
        if (!step4.passed) allPassed = false

        // Step 5: Walk chain to ROOT
        const step5 = this._step5_walkChain(cert)
        steps.push(step5)
        if (!step5.passed) allPassed = false

        // Step 6: Verify security proofs
        const step6 = this._step6_verifyProofs(cert)
        steps.push(step6)
        if (!step6.passed) allPassed = false

        // Step 7: Compare intent_binding hashes
        const step7 = this._step7_verifyIntentBinding(cert, knownSource)
        steps.push(step7)
        if (!step7.passed) allPassed = false

        const failedStep = steps.findIndex(s => !s.passed)

        const result = {
            valid: allPassed,
            cert_id: cert.cert_id,
            cert_type: cert.cert_type,
            steps,
            failedStep: failedStep >= 0 ? failedStep + 1 : null,
            validatedAt: new Date().toISOString(),
        }

        this.validationLog.push(result)
        return result
    }

    /**
     * Quick validation — just checks signature, integrity, expiration, revocation.
     * Faster than full 7-step validation.
     */
    quickValidate(cert, publicKey = null) {
        if (!(cert instanceof LumeTrustCertificate)) {
            cert = LumeTrustCertificate.fromJSON(cert)
        }

        const sig = this._step1_verifySignature(cert, publicKey)
        if (!sig.passed) return { valid: false, reason: sig.reason }

        const integrity = this._step2_verifyIntegrity(cert)
        if (!integrity.passed) return { valid: false, reason: integrity.reason }

        const expiration = this._step3_checkExpiration(cert)
        if (!expiration.passed) return { valid: false, reason: expiration.reason }

        const revocation = this._step4_checkRevocation(cert)
        if (!revocation.passed) return { valid: false, reason: revocation.reason }

        return { valid: true }
    }

    /**
     * Get validation history.
     */
    getValidationLog() {
        return this.validationLog
    }

    // ═══════════════════════════════════════════
    //  VALIDATION STEPS
    // ═══════════════════════════════════════════

    _step1_verifySignature(cert, publicKey) {
        const step = { step: 1, name: 'SIGNATURE VERIFICATION', passed: false, reason: '' }

        try {
            const key = publicKey
                || this.trustedKeys.get(cert.issuer?.instance_id)
                || this.trustedKeys.get(cert.issuer?.authority)

            if (!key) {
                step.reason = 'No trusted public key found for issuer'
                return step
            }

            if (!cert.signature) {
                step.reason = 'Certificate has no signature'
                return step
            }

            step.passed = cert.verifySignature(key)
            step.reason = step.passed ? 'Signature valid' : 'Signature verification failed'
        } catch (err) {
            step.reason = `Signature verification error: ${err.message}`
        }

        return step
    }

    _step2_verifyIntegrity(cert) {
        const step = { step: 2, name: 'INTEGRITY CHECK', passed: false, reason: '' }

        try {
            step.passed = cert.verifyIntegrity()
            step.reason = step.passed
                ? 'cert_id matches SHA-256 of canonical body'
                : 'cert_id does NOT match SHA-256 of canonical body — TAMPERED'
        } catch (err) {
            step.reason = `Integrity check error: ${err.message}`
        }

        return step
    }

    _step3_checkExpiration(cert) {
        const step = { step: 3, name: 'EXPIRATION CHECK', passed: false, reason: '' }

        if (cert.expires_at === 'NEVER') {
            step.passed = true
            step.reason = 'Certificate never expires'
            return step
        }

        try {
            const expired = cert.isExpired()
            step.passed = !expired
            step.reason = expired
                ? `Certificate expired at ${cert.expires_at}`
                : `Certificate valid until ${cert.expires_at}`
        } catch (err) {
            step.reason = `Expiration check error: ${err.message}`
        }

        return step
    }

    _step4_checkRevocation(cert) {
        const step = { step: 4, name: 'REVOCATION CHECK', passed: false, reason: '' }

        const revoked = this.revocationList.has(cert.cert_id)
        step.passed = !revoked
        step.reason = revoked
            ? 'Certificate has been REVOKED'
            : 'Certificate is not revoked'

        return step
    }

    _step5_walkChain(cert) {
        const step = { step: 5, name: 'CHAIN VALIDATION', passed: false, reason: '', chain: [] }

        try {
            let current = cert
            const visited = new Set()
            const chain = [current.cert_id]

            while (current.chain?.parent_cert && current.chain.parent_cert !== 'ROOT') {
                const parentId = current.chain.parent_cert

                // Cycle detection
                if (visited.has(parentId)) {
                    step.reason = `Cycle detected in certificate chain at ${parentId}`
                    step.chain = chain
                    return step
                }
                visited.add(parentId)

                // Look up parent
                const parent = this.certStore.get(parentId)
                if (!parent) {
                    step.reason = `Parent certificate ${parentId.slice(0, 16)}... not found in store`
                    step.chain = chain
                    // Partial chain — still consider it valid if the parent is just unknown
                    step.passed = true
                    step.reason += ' (partial chain — parent not in local store)'
                    return step
                }

                chain.push(parentId)
                current = parent instanceof LumeTrustCertificate ? parent : LumeTrustCertificate.fromJSON(parent)
            }

            // Reached ROOT
            chain.push('ROOT')
            step.passed = true
            step.reason = `Chain verified to ROOT (depth: ${chain.length - 1})`
            step.chain = chain
        } catch (err) {
            step.reason = `Chain validation error: ${err.message}`
        }

        return step
    }

    _step6_verifyProofs(cert) {
        const step = { step: 6, name: 'SECURITY PROOF VERIFICATION', passed: false, reason: '', proofs: [] }

        if (!cert.security_proofs || cert.security_proofs.length === 0) {
            step.passed = true
            step.reason = 'No security proofs to verify'
            return step
        }

        let allValid = true
        for (const proof of cert.security_proofs) {
            const proofResult = {
                type: proof.proof_type,
                hash: proof.proof_hash?.slice(0, 16) + '...',
                status: proof.proof_status,
                valid: proof.proof_status === 'verified',
            }

            if (proof.proof_status !== 'verified') {
                allValid = false
                proofResult.valid = false
            }

            // Verify hash is a valid SHA-256
            if (proof.proof_hash && proof.proof_hash.length !== 64) {
                allValid = false
                proofResult.valid = false
                proofResult.issue = 'Invalid hash length'
            }

            step.proofs.push(proofResult)
        }

        step.passed = allValid
        step.reason = allValid
            ? `All ${cert.security_proofs.length} security proofs verified`
            : `Some security proofs failed verification`

        return step
    }

    _step7_verifyIntentBinding(cert, knownSource) {
        const step = { step: 7, name: 'INTENT BINDING VERIFICATION', passed: false, reason: '' }

        if (!cert.intent_binding) {
            step.passed = true
            step.reason = 'No intent binding to verify'
            return step
        }

        if (!knownSource) {
            step.passed = true
            step.reason = 'No known source provided — skipping intent binding verification'
            return step
        }

        const computedHash = crypto.createHash('sha256')
            .update(knownSource)
            .digest('hex')

        step.passed = computedHash === cert.intent_binding.intent_hash
        step.reason = step.passed
            ? 'Intent hash matches known source'
            : 'Intent hash does NOT match known source — source may have been modified'

        return step
    }
}

export const validator = new TrustCertificateValidator()
export default validator
